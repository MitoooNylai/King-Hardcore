// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.entity.BlockDisplay;
import org.joml.Matrix4f;
import org.joml.Vector3f;

private static record Deco(BlockDisplay d, Matrix4f local, Vector3f pivot, int start, int dur, boolean swing, String sound, float pitch) {
}