// by decompiler.cc
package com.bzl.deathanimation;

static class MannequinBody$1 {
    static {
        try {
            $SwitchMap$com$bzl$deathanimation$Body$Stage[Body.Stage.FALL.ordinal()] = 1;
        } catch (NoSuchFieldError noSuchFieldError) {
            try {
                $SwitchMap$com$bzl$deathanimation$Body$Stage[Body.Stage.GET_UP.ordinal()] = 2;
            } catch (NoSuchFieldError noSuchFieldError) {

            }
        }
        try {
            $SwitchMap$com$bzl$deathanimation$Body$Stage[Body.Stage.PULL.ordinal()] = 3;
        } catch (NoSuchFieldError noSuchFieldError) {
            try {
                $SwitchMap$com$bzl$deathanimation$Body$Stage[Body.Stage.DESCEND.ordinal()] = 4;
            } catch (NoSuchFieldError noSuchFieldError) {

            }
        }
        try {
            $SwitchMap$com$bzl$deathanimation$Body$Stage[Body.Stage.LAND.ordinal()] = 5;
        } catch (NoSuchFieldError noSuchFieldError) {
            try {
                $SwitchMap$com$bzl$deathanimation$Body$Stage[Body.Stage.LOOK.ordinal()] = 6;
            } catch (NoSuchFieldError noSuchFieldError) {

            }
        }
    }
}