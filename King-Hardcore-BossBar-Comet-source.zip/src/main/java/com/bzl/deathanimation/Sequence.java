// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

interface Sequence {
    void abort();

    static Sequence fromSky(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, boolean wings, Runnable onLand) {
        return Descent.clearAbove(dest) >= 6.0 ? new Arrival(plugin, player, dest, mode, wings, onLand) : new Descent(plugin, player, dest, mode, onLand);
    }
}