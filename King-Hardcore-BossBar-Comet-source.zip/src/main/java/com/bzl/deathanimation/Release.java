// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

final class Release extends BukkitRunnable {
    private static final int OPEN = 16;
    private static final int SINK = 34;
    private static final int ARRIVE = 46;
    private final BzlDeathAnimation plugin;
    private final Player player;
    private final Location start;
    private final Location dest;
    private final GameMode mode;
    private final Runnable onDone;
    private final Rift floor;
    private Sequence descent;
    private int tick;
    private boolean done;

    Release(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, Runnable onDone) {
        this.plugin = plugin;
        this.player = player;
        this.dest = dest.clone();
        this.mode = mode;
        this.onDone = onDone;
        start = player.getLocation();
        player.getPersistentDataContainer().set(plugin.pendingKey, PersistentDataType.STRING, mode.name() + ";" + Nebula.serialize(dest));
        floor = new Rift(start.clone().add(0.0, 0.06, 0.0), 1.3F, 1);
        World w = start.getWorld();
        w.playSound(start, "block.respawn_anchor.charge", 1.0F, 0.8F);
        w.playSound(start, "block.beacon.activate", 1.0F, 1.3F);
        runTaskTimer(plugin, 1L, 1L);
    }

    public void run() {
        tick++;
        if (!player.isOnline()) {
            abort();
            return;
        }
        World w = start.getWorld();
        float s = outBack(k((float)tick, 0.0F, 16.0F));
        floor.size(s, 2, tick);
        swirl(w, start.clone().add(0.0, 0.15, 0.0), 1.3 * (double)s);
        if (tick < 34) {
            Location now = player.getLocation();
            boolean away = !now.getWorld().equals(start.getWorld()) || now.distanceSquared(start) > 0.04;
            if (away) {
                Location hold = start.clone();
                hold.setYaw(now.getYaw());
                hold.setPitch(now.getPitch());
                player.teleport(hold);
            }
            if (tick == 4) {
                w.playSound(start, "block.portal.trigger", 0.4F, 1.6F);
            }
            if (tick >= 16 && tick % 5 == 0) {
                w.playSound(start, "block.respawn_anchor.charge", 1.0F, 1.0F + (float)(tick - 16) * 0.04F);
            }
            Fx.get(Fx.Slot.FLOOR_RISE).spawn(start.clone().add(0.0, 0.2, 0.0), 2, 0.6, 0.05, 0.6, 0.06);
            return;
        }
        if (tick == 34) {
            player.setGameMode(GameMode.SPECTATOR);
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, 0, 0, 0));
            w.playSound(start, "block.portal.travel", 0.4F, 1.6F);
            w.playSound(start, "entity.enderman.teleport", 1.0F, 0.7F);
            Fx.get(Fx.Slot.FLOOR_SINK).spawn(start.clone().add(0.0, 0.5, 0.0), 50, 0.3, 0.6, 0.3, 0.2);
        }
        if (tick < 46) {
            Location sink = start.clone().subtract(0.0, (double)(tick - 34) * 0.15, 0.0);
            sink.setYaw(player.getLocation().getYaw());
            sink.setPitch(player.getLocation().getPitch());
            player.teleport(sink);
            return;
        }
        cancel();
        floor.remove();
        descent = Sequence.fromSky(plugin, player, dest, mode, plugin.settings.wings, () -> {
        Location at = player.getLocation();
        at.getWorld().playSound(at, "entity.player.levelup", 0.6F, 1.4F);
        player.stopSound("music.end");
        finish(0);
    });
    }

    void abort() {
        if (done) {
            return;
        }
        if (descent != null) {
            descent.abort();
            return;
        }
        cancel();
        floor.remove();
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        boolean arrived = player.teleport(dest) && player.getWorld().equals(dest.getWorld());
        player.setGameMode(mode);
        player.stopSound("music.end");
        finish(arrived);
    }

    private void finish() {
        finish(1);
    }

    private void finish(boolean arrived) {
        if (done) {
            return;
        }
        done = 1;
        if (arrived) {
            player.getPersistentDataContainer().remove(plugin.pendingKey);
        }
        onDone.run();
    }

    private void swirl(World w, Location c, double r) {
        if (r < 0.05) {
            return;
        }
        for (int arm = 0; arm < 2; arm++) {
            for (int j = 0; j < 5; j++) {
                double t = (double)j / 4.0;
                double a = (double)tick * 0.25 + (double)arm * 3.141592653589793 + t * 2.2;
                double rad = r * (0.25 + 0.8 * t);
                Fx.get(Fx.Slot.RIFT_SWIRL).spawn(c.clone().add(Math.cos(a) * rad, 0.0, Math.sin(a) * rad), 1, 0.0, 0.0, 0.0, 0.0, t);
            }
        }
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0F, Math.max(0.0F, (t - a) / (b - a)));
    }

    private static float outBack(float x) {
        if (x <= 0.0F) {
            return 0.0F;
        }
        float c1 = 1.70158F;
        float c3 = c1 + 1.0F;
        return 1.0F + c3 * (float)Math.pow((double)(x - 1.0F), 3.0) + c1 * (float)Math.pow((double)(x - 1.0F), 2.0);
    }
}