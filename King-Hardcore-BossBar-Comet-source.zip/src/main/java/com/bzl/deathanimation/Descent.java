// by decompiler.cc
package com.bzl.deathanimation;

import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

final class Descent extends BukkitRunnable implements Sequence {
    private static final int OPEN = 6;
    private static final int SKY_CLOSE = 34;
    private static final int TIMEOUT = 300;
    private static final double MAX_DROP = 22.0;
    private final Player player;
    private final Location dest;
    private final Location skyAt;
    private final World world;
    private final Runnable onLand;
    private Rift sky;
    private int tick;
    private boolean done;
    private boolean arrived = 1;
    private final NamespacedKey pendingKey;

    Descent(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, Runnable onLand) {
        this.player = player;
        pendingKey = plugin.pendingKey;
        player.getPersistentDataContainer().set(pendingKey, PersistentDataType.STRING, mode.name() + ";" + Nebula.serialize(dest));
        this.dest = dest.clone();
        world = dest.getWorld();
        this.onLand = onLand;
        double drop = clearAbove(dest);
        skyAt = dest.clone().add(0.0, drop, 0.0);
        skyAt.setPitch(drop > 3.0 ? 60.0F : 0.0F);
        player.teleport(skyAt);
        player.setGameMode(mode);
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 300, 0, 0, 0, 0));
        player.setFallDistance(0.0F);
        sky = new Rift(skyAt.clone().add(0.0, 2.2, 0.0), 1.6F, 0);
        world.playSound(skyAt, "block.end_portal.spawn", 0.5F, 1.4F);
        world.playSound(skyAt, "entity.enderman.teleport", 1.0F, 0.8F);
        world.playSound(skyAt, "block.beacon.activate", 1.0F, 1.2F);
        Fx.get(Fx.Slot.RIFT_OPEN).spawn(skyAt.clone().add(0.0, 2.0, 0.0), 60, 0.5, 0.2, 0.5, 0.2);
        player.playSound(player, "item.elytra.flying", 0.45F, 1.25F);
        runTaskTimer(plugin, 1L, 1L);
    }

    public void run() {
        tick++;
        if (!player.isOnline()) {
            abort();
            return;
        }
        if (sky != null) {
            if (tick < 34) {
                sky.size(outBack(k((float)tick, 0.0F, 6.0F)), 2, tick);
            } else {
                label0: {
                    if (tick <= 46) {
                        sky.size(1.0F - inCubic(k((float)tick, 34.0F, 46.0F)), 2, tick);
                        break label0;
                    }
                    sky.remove();
                    sky = null;
                    world.playSound(skyAt, "block.beacon.deactivate", 0.8F, 1.4F);
                }
            }
            if (sky != null) {
                swirl(skyAt.clone().add(0.0, 2.1, 0.0), 1.6);
            }
        }
        Location pos = player.getLocation();
        double above = pos.getY() - dest.getY();
        boolean grounded = player.isOnGround();
        if (grounded && tick > 2 || (above <= 0.05 || tick > 300)) {
            land();
            return;
        }
        double vy = -Math.min(0.45, 0.07 + above * 0.018);
        player.setVelocity(new Vector((dest.getX() - pos.getX()) * 0.15, vy, (dest.getZ() - pos.getZ()) * 0.15));
        player.setFallDistance(0.0F);
        Fx.get(Fx.Slot.DESCENT_TRAIL).spawn(pos.clone().add(0.0, 1.0, 0.0), 4, 0.28, 0.55, 0.28, 0.01);
        double ringR = 1.2 + Math.min(1.5, above * 0.08);
        int i = 0;
        for (; tick % 2 == 0 && i < 18; i++) {
            double a = (double)tick * 0.12 + (double)i * 3.141592653589793 * 2.0 / 18.0;
            Fx.get(Fx.Slot.LANDING_RING).spawn(dest.clone().add(Math.cos(a) * ringR, 0.1, Math.sin(a) * ringR), 1, 0.0, 0.0, 0.0, 0.0);
        }
        if (sky != null) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            for (i = 0; i < 3; i++) {
                Fx.get(Fx.Slot.LANDING_BEAM).spawn(dest.clone().add(r.nextDouble(-0.3, 0.3), r.nextDouble(0.0, skyAt.getY() - dest.getY() + 2.0), r.nextDouble(-0.3, 0.3)), 1, 0.0, 0.0, 0.0, 0.005);
            }
        }
    }

    private void land() {
        Location at = player.getLocation();
        for (int i = 0; i < 24; i++) {
            double a = (double)i * 3.141592653589793 * 2.0 / 24.0;
            Location ring = at.clone().add(Math.cos(a) * 0.4, 0.1, Math.sin(a) * 0.4);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(ring, 0, Math.cos(a), 0.06, Math.sin(a), 0.25);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(ring, 0, Math.cos(a), 0.06, Math.sin(a), 0.25);
        }
        Fx.get(Fx.Slot.FLASH).spawn(at.clone().add(0.0, 1.0, 0.0), 1, 0.0, 0.0, 0.0, 0.0);
        world.playSound(at, "block.respawn_anchor.deplete", 1.0F, 1.2F);
        world.playSound(at, "block.amethyst_block.resonate", 1.0F, 1.0F);
        end();
    }

    public void abort() {
        if (done) {
            return;
        }
        arrived = player.teleport(dest) && player.getWorld().equals(dest.getWorld());
        end();
    }

    private void end() {
        if (done) {
            return;
        }
        done = 1;
        cancel();
        if (arrived) {
            player.getPersistentDataContainer().remove(pendingKey);
        }
        if (sky != null) {
            sky.remove();
        }
        player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        player.setFallDistance(0.0F);
        player.stopSound("item.elytra.flying");
        onLand.run();
    }

    static double clearAbove(Location dest) {
        Location eye = dest.clone().add(0.0, 1.8, 0.0);
        RayTraceResult hit = dest.getWorld().rayTraceBlocks(eye, new Vector(0, 1, 0), 26.0, FluidCollisionMode.ALWAYS, 1);
        double $stack0 = hit == null ? 26.0 : hit.getHitPosition().getY() - eye.getY();
        double room = $stack0;
        double drop = Math.min(22.0, room - 4.0);
        $stack0 = drop < 3.0 ? 0.0 : drop;
        return $stack0;
    }

    private void swirl(Location c, double r) {
        for (int arm = 0; arm < 2; arm++) {
            for (int j = 0; j < 5; j++) {
                double t = (double)j / 4.0;
                double a = (double)tick * 0.25 + (double)arm * 3.141592653589793 + t * 2.2;
                double rad = r * (0.25 + 0.8 * t);
                Fx.get(Fx.Slot.RIFT_SWIRL).spawn(c.clone().add(Math.cos(a) * rad, 0.0, Math.sin(a) * rad), 1, 0.0, 0.0, 0.0, 0.0, t);
            }
        }
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0F, Math.max(0.0F, (t - a) / (b - a)));
    }

    private static float inCubic(float x) {
        return x * x * x;
    }

    private static float outBack(float x) {
        if (x <= 0.0F) {
            return 0.0F;
        }
        float c1 = 1.70158F;
        float c3 = c1 + 1.0F;
        return 1.0F + c3 * (float)Math.pow((double)(x - 1.0F), 3.0) + c1 * (float)Math.pow((double)(x - 1.0F), 2.0);
    }
}