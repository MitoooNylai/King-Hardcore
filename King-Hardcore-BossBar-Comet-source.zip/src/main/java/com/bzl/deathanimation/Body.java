// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.Location;
import org.bukkit.entity.Player;

interface Body {
    boolean MANNEQUIN = classExists("org.bukkit.entity.Mannequin");

    void pose(Body.Stage stage, float f, float[] floatArray, double d, double d2, double d3, float f2);

    void remove();

    boolean ready();

    static Body create(Location feet, float yaw, Player owner, Puppet.Colors colors, String type) {
        if ("blocks".equals(type) || !MANNEQUIN) {
            return new Puppet(feet, yaw, owner, colors);
        }
        return create(feet, yaw, owner, colors);
    }

    static Body create(Location feet, float yaw, Player owner, Puppet.Colors colors) {
        return MANNEQUIN ? new MannequinBody(feet, yaw, owner) : new Puppet(feet, yaw, owner, colors);
    }

    private static boolean classExists(String name) {
        try {
            Class.forName(name);
            int $stack0 = 1;
        } catch (ClassNotFoundException e) {
            return 0;
        }
    }

}