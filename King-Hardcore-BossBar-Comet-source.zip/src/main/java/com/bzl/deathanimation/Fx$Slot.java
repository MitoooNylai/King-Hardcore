// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.Material;

static enum Slot {
    BODY_FALL("body-fall", "Debu saat badan jatuh ke tanah", Material.COARSE_DIRT), STONE_TRAIL("stone-trail", "Jejak api batu yang jatuh dari langit", Material.BLAZE_POWDER), STONE_IMPACT("stone-impact", "Ledakan saat batu menghantam tanah", Material.TNT), STONE_IMPACT_RING("stone-impact-ring", "Cincin debu dari hantaman batu", Material.GRAY_DYE), STONE_LIFTOFF("stone-liftoff", "Serpihan saat batu terangkat", Material.COBBLED_DEEPSLATE), STONE_FLIGHT("stone-flight", "Jejak batu yang terbang ke portal", Material.FEATHER), STONE_LOCK("stone-lock", "Kilau saat batu terpasang", Material.AMETHYST_SHARD), STEPS_DEBRIS("steps-debris", "Debu tangga yang naik dari tanah", Material.DEEPSLATE_TILES), PORTAL_CHARGE("portal-charge", "Energi yang terkumpul sebelum menyala", Material.GLOWSTONE_DUST), PORTAL_STREAM("portal-stream", "Partikel yang tersedot ke portal", Material.ENDER_PEARL), PORTAL_IGNITE("portal-ignite", "Semburan saat portal menyala", Material.FIRE_CHARGE), SHOCKWAVE_RING("shockwave-ring", "Gelombang kejut di bidang portal", Material.HEART_OF_THE_SEA), SHOCKWAVE_GROUND("shockwave-ground", "Gelombang kejut di tanah", Material.WHITE_WOOL), PORTAL_HALO("portal-halo", "Cahaya lembut di tepi portal", Material.LIGHT_BLUE_DYE), PORTAL_SPIRAL("portal-spiral", "Spiral di tepi portal", Material.STRING), PORTAL_SPARKLE("portal-sparkle", "Kilau acak di tepi portal", Material.GLOW_INK_SAC), PORTAL_VORTEX("portal-vortex", "Pusaran galaksi di tengah portal", Material.ENDER_EYE), PORTAL_CLOSE("portal-close", "Semburan saat portal tertutup", Material.END_ROD), BODY_GETUP("body-getup", "Aura saat badan bangun", Material.SUGAR), BODY_HIT("body-hit", "Hembusan saat badan dihantam dari belakang", Material.WIND_CHARGE), BODY_TRAIL("body-trail", "Jejak badan yang tersedot ke portal", Material.GHAST_TEAR), BODY_ENTER("body-enter", "Semburan saat badan masuk portal", Material.NETHER_STAR), FLASH("flash", "Kilatan putih (portal, mendarat)", Material.GLOWSTONE), RIFT_SWIRL("rift-swirl", "Pusaran portal kecil (lantai / langit)", Material.PRISMARINE_CRYSTALS), RIFT_OPEN("rift-open", "Semburan saat portal langit terbuka", Material.END_CRYSTAL), FLOOR_RISE("floor-rise", "Cahaya naik dari portal lantai Nebula", Material.BEACON), FLOOR_SINK("floor-sink", "Semburan saat tenggelam ke portal lantai", Material.ENDER_PEARL), DESCENT_TRAIL("descent-trail", "Jejak badan yang turun dari langit", Material.PHANTOM_MEMBRANE), LANDING_RING("landing-ring", "Lingkaran titik mendarat", Material.LIGHT_BLUE_CARPET), LANDING_BEAM("landing-beam", "Sorot cahaya dari portal ke tanah", Material.SPECTRAL_ARROW), LANDING_SHOCKWAVE("landing-shockwave", "Gelombang saat mendarat", Material.SLIME_BALL), WINGS("wings", "Sayap dewi (warna dari pangkal ke ujung)", Material.ELYTRA), WING_TIPS("wing-tips", "Cahaya di ujung sayap", Material.END_ROD), WINGS_OPEN("wings-open", "Semburan saat sayap terbuka penuh", Material.TOTEM_OF_UNDYING), WING_BEAT("wing-beat", "Hembusan setiap kepakan sayap", Material.FEATHER), WINGS_BURST("wings-burst", "Sayap pecah jadi bulu", Material.WHITE_DYE), HALO("halo", "Halo di atas kepala", Material.GOLD_NUGGET), NEBULA_ARRIVE("nebula-arrive", "Cahaya saat mendarat di Nebula", Material.ECHO_SHARD), NEBULA_STARS("nebula-stars", "Bintang yang melayang di Nebula", Material.NETHER_STAR);

    final String key;
    final String description;
    final Material icon;

    private Slot(String key, String description, Material icon) {
        super(string, i);
        this.key = key;
        this.description = description;
        this.icon = icon;
    }

}