// by decompiler.cc
package com.bzl.deathanimation;

import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import org.joml.Matrix4f;

final class Cinematic extends BukkitRunnable {
    private static final int FALL_END = 14;
    private static final int WAKE = 54;
    private static final int CUT2 = 109;
    private static final int CUT3 = 200;
    private static final int STONE_FALL = 58;
    private static final int DRAW = 92;
    private static final int ASSEMBLE = 112;
    private static final int STEPS = 120;
    private static final int CONVERGE = 168;
    private static final int IGNITE = 178;
    private static final int GETUP_END = 235;
    private static final int PULL_START = 243;
    private static final int PULL_END = 343;
    private static final int CLOSE_END = 357;
    private static final int DONE = 377;
    private static final int[] CUTS = new int[]{54, 109, 200};
    private static final int[][] EYES_CLOSED = new int[][]{new int[]{16, 20}, new int[]{28, 33}, new int[]{40, 54}};
    private static final Display.Brightness PITCH_BLACK = new Display.Brightness(0, 0);
    private static final float[] STANDING = new float[]{0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F};
    private static final float[] LYING = new float[]{-90.0F, -30.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.13F};
    private static final float[] KNEEL = new float[]{-45.0F, -15.0F, 20.0F, -35.0F, -35.0F, 15.0F, 0.05F};
    private static final float[] BLOWN = new float[]{30.0F, 75.0F, 15.0F, 25.0F, 12.0F, -25.0F, 0.8F};
    private final BzlDeathAnimation plugin;
    private final Player player;
    private final World world;
    private final Location feet;
    private final Location startEye;
    private final Location lyingEye;
    private final Location portalCenter;
    private final Location site;
    private final Vector forward;
    private final Vector right;
    private final Vector up = new Vector(0, 1, 0);
    private final Vector travel;
    private final GameMode originalMode;
    private final Body body;
    private final Portal portal;
    private final ItemDisplay camera;
    private final BlockDisplay lidTop;
    private final BlockDisplay lidBottom;
    private Location lastChase;
    private float lid;
    private double shake;
    private int tick;
    private boolean eyesClosed;
    private boolean finished;
    private int nextBeat = 15;

    Cinematic(BzlDeathAnimation plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        world = player.getWorld();
        feet = groundBelow(player);
        float yaw = feet.getYaw();
        forward = new Vector(-Math.sin(Math.toRadians((double)yaw)), 0.0, Math.cos(Math.toRadians((double)yaw)));
        right = forward.getCrossProduct(up).normalize();
        startEye = player.getEyeLocation();
        lyingEye = feet.clone().subtract(forward.clone().multiply(1.75)).add(0.0, 0.55, 0.0);
        site = feet.clone().add(forward.clone().multiply(plugin.settings.portalDistance));
        portalCenter = site.clone().add(0.0, plugin.settings.portalHeight, 0.0);
        travel = portalCenter.toVector().subtract(new Vector(0.0, 1.0, 0.0)).subtract(feet.toVector());
        Body b = null;
        Portal pt = null;
        ItemDisplay cam = null;
        BlockDisplay top = null;
        BlockDisplay bottom = null;
        try {
            b = Body.create(feet, yaw, player, plugin.skinOf(player), plugin.settings.body);
            pt = new Portal(portalCenter, yaw, plugin.settings.portalHeight, new Portal.Timing(58, 92, 112, 120, 178));
            cam = (ItemDisplay)world.spawn(startEye, ItemDisplay.class, d -> {
        d.setPersistent(0);
        d.addScoreboardTag("bda_fx");
        d.setTeleportDuration(3);
    });
            top = spawnLid();
            bottom = spawnLid();
        } catch (RuntimeException e) {
            if (b != null) {
                b.remove();
            }
            if (pt != null) {
                pt.remove();
            }
            if (cam != null) {
                cam.remove();
            }
            if (top != null) {
                top.remove();
            }
            if (bottom != null) {
                bottom.remove();
            }
            throw e;
        }
        body = b;
        portal = pt;
        camera = cam;
        lidTop = top;
        lidBottom = bottom;
        originalMode = player.getGameMode();
        player.getPersistentDataContainer().set(plugin.savedModeKey, PersistentDataType.STRING, originalMode.name());
        player.setGameMode(GameMode.SPECTATOR);
        moveFirstPerson(startEye, 0);
        world.playSound(feet, "entity.player.hurt", 1.0F, 0.8F);
        runTaskTimer(plugin, 1L, 1L);
    }

    private static Location groundBelow(Player player) {
        Location at = player.getLocation();
        boolean grounded = player.isOnGround();
        if (grounded || at.getBlock().isLiquid()) {
            return at;
        }
        RayTraceResult hit = at.getWorld().rayTraceBlocks(at.clone().add(0.0, 0.1, 0.0), new Vector(0, -1, 0), 40.0, FluidCollisionMode.ALWAYS, 1);
        if (hit == null) {
            return at;
        }
        Location ground = hit.getHitPosition().toLocation(at.getWorld());
        ground.setYaw(at.getYaw());
        ground.setPitch(at.getPitch());
        return ground;
    }

    private BlockDisplay spawnLid() {
        Location at = startEye.clone();
        at.setYaw(0.0F);
        at.setPitch(0.0F);
        return (BlockDisplay)world.spawn(at, BlockDisplay.class, d -> {
        d.setPersistent(0);
        d.addScoreboardTag("bda_fx");
        d.setBlock(Material.BLACK_CONCRETE.createBlockData());
        d.setBrightness(PITCH_BLACK);
        d.setTeleportDuration(2);
        d.setDisplayWidth(4.0F);
        d.setDisplayHeight(4.0F);
    });
    }

    public void run() {
        tick++;
        if (player.getSpectatorTarget() != camera) {
            plugin.watch(player, camera);
        }
        for (int cut : CUTS) {
            if (tick == cut - 1) {
                camera.setTeleportDuration(0);
            }
            if (tick == cut + 1) {
                camera.setTeleportDuration(3);
            }
        }
        if (tick <= 14) {
            fall();
        } else {
            label0: {
                if (tick < 54) {
                    lieAndBlink();
                    break label0;
                }
                if (tick == 54) {
                    wake();
                }
            }
        }
        if (tick >= 54) {
            if (tick < 357) {
                shake += (double)portal.update(tick, inCubic(k((float)tick, 343.0F, 357.0F))) * 0.35;
            } else if (tick == 357) {
                portal.remove();
                Fx.get(Fx.Slot.PORTAL_CLOSE).spawn(portalCenter, 30, 0.1, 0.1, 0.1, 0.2);
                world.playSound(portalCenter, "block.respawn_anchor.deplete", 0.8F, 1.5F);
            }
            buildEffects();
            bodyScene();
            directCamera();
        }
        if (tick >= 377) {
            finish(1);
        }
    }

    private void fall() {
        float f = (float)tick / 14.0F;
        f *= f;
        body.pose(Body.Stage.FALL, f, mix(STANDING, LYING, f), 0.0, 0.0, 0.0, 1.0F);
        Location eye = lerp(startEye, lyingEye, f);
        eye.setYaw(startEye.getYaw());
        eye.setPitch(lerp(startEye.getPitch(), -80.0F, f));
        moveFirstPerson(eye, 0);
        if (tick == 14) {
            world.playSound(feet, "entity.generic.big_fall", 1.0F, 0.9F);
            player.playSound(player, "block.beacon.ambient", 0.5F, 2.0F);
            Fx.get(Fx.Slot.BODY_FALL).spawn(feet, 12, 0.6, 0.05, 0.6, 0.02);
        }
    }

    private void lieAndBlink() {
        boolean closed = 0;
        Location eye = EYES_CLOSED;
        int i = eye.length;
        int i2 = 0;
        boolean $stack0;
        int $stack1;
        for (; i2 < i; i2++) {
            int[] w = eye[i2];
            $stack0 = closed;
            $stack1 = tick >= w[0] && tick < w[1];
            closed = $stack0 | $stack1;
        }
        if (tick >= nextBeat) {
            Sfx.heartbeat(player, 1.0F, 1.0F);
            $stack0 = this;
            $stack1 = tick;
            int $stack2;
            if (tick < 30) {
                $stack2 = 14;
            } else {
                label0: {
                    if (tick < 44) {
                        $stack2 = 17;
                        break label0;
                    }
                    $stack2 = 21;
                }
            }
            $stack0.nextBeat = $stack1 + $stack2;
        }
        if (!closed && eyesClosed) {
            Sfx.breatheIn(player);
        }
        eyesClosed = closed;
        eye = lyingEye.clone();
        eye.setYaw(startEye.getYaw());
        eye.setPitch(-80.0F + (float)Math.sin((double)tick * 0.12) * 2.5F);
        moveFirstPerson(eye, closed);
    }

    private void moveFirstPerson(Location eye, boolean closed) {
        camera.teleport(eye);
        lid = closed ? Math.min(1.0F, lid + 0.45F) : Math.max(0.0F, lid - 0.3F);
        float gap = (1.0F - smooth(lid)) * 0.8F;
        Matrix4f face = new Matrix4f().rotateY((float)-Math.toRadians((double)eye.getYaw())).rotateX((float)Math.toRadians((double)eye.getPitch()));
        Puppet.apply(lidTop, new Matrix4f(face).translate(-1.2F, gap - 0.01F, 0.2F).scale(2.4F, 0.8F, 0.01F), 2);
        Puppet.apply(lidBottom, new Matrix4f(face).translate(-1.2F, -gap - 0.79F, 0.2F).scale(2.4F, 0.8F, 0.01F), 2);
        Location at = eye.clone();
        at.setYaw(0.0F);
        at.setPitch(0.0F);
        lidTop.teleport(at);
        lidBottom.teleport(at);
    }

    private void wake() {
        lidTop.remove();
        lidBottom.remove();
        world.playSound(site, "entity.wither.spawn", 0.35F, 1.6F);
        world.playSound(site, "entity.lightning_bolt.thunder", 0.6F, 0.8F);
        Sfx.minor(site, "block.note_block.bell", 0.7F, 1);
        world.playSound(site, "item.elytra.flying", 0.35F, 1.3F);
        if (plugin.settings.music) {
            player.playSound(player, "music.end", 0.9F, 1.0F);
        }
    }

    private void directCamera() {
        Location pos;
        Location look;
        float t;
        if (tick < 109) {
            t = smooth(k((float)tick, 54.0F, 103.0F));
            pos = feet.clone().subtract(forward.clone().multiply(2.5)).add(right.clone().multiply(3)).add(0.0, (double)lerp(9.0F, 2.2F, t), 0.0);
            look = site.clone().add(0.0, (double)lerp(30.0F, 1.0F, t), 0.0);
        } else {
            label0: {
                if (tick < 200) {
                    t = smooth(k((float)tick, 109.0F, 200.0F));
                    pos = portalCenter.clone().subtract(forward.clone().multiply(lerp(11.0F, 6.5F, t))).add(right.clone().multiply(lerp(2.5F, 0.6F, t))).add(0.0, (double)lerp(-1.3F, -0.4F, t), 0.0);
                    look = portalCenter.clone().add(0.0, 0.3, 0.0);
                    break label0;
                }
                if (tick < 343) {
                    Location at = bodyAt();
                    Location side = feet.clone().add(right.clone().multiply(3.4)).subtract(forward.clone().multiply(0.6)).add(forward.clone().multiply(0.6 * (double)k((float)tick, 200.0F, 243.0F))).add(0.0, 1.1, 0.0);
                    Location sideLook = feet.clone().add(0.0, 0.8, 0.0);
                    Location chase = at.clone().subtract(forward.clone().multiply(4.2)).add(right.clone().multiply(1.4)).add(0.0, 0.6, 0.0);
                    Location chaseLook = lerp(at, portalCenter, 0.65F);
                    float b = smooth(k((float)tick, 239.0F, 259.0F));
                    pos = lerp(side, chase, b);
                    look = lerp(sideLook, chaseLook, b);
                    lastChase = pos.clone();
                    break label0;
                }
                pos = lastChase.clone().subtract(forward.clone().multiply(1.5 * (double)k((float)tick, 343.0F, 377.0F)));
                look = portalCenter;
            }
        }
        if (tick >= 109) {
            pos = pos.clone().add(Math.sin((double)tick * 0.13) * 0.06, Math.sin((double)tick * 0.17 + 1.0) * 0.05, Math.sin((double)tick * 0.11 + 2.0) * 0.06);
        }
        if (!plugin.settings.screenShake) {
            shake = 0.0;
        }
        if (shake > 0.01) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            pos = pos.clone().add(r.nextDouble(-shake, shake), r.nextDouble(-shake, shake), r.nextDouble(-shake, shake));
            shake *= 0.8;
        }
        place(pos, look);
    }

    private void place(Location pos, Location look) {
        Vector off = pos.toVector().subtract(look.toVector());
        double len = off.length();
        if (len > 0.01) {
            RayTraceResult hit = world.rayTraceBlocks(look, off.clone().normalize(), len, FluidCollisionMode.NEVER, 1);
            if (hit != null) {
                off.normalize().multiply(Math.max(0.8, hit.getHitPosition().distance(look.toVector()) - 0.4));
            }
        }
        Location cam = look.clone().add(off);
        camera.teleport(cam.setDirection(look.toVector().subtract(cam.toVector())));
    }

    private void buildEffects() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int i;
        if (tick >= 168 && tick < 178) {
            if (tick == 168) {
                world.playSound(portalCenter, "block.beacon.power_select", 1.0F, 0.5F);
                world.playSound(portalCenter, "block.conduit.ambient.short", 1.0F, 0.8F);
            }
            if ((tick - 168) % 3 == 0) {
                world.playSound(portalCenter, "block.respawn_anchor.charge", 1.0F, 1.2F + (float)(tick - 168) * 0.06F);
            }
            for (i = 0; i < 6; i++) {
                suck(Fx.Slot.PORTAL_STREAM, onPortal(r.nextDouble(6.283185307179586), 2.4 + r.nextDouble(1.2)), portalCenter, 0.04);
            }
            Fx.get(Fx.Slot.PORTAL_CHARGE).spawn(portalCenter, 3, 0.1, 0.1, 0.1, 0.01);
        }
        Location from;
        if (tick == 178) {
            flash(portalCenter);
            Fx.get(Fx.Slot.PORTAL_IGNITE).spawn(portalCenter, 120, 0.25, 0.25, 0.25, 0.27);
            for (i = 0; i < 36; i++) {
                double a = (double)i * 3.141592653589793 * 2.0 / 36.0;
                Vector dir = right.clone().multiply(Math.cos(a)).add(new Vector(0.0, Math.sin(a), 0.0));
                from = portalCenter.clone().add(dir.clone().multiply(1.6));
                Fx.get(Fx.Slot.SHOCKWAVE_RING).spawn(from, 0, dir.getX(), dir.getY(), dir.getZ(), 0.5);
                Vector flat = right.clone().multiply(Math.cos(a)).add(forward.clone().multiply(Math.sin(a)));
                Fx.get(Fx.Slot.SHOCKWAVE_GROUND).spawn(site.clone().add(flat).add(0.0, 0.2, 0.0), 0, flat.getX(), 0.0, flat.getZ(), 0.6);
            }
            world.playSound(portalCenter, "block.end_portal.spawn", 0.6F, 1.2F);
            Sfx.major(portalCenter, "block.note_block.bell", 1.0F, 6);
            world.playSound(portalCenter, "item.trident.thunder", 0.8F, 1.0F);
            world.playSound(portalCenter, "entity.warden.sonic_boom", 0.4F, 1.4F);
            world.playSound(portalCenter, "block.respawn_anchor.set_spawn", 1.0F, 0.9F);
            world.playSound(portalCenter, "block.conduit.activate", 1.0F, 0.9F);
            world.playSound(portalCenter, "block.beacon.activate", 1.0F, 1.2F);
            world.playSound(portalCenter, "entity.generic.explode", 0.6F, 1.6F);
            shake += 0.5;
        }
        if (tick > 178 && tick < 343) {
            if ((tick - 178) % 30 == 0) {
                world.playSound(portalCenter, "block.respawn_anchor.ambient", 1.0F, 0.8F);
            }
            if ((tick - 178) % 50 == 25) {
                world.playSound(portalCenter, "block.beacon.ambient", 1.0F, 1.1F);
            }
            vortex(Math.min(1.0F, k((float)tick, 183.0F, 194.0F)));
            for (i = 0; i < 12; i++) {
                Fx.get(Fx.Slot.PORTAL_HALO).spawn(onPortal(r.nextDouble(6.283185307179586), 1.62 + r.nextDouble(0.4)), 1, 0.0, 0.0, 0.05, 0.0);
            }
            for (int arm = 0; arm < 2; arm++) {
                Fx.get(Fx.Slot.PORTAL_SPIRAL).spawn(onPortal(-((double)tick * 0.25 + (double)arm * 3.141592653589793), 1.3), 1, 0.0, 0.0, 0.0, 0.0);
            }
            for (i = 0; i < 3; i++) {
                from = onPortal(r.nextDouble(6.283185307179586), 2.6 + r.nextDouble()).add(forward.clone().multiply(r.nextDouble(-0.6, 0.2)));
                suck(Fx.Slot.PORTAL_STREAM, from, portalCenter, 0.035);
            }
            Fx.get(Fx.Slot.PORTAL_SPARKLE).spawn(onPortal(r.nextDouble(6.283185307179586), 1.7), 1, 0.05, 0.05, 0.05, 0.0);
        } else if (tick >= 343 && tick < 357) {
            for (i = 0; i < 10; i++) {
                suck(Fx.Slot.PORTAL_STREAM, onPortal(r.nextDouble(6.283185307179586), 2.0 + r.nextDouble(1.5)), portalCenter, 0.045);
            }
        }
    }

    private void vortex(float size) {
        if (size <= 0.0F) {
            return;
        }
        Vector toViewer = forward.clone().multiply(-0.08);
        Fx fx = Fx.get(Fx.Slot.PORTAL_VORTEX);
        for (int arm = 0; arm < 4; arm++) {
            for (int j = 0; j < 7; j++) {
                float t = (float)j / 6.0F;
                double a = (double)tick * 0.18 + (double)arm * 3.141592653589793 / 2.0 + (double)t * 2.4;
                double r = (0.15 + (double)t * 1.25) * (double)size;
                fx.spawn(onPortal(a, r).add(toViewer), 1, 0.02, 0.02, 0.0, 0.0, (double)t);
            }
        }
    }

    private float pullTravel() {
        float q = k((float)tick, 246.0F, 343.0F);
        return q < 0.5F ? 2.0F * q * q : 1.0F - 2.0F * (1.0F - q) * (1.0F - q);
    }

    private Location bodyAt() {
        return feet.clone().add(travel.clone().multiply(pullTravel())).add(0.0, 1.0, 0.0);
    }

    private void bodyScene() {
        if (tick < 200 || tick > 343) {
            return;
        }
        if (tick == 343) {
            body.remove();
            flash(portalCenter);
            Fx.get(Fx.Slot.BODY_ENTER).spawn(portalCenter, 110, 0.4, 0.4, 0.25, 0.3);
            world.playSound(portalCenter, "entity.enderman.teleport", 1.0F, 0.6F);
            world.playSound(portalCenter, "entity.firework_rocket.twinkle", 1.0F, 0.8F);
            world.playSound(portalCenter, "block.portal.travel", 0.25F, 1.4F);
            world.playSound(portalCenter, "block.respawn_anchor.deplete", 1.0F, 0.7F);
            world.playSound(portalCenter, "block.beacon.deactivate", 1.0F, 0.8F);
            world.playSound(portalCenter, "block.end_gateway.spawn", 0.5F, 1.3F);
            return;
        }
        Location at = bodyAt();
        float[] p;
        float $stack0;
        if (tick < 243) {
            float g = k((float)tick, 200.0F, 235.0F);
            $stack0 = g < 0.5F ? mix(LYING, KNEEL, smooth(g * 2.0F)) : mix(KNEEL, STANDING, smooth((g - 0.5F) * 2.0F));
            p = $stack0;
            body.pose(Body.Stage.GET_UP, g, p, 0.0, 0.0, 0.0, 1.0F);
            if (tick == 202) {
                Sfx.heartbeat(player, 1.0F, 1.1F);
            }
            if (tick == 208) {
                Sfx.breatheIn(player);
            }
            if (tick == 215) {
                Sfx.breatheOut(player);
            }
            if (tick == 224) {
                Sfx.breatheIn(player);
            }
            if (tick == 231) {
                Sfx.breatheOut(player);
            }
            if (tick == 220) {
                world.playSound(feet, "item.armor.equip_generic", 1.0F, 0.8F);
            }
            if (tick % 4 == 0) {
                Fx.get(Fx.Slot.BODY_GETUP).spawn(at, 2, 0.4, 0.6, 0.4, 0.0);
            }
            return;
        }
        float jolt = 1.0F - (float)Math.pow((double)(1.0F - k((float)tick, 243.0F, 248.0F)), 3.0);
        float q = k((float)tick, 246.0F, 343.0F);
        float e = pullTravel();
        p = mix(STANDING, BLOWN, jolt);
        $stack0 = q > 0.0F ? (float)Math.sin((double)tick * 0.35) * (1.0F - q) : 0.0F;
        float wob = $stack0;
        p[0] += wob * 2.0F + 10.0F * smooth(q);
        p[1] += wob * 8.0F;
        p[3] += wob * 5.0F;
        p[4] -= wob * 5.0F;
        p[6] += (float)Math.sin((double)q * 3.141592653589793) * 0.35F;
        body.pose(Body.Stage.PULL, q, p, travel.getX() * (double)e, travel.getY() * (double)e, travel.getZ() * (double)e, 1.0F - inCubic(k(q, 0.7F, 1.0F)) * 0.98F);
        if (tick == 243) {
            world.playSound(at, "entity.breeze.wind_burst", 1.0F, 0.7F);
            world.playSound(at, "item.elytra.flying", 0.5F, 1.4F);
            Location behind = at.clone().subtract(forward.clone().multiply(0.6));
            Fx.get(Fx.Slot.BODY_HIT).spawn(behind, 20, 0.2, 0.4, 0.2, 0.07);
            shake += 0.25;
        }
        if (tick == 246 + Math.round(48.5F)) {
            world.playSound(at, "entity.breeze.wind_burst", 1.0F, 1.1F);
            world.playSound(at, "entity.phantom.swoop", 0.8F, 0.7F);
            shake += 0.15;
        }
        Fx.get(Fx.Slot.BODY_TRAIL).spawn(at, 4, 0.22, 0.45, 0.22, 0.01);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        suck(Fx.Slot.PORTAL_STREAM, at.clone().add(r.nextDouble(-0.3, 0.3), r.nextDouble(-0.6, 0.6), 0.0), portalCenter, 0.04);
    }

    private static void suck(Fx.Slot slot, Location from, Location to, double speed) {
        Vector v = to.toVector().subtract(from.toVector()).multiply(speed);
        Fx.get(slot).spawn(from, 0, v.getX(), v.getY(), v.getZ(), 1.0);
    }

    private Location onPortal(double a, double r) {
        return portalCenter.clone().add(right.clone().multiply(Math.cos(a) * r)).add(0.0, Math.sin(a) * r, 0.0);
    }

    private static void flash(Location at) {
        Fx.get(Fx.Slot.FLASH).spawn(at, 1, 0.0, 0.0, 0.0, 0.0);
    }

    void finish(boolean animate) {
        if (finished) {
            return;
        }
        finished = 1;
        cancel();
        plugin.running.remove(player.getUniqueId());
        body.remove();
        portal.remove();
        for (Display d : new Display[]{camera, lidTop, lidBottom}) {
            d.remove();
        }
        BzlDeathAnimation.unwatch(player);
        player.setGameMode(originalMode);
        player.getPersistentDataContainer().remove(plugin.savedModeKey);
        plugin.nebula.imprison(player, feet, animate, originalMode);
    }

    private static float[] mix(float[] a, float[] b, float t) {
        float[] out = new float[a.length];
        for (int i = 0; i < a.length; i++) {
            out[i] = a[i] + (b[i] - a[i]) * t;
        }
        return out;
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0F, Math.max(0.0F, (t - a) / (b - a)));
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static Location lerp(Location a, Location b, float t) {
        return a.clone().add(b.toVector().subtract(a.toVector()).multiply(t));
    }

    private static float smooth(float x) {
        return x * x * (3.0F - 2.0F * x);
    }

    private static float inCubic(float x) {
        return x * x * x;
    }

}