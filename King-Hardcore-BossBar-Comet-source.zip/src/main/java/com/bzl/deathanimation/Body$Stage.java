// by decompiler.cc
package com.bzl.deathanimation;

public static enum Stage {
    FALL, GET_UP, PULL, DESCEND, LAND, LOOK;

    private Stage() {
        super(string, i);
    }

}