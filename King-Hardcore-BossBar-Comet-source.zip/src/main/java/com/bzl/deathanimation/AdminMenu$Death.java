// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.entity.Player;

static final class Death extends Menu {
    Death(BzlDeathAnimation plugin, Player viewer) {
        super(plugin, viewer);
    }

    Component title() {
        return plugin.settings.msg("menu.title.death", new TagResolver[0]);
    }

    int rows() {
        return 5;
    }

    void draw() {
        Settings s = plugin.settings;
        header(Material.WITHER_SKELETON_SKULL, "Kematian", new String[]{"Yang terjadi saat pemain", "hampir mati."});
        toggle(10, Material.END_CRYSTAL, "Animasi Kematian", "death-animation.enabled", s.enabled, new String[]{"Saklar utama plugin."});
        toggle(11, Material.TOTEM_OF_UNDYING, "Totem Menyelamatkan", "death-animation.totem-saves-player", s.totemSaves, new String[]{"Totem di tangan = selamat cara", "vanilla, tanpa animasi."});
        cycle(12, Material.ARMOR_STAND, "Model Badan", "death-animation.body", s.body, List.of("auto", "mannequin", "blocks"), List.of("Otomatis", "Mannequin (skin penuh, 1.21.9+)", "Blok (semua versi)"), new String[]{"Kembaran pemain di sinematik.", "Blok = pakai jika klien tidak", "menampilkan mannequin."});
        number(14, Material.ENDER_EYE, "Jarak Portal", "death-animation.portal-distance", s.portalDistance, 0.5, 2.0, 2.0, 12.0, 0, " blok", new String[]{"Jarak portal di depan pemain."});
        number(15, Material.LADDER, "Tinggi Portal", "death-animation.portal-height", s.portalHeight, 0.5, 1.0, 1.0, 8.0, 0, " blok", new String[]{"Tinggi pusat portal dari tanah."});
        String world = viewer.getWorld().getName();
        boolean off = s.disabledWorlds.contains(world.toLowerCase(Locale.ROOT));
        List lore = gray(new String[]{"Animasi di dunia tempatmu berdiri.", ""});
        List<String> $stack0 = lore;
        String $stack1 = off ? "<#FF6B6B>● DIKECUALIKAN" : "<#5CFF8A>● AKTIF";
        $stack0.add("<dark_gray>Status: " + $stack1);
        lore.add("");
        lore.add("<gray>Dunia dikecualikan:");
        List listed = plugin.getConfig().getStringList("death-animation.disabled-worlds");
        if (listed.isEmpty()) {
            lore.add("<dark_gray>  (tidak ada)");
        }
        List causes = listed.iterator();
        String w;
        while (causes.hasNext()) {
            w = (String)causes.next();
            lore.add("<dark_gray>  • <white>" + Menu.esc(w));
        }
        lore.add("");
        $stack0 = lore;
        $stack1 = off ? "mengaktifkan" : "mengecualikan";
        $stack0.add("<#7FE3FF>» <gray>Klik untuk " + $stack1 + " dunia ini");
        $stack0 = this;
        $stack1 = 16;
        $stack0.set($stack1, item(off ? Material.DEAD_BUSH : Material.GRASS_BLOCK, "<#B8F1FF><bold>Dunia: " + Menu.esc(world), lore), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        List worlds = new ArrayList(listed);
        if (off) {
            worlds.removeIf(w -> w.equalsIgnoreCase(world));
        } else {
            worlds.add(world);
        }
        save("death-animation.disabled-worlds", worlds);
        sound("block.note_block.pling", off ? 1.6F : 0.7F);
    });
        causes = gray(new String[]{"Sebab kematian yang tidak memutar", "animasi (pemain mati biasa):", ""});
        for (String c : s.skipCauses) {
            causes.add("<dark_gray>  • <white>" + c);
        }
        causes.add("");
        causes.add("<dark_gray>Ubah di config.yml -> skip-causes");
        set(22, item(Material.BOOK, "<#B8F1FF><bold>Sebab yang Dilewati", causes));
        back(40, () -> new AdminMenu.Main(plugin, viewer));
    }
}