// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.entity.Player;

static final class NebulaPage extends Menu {
    NebulaPage(BzlDeathAnimation plugin, Player viewer) {
        super(plugin, viewer);
    }

    Component title() {
        return plugin.settings.msg("menu.title.nebula", new TagResolver[0]);
    }

    int rows() {
        return 5;
    }

    void draw() {
        Settings s = plugin.settings;
        header(Material.END_STONE, "Nebula", new String[]{"Dimensi void tempat pemain", "ditahan setelah mati."});
        number(10, Material.CLOCK, "Lama Hukuman", "nebula.duration-minutes", (double)s.durationMinutes, 1.0, 5.0, 1.0, 1440.0, 1, " menit", new String[]{"Berapa lama pemain ditahan.", "Tetap berjalan saat offline."});
        cycle(11, Material.RED_BED, "Tujuan Pulang", "nebula.return-to", s.returnTo, List.of("death", "spawn"), List.of("Tempat mati", "Kasur / spawn dunia"), new String[]{"Ke mana pemain kembali."});
        cycle(12, Material.FILLED_MAP, "Gamemode di Nebula", "nebula.gamemode", s.nebulaMode.name(), List.of("ADVENTURE", "SURVIVAL", "CREATIVE"), List.of("Adventure", "Survival", "Creative"), new String[]{"Adventure = bisa jalan, tidak", "bisa merusak pulau."});
        number(13, Material.NAME_TAG, "Lama Judul NEBULA", "nebula.title.stay-ticks", (double)s.titleStay, 10.0, 40.0, 0.0, 400.0, 1, " tick", new String[]{"20 tick = 1 detik."});
        toggle(14, Material.GOLDEN_APPLE, "Pulihkan Saat Tiba", "nebula.heal-on-arrival", s.healOnArrival, new String[]{"Darah & lapar penuh saat masuk."});
        toggle(15, Material.ENDER_PEARL, "Blokir Teleport Keluar", "nebula.block-teleport-out", s.blockTeleport, new String[]{"/spawn, /home, /tpa ... ditolak.", "Bypass: bda.bypass.teleport"});
        List<String> cmds = new ArrayList<>(s.allowedCommands);
        cmds.sort(null);
        toggle(16, Material.COMMAND_BLOCK, "Blokir Command", "nebula.block-commands", s.blockCommands, new String[]{"Hanya command ini yang boleh:", "<white>/" + String.join(" /", cmds), "Bypass: bda.bypass.commands"});
        toggle(19, Material.ELYTRA, "Sinematik Masuk", "nebula.arrival-cinematic", s.arrivalCinematic, new String[]{"Badan jatuh dari portal langit", "ke pulau Nebula."});
        toggle(20, Material.FEATHER, "Sinematik Pulang", "nebula.release-cinematic", s.releaseCinematic, new String[]{"Portal lantai, lalu turun dari", "langit kembali ke dunia."});
        toggle(21, Material.AMETHYST_SHARD, "Partikel Ambient", "nebula.ambient-particles", s.ambientParticles, new String[]{"Debu bintang di sekitar pemain."});
        toggle(22, Material.BELL, "Suara Ambient", "nebula.ambient-sounds", s.ambientSounds, new String[]{"Gemuruh & bisikan dari jauh."});
        set(25, item(Material.END_PORTAL_FRAME, "<#B8F1FF><bold>Dunia Nebula", new String[]{"<gray>Nama: <white>" + Menu.esc(s.nebulaWorld), "", "<dark_gray>Ubah di config.yml -> nebula.world", "<dark_gray>(butuh restart server)"}));
        back(40, () -> new AdminMenu.Main(plugin, viewer));
    }
}