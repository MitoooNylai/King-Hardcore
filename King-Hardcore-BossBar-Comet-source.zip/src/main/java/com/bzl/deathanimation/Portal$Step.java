// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.entity.BlockDisplay;
import org.joml.Matrix4f;

private static record Step(BlockDisplay d, Matrix4f local) {
}