// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.joml.Matrix4f;

final class Rift {
    private static final int LAYERS = 24;
    private static final int NOTCHES = 10;
    private static final int RAYS = 8;
    private static final Display.Brightness FULL_BRIGHT = new Display.Brightness(15, 15);
    private static final Display.Brightness PORTAL_LIT = new Display.Brightness(10, 15);
    private static final Material[] BAND = new Material[]{Material.WHITE_CONCRETE, Material.LIGHT_BLUE_CONCRETE, Material.BLUE_CONCRETE, Material.POLISHED_DEEPSLATE};
    private static final float[] BAND_R = new float[]{1.0F, 1.12F, 1.22F, 1.38F};
    private final List<List<BlockDisplay>> bands = new ArrayList<>();
    private final List<BlockDisplay> notches = new ArrayList<>();
    private final List<BlockDisplay> rays = new ArrayList<>();
    private final List<BlockDisplay> all = new ArrayList<>();
    private final float radius;
    private final float facing;

    Rift(Location center, float radius, boolean seenFromAbove) {
        this.radius = radius;
        facing = seenFromAbove ? 1.0F : -1.0F;
        Location at = center.clone();
        at.setYaw(0.0F);
        at.setPitch(0.0F);
        try {
            int b = 0;
            int i;
            for (; b < BAND.length; b++) {
                List band = new ArrayList();
                for (i = 0; i < 24; i++) {
                    BlockDisplay d = spawn(at, BAND[b]);
                    if (b == 3) {
                        d.setBrightness(PORTAL_LIT);
                    }
                    band.add(d);
                }
                bands.add(band);
            }
            for (i = 0; i < 10; i++) {
                notches.add(spawn(at, Material.LIGHT_BLUE_CONCRETE));
            }
            for (i = 0; i < 8; i++) {
                rays.add(spawn(at, Material.END_ROD));
            }
            size(0.0F, 0, 0);
        } catch (RuntimeException e) {
            remove();
            throw e;
        }
    }

    private BlockDisplay spawn(Location at, Material m) {
        BlockDisplay d = (BlockDisplay)at.getWorld().spawn(at, BlockDisplay.class, e -> {
        e.setPersistent(0);
        e.addScoreboardTag("bda_fx");
        e.setBlock(m.createBlockData());
        e.setBrightness(FULL_BRIGHT);
    });
        all.add(d);
        return d;
    }

    void size(float s, int interp, int tick) {
        float pulse = Math.max(0.001F, s * (1.0F + 0.04F * (float)Math.sin((double)tick * 0.3)));
        Matrix4f flat = new Matrix4f().rotateX(-1.5707964F).scale(pulse);
        int $stack0 = interp == 0 || tick % 2 == 0;
        boolean bandsNow = $stack0;
        int b = 0;
        int i;
        float a;
        Matrix4f $stack1;
        int $stack2;
        for (; bandsNow && b < BAND.length; b++) {
            float r = radius * BAND_R[b];
            float z = facing * (0.18F - (float)b * 0.06F);
            for (i = 0; i < 24; i++) {
                a = (float)((double)i * 1.5707963267948966 / 24.0) + (float)tick * 0.02F;
                $stack0 = (Display)((List)bands.get(b)).get(i);
                $stack1 = new Matrix4f(flat).rotateZ(a).translate(-r, -r, z - facing * (float)i * 0.0005F).scale(2.0F * r, 2.0F * r, 0.03F);
                $stack2 = interp == 0 ? 0 : Math.max(interp, 3);
                Puppet.apply($stack0, $stack1, $stack2);
            }
        }
        float dialR = radius * 1.3F;
        for (i = 0; i < 10; i++) {
            a = (float)((double)i * 3.141592653589793 * 2.0 / 10.0) - (float)tick * 0.03F;
            $stack0 = (Display)notches.get(i);
            $stack1 = new Matrix4f(flat).rotateZ(a);
            $stack2 = dialR;
            Puppet.apply($stack0, $stack1.translate($stack2, 0.0F, facing > 0.0F ? 0.045F : -0.015F).translate(-0.12F * radius, -0.03F, 0.0F).scale(0.24F * radius, 0.06F, 0.01F), interp);
        }
        for (i = 0; i < 8; i++) {
            a = (float)((double)i * 3.141592653589793 * 2.0 / 8.0) + (float)tick * 0.015F;
            float len = radius * (0.7F + 0.25F * (float)Math.sin((double)tick * 0.2 + (double)i));
            Puppet.apply((Display)rays.get(i), new Matrix4f(flat).rotateZ(a - 1.5707964F).translate(-0.5F, radius * 1.42F, -0.5F).scale(1.0F, len, 1.0F), interp);
        }
    }

    void remove() {
        all.forEach(Entity::remove);
    }

}