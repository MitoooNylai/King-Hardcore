// by decompiler.cc
package com.bzl.deathanimation;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

final class Nebula implements Listener {
    private static final int IX = 5000;
    private static final int IY = 80;
    private static final int IZ = 5000;
    private static final int FALL_LIMIT = 48;
    private static final String[] AMBIENCE = new String[]{"ambient.cave", "ambient.soul_sand_valley.additions", "block.amethyst_block.chime", "ambient.warped_forest.additions", "block.beacon.ambient"};
    private final BzlDeathAnimation plugin;
    private final NamespacedKey untilKey;
    private final NamespacedKey returnKey;
    private final NamespacedKey modeKey;
    private final Map<UUID, Release> releases = new HashMap<>();
    private final Map<UUID, Sequence> arrivals = new HashMap<>();
    private final Map<UUID, BossBar> timerBars = new HashMap<>();
    private World world;
    private static final int ISLAND_VERSION = 3;
    private static final double ISLAND_R = 16.3;
    private static final int CLEAR = 46;
    private static final Material[] FLOOR = new Material[]{Material.POLISHED_DEEPSLATE, Material.POLISHED_DEEPSLATE, Material.DEEPSLATE_TILES, Material.DEEPSLATE_TILES, Material.CRACKED_DEEPSLATE_TILES};
    private static final Material[] ROCK = new Material[]{Material.DEEPSLATE, Material.COBBLED_DEEPSLATE, Material.TUFF, Material.DEEPSLATE};

    Nebula(BzlDeathAnimation plugin) {
        this.plugin = plugin;
        untilKey = new NamespacedKey(plugin, "nebula_until");
        returnKey = new NamespacedKey(plugin, "nebula_return");
        modeKey = new NamespacedKey(plugin, "nebula_mode");
    }

    void enable() {
        world = loadWorld();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, this::everySecond, 20L, 20L);
    }

    boolean isNebula(World w) {
        return w.equals(world);
    }

    boolean isTrapped(Player p) {
        return p.getPersistentDataContainer().has(untilKey, PersistentDataType.LONG);
    }

    Location spawn() {
        return new Location(world, 5000.5, 81.0, 5000.5, 180.0F, 0.0F);
    }

    private World loadWorld() {
        String name = plugin.settings.nebulaWorld;
        World w = Bukkit.getWorld(name);
        boolean fresh = w == null && !new File(Bukkit.getWorldContainer(), name).exists();
        if (w == null) {
            w = new WorldCreator(name).environment(World.Environment.THE_END).generator(new Nebula.VoidGenerator()).biomeProvider(new Nebula.VoidBiomes()).generateStructures(0).createWorld();
        }
        w.setSpawnLocation(5000, 81, 5000);
        ensureIsland(w, fresh);
        return w;
    }

    private void ensureIsland(World w, boolean fresh) {
        NamespacedKey key = new NamespacedKey(plugin, "island_version");
        Integer built = (Integer)w.getPersistentDataContainer().get(key, PersistentDataType.INTEGER);
        if (built != null && built >= 3) {
            return;
        }
        if (!fresh) {
            clearIsland(w);
        }
        buildIsland(w);
        w.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, 3);
    }

    private static void clearIsland(World w) {
        for (int dx = -46; dx <= 46; dx++) {
            for (int dz = -46; dz <= 46; dz++) {
                for (int dy = -32; dy <= 18; dy++) {
                    Block b = w.getBlockAt(5000 + dx, 80 + dy, 5000 + dz);
                    if (!b.getType().isAir()) {
                        b.setType(Material.AIR, 0);
                    }
                }
            }
        }
    }

    Location landingSpot() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int tries = 0; tries < 12; tries++) {
            double a = r.nextDouble(6.283185307179586);
            double rad = r.nextDouble(1.5, 5.5);
            int x = (int)Math.floor(Math.cos(a) * rad);
            int z = (int)Math.floor(Math.sin(a) * rad);
            Block floor = world.getBlockAt(5000 + x, 80, 5000 + z);
            if (floor.getType().isSolid() && floor.getRelative(0, 1, 0).isPassable() && floor.getRelative(0, 2, 0).isPassable()) {
                return new Location(world, (double)(5000 + x) + 0.5, 81.0, (double)(5000 + z) + 0.5, r.nextFloat() * 360.0F, 0.0F);
            }
        }
        return spawn();
    }

    private void buildIsland(World w) {
        Random r = new Random(7L);
        int[][] bottom = disc(w, r, 0, 0, 0, 16.3, 1);
        int i = new int[][]{new int[]{3, 0}, new int[]{-3, 0}, new int[]{0, 3}, new int[]{0, -3}};
        double a = i.length;
        int z = 0;
        for (; z < a; z++) {
            int[] o = i[z];
            set(w, o[0], 1, o[1], Material.END_ROD);
        }
        i = 0;
        double rad;
        int x;
        World $stack0;
        int $stack1;
        int $stack2;
        int $stack3;
        Material $stack4;
        for (; i < 7; i++) {
            a = (double)i * 3.141592653589793 * 2.0 / 7.0 + r.nextDouble() * 0.3;
            rad = 9.0 + r.nextDouble() * 2.0;
            x = (int)Math.round(Math.cos(a) * rad);
            z = (int)Math.round(Math.sin(a) * rad);
            int h = 2 + r.nextInt(4);
            for (int y = 1; y <= h; y++) {
                $stack0 = w;
                $stack1 = x;
                $stack2 = y;
                $stack3 = z;
                $stack4 = y == h ? Material.CRACKED_DEEPSLATE_BRICKS : Material.DEEPSLATE_BRICKS;
                set($stack0, $stack1, $stack2, $stack3, $stack4);
            }
            $stack0 = w;
            $stack1 = x;
            $stack2 = h + 1;
            $stack3 = z;
            $stack4 = h >= 4 ? Material.SEA_LANTERN : Material.AMETHYST_CLUSTER;
            set($stack0, $stack1, $stack2, $stack3, $stack4);
            $stack0 = w;
            $stack1 = x;
            $stack2 = r.nextBoolean() ? 1 : -1;
            set($stack0, $stack1 + $stack2, 1, z, Material.COBBLED_DEEPSLATE);
        }
        for (i = 0; i < 8; i++) {
            a = 0.39269908169872414 + (double)i * 3.141592653589793 / 4.0;
            x = (int)Math.round(Math.cos(a) * 14.5);
            z = (int)Math.round(Math.sin(a) * 14.5);
            set(w, x, 1, z, Material.POLISHED_DEEPSLATE_WALL);
            set(w, x, 2, z, Material.POLISHED_DEEPSLATE_WALL);
            set(w, x, 3, z, Material.SOUL_LANTERN);
        }
        for (i = 0; i < 34; i++) {
            a = r.nextDouble() * 3.141592653589793 * 2.0;
            rad = 4.0 + r.nextDouble() * 11.0;
            x = (int)Math.round(Math.cos(a) * rad);
            z = (int)Math.round(Math.sin(a) * rad);
            if (!w.getBlockAt(5000 + x, 80, 5000 + z).getType().isAir() && w.getBlockAt(5000 + x, 81, 5000 + z).getType().isAir()) {
                $stack0 = w;
                $stack1 = x;
                $stack2 = 1;
                $stack3 = z;
                $stack4 = i % 3 == 0 ? Material.LARGE_AMETHYST_BUD : Material.AMETHYST_CLUSTER;
                set($stack0, $stack1, $stack2, $stack3, $stack4);
            }
        }
        i = 0;
        int b;
        for (; i < 40; i++) {
            x = r.nextInt(27) - 13;
            z = r.nextInt(27) - 13;
            b = bottom[x + 20][z + 20];
            if (b != 0) {
                stalactite(w, x, b - 1, z, 2 + r.nextInt(4));
            }
        }
        String chain = blockId(new String[]{"minecraft:iron_chain", "minecraft:chain"});
        for (i = 0; i < 8; i++) {
            a = (double)i * 3.141592653589793 / 4.0;
            x = (int)Math.round(Math.cos(a) * 12.0);
            z = (int)Math.round(Math.sin(a) * 12.0);
            b = bottom[x + 20][z + 20];
            if (b != 0) {
                int len = 2 + r.nextInt(3);
                for (int k = 1; k <= len; k++) {
                    setData(w, x, b - k, z, chain);
                }
                setData(w, x, b - len - 1, z, "minecraft:soul_lantern[hanging=true]");
            }
        }
        for (i = 0; i < 6; i++) {
            a = (double)i * 3.141592653589793 / 3.0 + (r.nextDouble() - 0.5) * 0.5;
            double dist = 27.0 + r.nextDouble() * 6.0;
            int cx = (int)Math.round(Math.cos(a) * dist);
            int cz = (int)Math.round(Math.sin(a) * dist);
            int cy = r.nextInt(12) - 5;
            disc(w, r, cx, cy, cz, 2.4 + r.nextDouble() * 1.4, 0);
            $stack0 = w;
            $stack1 = cx;
            $stack2 = cy + 1;
            $stack3 = cz;
            $stack4 = i % 2 == 0 ? Material.AMETHYST_CLUSTER : Material.END_ROD;
            set($stack0, $stack1, $stack2, $stack3, $stack4);
            stalactite(w, cx, cy - 4, cz, 2 + r.nextInt(2));
        }
    }

    private static int[][] disc(World w, Random r, int ox, int oy, int oz, double radius, boolean main) {
        int[][] bottom = new int[41][41];
        int span = (int)Math.ceil(radius);
        for (int dx = -span; dx <= span; dx++) {
            for (int dz = -span; dz <= span; dz++) {
                double d = Math.sqrt((double)(dx * dx + dz * dz));
                if (d <= radius) {
                    int top = 0;
                    if (d > radius - 1.0 && r.nextDouble() < 0.3) {
                        top = -1;
                    }
                    int $stack0 = main && top == 0 && (d >= 6.6 && d <= 7.4 || d >= 12.6 && d <= 13.4);
                    boolean ring = $stack0;
                    if (main && d < 1.6) {
                        $stack0 = Material.CHISELED_DEEPSLATE;
                    } else {
                        label0: {
                            if (ring) {
                                $stack0 = Material.SEA_LANTERN;
                                break label0;
                            }
                            $stack0 = FLOOR[r.nextInt(FLOOR.length)];
                        }
                    }
                    Material m = $stack0;
                    set(w, ox + dx, oy + top, oz + dz, m);
                    int depth = Math.min(12, (int)((radius - d) * 0.75)) + 1 + r.nextInt(2);
                    for (int k = 1; k <= depth; k++) {
                        set(w, ox + dx, oy + top - k, oz + dz, ROCK[r.nextInt(ROCK.length)]);
                    }
                    if (Math.abs(dx) <= 20 && Math.abs(dz) <= 20) {
                        bottom[dx + 20][dz + 20] = top - depth;
                    }
                }
            }
        }
        return bottom;
    }

    private static void stalactite(World w, int x, int y, int z, int len) {
        for (int j = 0; j < len; j++) {
            String $stack0;
            if (j == len - 1) {
                $stack0 = "tip";
            } else {
                label0: {
                    if (j == len - 2) {
                        $stack0 = "frustum";
                        break label0;
                    }
                    if (j == 0) {
                        $stack0 = "base";
                        break label0;
                    }
                    $stack0 = "middle";
                }
            }
            String t = $stack0;
            setData(w, x, y - j, z, "minecraft:pointed_dripstone[thickness=" + t + ",vertical_direction=down]");
        }
    }

    private static void set(World w, int dx, int dy, int dz, Material m) {
        w.getBlockAt(5000 + dx, 80 + dy, 5000 + dz).setType(m, 0);
    }

    private static void setData(World w, int dx, int dy, int dz, String data) {
        try {
            w.getBlockAt(5000 + dx, 80 + dy, 5000 + dz).setBlockData(Bukkit.createBlockData(data), 0);
        } catch (IllegalArgumentException illegalArgumentException) {
            return;
        }
    }

    private static String blockId(String... ids) {
        String[] stringArray = ids;
        int i = stringArray.length;
        int i2 = 0;
        while (i2 < i) {
            String id = stringArray[i2];
            try {
                Bukkit.createBlockData(id);
                String $stack0 = id;
            } catch (IllegalArgumentException illegalArgumentException) {
                i2++;
                continue;
            }
        }
        return ids[ids.length - 1];
    }

    void imprison(Player p, Location returnTo, boolean animate, GameMode realMode) {
        int minutes = plugin.settings.durationMinutes;
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        pdc.set(untilKey, PersistentDataType.LONG, System.currentTimeMillis() + (long)minutes * 60000L);
        pdc.set(returnKey, PersistentDataType.STRING, serialize(returnTo));
        pdc.set(modeKey, PersistentDataType.STRING, (realMode == GameMode.SPECTATOR ? GameMode.SURVIVAL : realMode).name());
        if (plugin.settings.healOnArrival) {
            heal(p);
        }
        Runnable welcome = () -> {
        if (!p.isOnline()) {
            return;
        }
        if (plugin.settings.has("nebula.title") || plugin.settings.has("nebula.subtitle")) {
            p.showTitle(Title.title(msg("title", p, minutes), msg("subtitle", p, minutes), Title.Times.times(Duration.ofMillis((long)plugin.settings.titleFadeIn * 50L), Duration.ofMillis((long)plugin.settings.titleStay * 50L), Duration.ofMillis((long)plugin.settings.titleFadeOut * 50L))));
        }
        p.playSound(p, "block.respawn_anchor.set_spawn", 1.0F, 1.2F);
    };
        if (animate && plugin.settings.arrivalCinematic) {
            p.playSound(p, "block.portal.travel", 0.6F, 1.4F);
            UUID id = p.getUniqueId();
            arrivals.put(id, Sequence.fromSky(plugin, p, landingSpot(), plugin.settings.nebulaMode, 0, () -> {
        arrivals.remove(id);
        welcome.run();
    }));
        } else {
            if (!p.teleport(spawn()) || !isNebula(p.getWorld())) {
                p.getPersistentDataContainer().set(plugin.pendingKey, PersistentDataType.STRING, plugin.settings.nebulaMode.name() + ";" + serialize(spawn()));
            }
            p.setGameMode(plugin.settings.nebulaMode);
            welcome.run();
        }
        if (plugin.settings.has("nebula.broadcast")) {
            Bukkit.broadcast(msg("broadcast", p, minutes));
        }
    }

    void release(Player p) {
        Sequence arriving = (Sequence)arrivals.get(p.getUniqueId());
        if (arriving != null) {
            arriving.abort();
        }
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        Location back = returnLocation(p, (String)pdc.get(returnKey, PersistentDataType.STRING));
        GameMode mode = GameMode.SURVIVAL;
        UUID id;
        try {
            m = (String)pdc.get(modeKey, PersistentDataType.STRING);
            if (m != null) {
                mode = GameMode.valueOf(m);
            }
        } catch (IllegalArgumentException m) {
            pdc.remove(untilKey);
            pdc.remove(returnKey);
            pdc.remove(modeKey);
            id = p.getUniqueId();
            if (!isNebula(p.getWorld()) || !plugin.settings.releaseCinematic) {
                p.teleport(back);
                p.setGameMode(mode);
                p.stopSound("music.end");
                if (plugin.settings.has("nebula.released")) {
                    p.sendMessage(msg("released", p, 0));
                }
                return;
            }
        }
        if (releases.containsKey(id)) {
            return;
        }
        releases.put(id, new Release(plugin, p, back, mode, () -> {
        releases.remove(id);
        if (p.isOnline() && plugin.settings.has("nebula.released")) {
            p.sendMessage(msg("released", p, 0));
        }
    }));
    }

    List<Player> trapped() {
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isTrapped(p)) {
                list.add(p);
            }
        }
        list.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        return list;
    }

    long remaining(Player p) {
        Long until = (Long)p.getPersistentDataContainer().get(untilKey, PersistentDataType.LONG);
        return until == null ? 0L : Math.max(0L, until - System.currentTimeMillis());
    }

    void addTime(Player p, long millis) {
        Long until = (Long)p.getPersistentDataContainer().get(untilKey, PersistentDataType.LONG);
        if (until == null) {
            return;
        }
        p.getPersistentDataContainer().set(untilKey, PersistentDataType.LONG, Math.max(System.currentTimeMillis(), until + millis));
    }

    boolean busy(Player p) {
        return arrivals.containsKey(p.getUniqueId()) || releases.containsKey(p.getUniqueId());
    }

    void abortReleases() {
        new ArrayList(releases.values()).forEach(Release::abort);
        new ArrayList(arrivals.values()).forEach(Sequence::abort);
    }

    private void arrive(Player p) {
        UUID id = p.getUniqueId();
        if (arrivals.containsKey(id)) {
            return;
        }
        arrivals.put(id, new Descent(plugin, p, spawn(), plugin.settings.nebulaMode, () -> {
        arrivals.remove(id);
        if (p.isOnline()) {
            Fx.get(Fx.Slot.NEBULA_ARRIVE).spawn(p.getLocation().add(0.0, 1.0, 0.0), 40, 0.4, 0.8, 0.4, 0.12);
        }
    }));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        removeTimerBar(e.getPlayer());
        Release r = (Release)releases.get(e.getPlayer().getUniqueId());
        if (r != null) {
            r.abort();
        }
        Sequence d = (Sequence)arrivals.get(e.getPlayer().getUniqueId());
        if (d != null) {
            d.abort();
        }
    }

    private Location returnLocation(Player p, String saved) {
        Location $stack0 = p.getRespawnLocation() != null ? p.getRespawnLocation() : ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
        Location fallback = $stack0;
        if (!"death".equals(plugin.settings.returnTo)) {
            return fallback;
        }
        Location loc = deserialize(saved);
        $stack0 = loc != null && isSafe(loc) ? loc : fallback;
        return $stack0;
    }

    private static boolean isSafe(Location loc) {
        Block feet = loc.getBlock();
        Block head = feet.getRelative(0, 1, 0);
        if (!feet.isPassable() || !head.isPassable()) {
            return 0;
        }
        int i = new Block[]{feet, head};
        Block below = i.length;
        for (i = 0; i < below; i++) {
            Block b = i[i];
            Material m = b.getType();
            if (m == Material.LAVA || m == Material.FIRE || m == Material.SOUL_FIRE) {
                return 0;
            }
        }
        for (i = 1; i <= 3; i++) {
            below = feet.getRelative(0, -i, 0);
            if (below.getType() == Material.LAVA) {
                return 0;
            }
            if (below.getType().isSolid()) {
                return 1;
            }
        }
        return 0;
    }

    private static void heal(Player p) {
        double max = p.getMaxHealth();
        p.setHealth(max);
        p.setFoodLevel(20);
        p.setFireTicks(0);
        p.setFallDistance(0.0F);
    }

    private void everySecond() {
        long now = System.currentTimeMillis();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Long until = (Long)p.getPersistentDataContainer().get(untilKey, PersistentDataType.LONG);
            if (until == null) {
                continue;
            }
            if (plugin.running.containsKey(p.getUniqueId())) {
                continue;
            }
            long left = until - now;
            if (left <= 0L) {
                removeTimerBar(p);
                release(p);
                continue;
            }
            if (!isNebula(p.getWorld())) {
                removeTimerBar(p);
                if (p.hasPermission("bda.bypass.teleport")) {
                    continue;
                }
                p.teleport(spawn());
                continue;
            }
            long s = (left + 999L) / 1000L;
            updateTimerBar(p, s);
            if (plugin.settings.ambientSounds && r.nextInt(18) == 0) {
                String cue = AMBIENCE[r.nextInt(AMBIENCE.length)];
                p.playSound(p.getLocation().add(r.nextDouble(-12.0, 12.0), r.nextDouble(-6.0, 6.0), r.nextDouble(-12.0, 12.0)), cue, 0.7F, 0.7F + r.nextFloat() * 0.5F);
            }
            Location c = p.getLocation();
            for (int i = 0; plugin.settings.ambientParticles && i < 12; i++) {
                Location at = c.clone().add(r.nextDouble(-14.0, 14.0), r.nextDouble(-6.0, 10.0), r.nextDouble(-14.0, 14.0));
                Fx.get(Fx.Slot.NEBULA_STARS).spawnFor(p, at, 1, 0.0, 0.0, 0.0, 0.005, 0.0);
            }
        }
    }

    private void updateTimerBar(Player p, long secondsLeft) {
        UUID id = p.getUniqueId();
        BossBar bar = timerBars.get(id);
        if (bar == null) {
            bar = Bukkit.createBossBar("", BarColor.BLUE, BarStyle.SOLID);
            bar.setVisible(true);
            timerBars.put(id, bar);
            bar.addPlayer(p);
        }
        String time = String.format(Locale.ROOT, "%02d:%02d", secondsLeft / 60L, secondsLeft % 60L);
        bar.setTitle("§b☄ Rebirth in §f" + time + " §b☄");
        double total = Math.max(1.0, plugin.settings.durationMinutes * 60.0);
        bar.setProgress(Math.max(0.0, Math.min(1.0, secondsLeft / total)));
    }

    private void removeTimerBar(Player p) {
        BossBar bar = timerBars.remove(p.getUniqueId());
        if (bar != null) {
            bar.removePlayer(p);
            bar.removeAll();
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        Entity entity = e.getEntity();
        Player p;
        if (entity instanceof Player) {
            p = (Player)entity;
        }
        return;
        if (busy(p)) {
            e.setCancelled(1);
            return;
        }
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID || e.getFinalDamage() >= p.getHealth()) {
            e.setCancelled(1);
            heal(p);
            arrive(p);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (e.getTo().getY() < 48.0 && isNebula(e.getTo().getWorld()) && isTrapped(e.getPlayer())) {
            Player p = e.getPlayer();
            if (!arrivals.containsKey(p.getUniqueId())) {
                Bukkit.getScheduler().runTask(plugin, () -> arrive(p));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        if (!plugin.settings.blockTeleport || !isTrapped(p) || p.hasPermission("bda.bypass.teleport")) {
            return;
        }
        if (isNebula(e.getFrom().getWorld()) && !isNebula(e.getTo().getWorld())) {
            e.setCancelled(1);
            if (plugin.settings.has("nebula.blocked")) {
                p.sendMessage(msg("blocked", p, 0));
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!plugin.settings.blockCommands || !isTrapped(p) || p.hasPermission("bda.bypass.commands")) {
            return;
        }
        String root = e.getMessage().substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        root = root.substring(root.indexOf(58) + 1);
        if (plugin.settings.allowedCommands.contains(root)) {
            return;
        }
        e.setCancelled(1);
        if (plugin.settings.has("nebula.command-blocked")) {
            p.sendMessage(msg("command-blocked", p, 0));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Long until = (Long)p.getPersistentDataContainer().get(untilKey, PersistentDataType.LONG);
        if (until == null) {
            return;
        }
        if (!isNebula(p.getWorld()) && until > System.currentTimeMillis() && !p.hasPermission("bda.bypass.teleport")) {
            p.teleport(spawn());
            p.setGameMode(plugin.settings.nebulaMode);
        }
        if (!plugin.settings.has("nebula.rejoin")) {
            return;
        }
        long s = Math.max(0L, (until - System.currentTimeMillis() + 999L) / 1000L);
        p.sendMessage(plugin.settings.msg("nebula.rejoin", new TagResolver[]{Placeholder.unparsed("player", p.getName()), Placeholder.unparsed("time", String.format("%02d:%02d", new Object[]{s / 60L, s % 60L}))}));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (isTrapped(e.getPlayer())) {
            e.setRespawnLocation(spawn());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void allowEffectBodies(CreatureSpawnEvent e) {
        if (e.getEntity().getScoreboardTags().contains("bda_fx")) {
            e.setCancelled(0);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (e.getEntity().getScoreboardTags().contains("bda_fx")) {
            return;
        }
        CreatureSpawnEvent.SpawnReason why = e.getSpawnReason();
        if (isNebula(e.getLocation().getWorld()) && why != CreatureSpawnEvent.SpawnReason.CUSTOM && why != CreatureSpawnEvent.SpawnReason.COMMAND) {
            e.setCancelled(1);
        }
    }

    private Component msg(String key, Player p, int minutes) {
        return plugin.settings.msg("nebula." + key, new TagResolver[]{Placeholder.unparsed("player", p.getName()), Placeholder.unparsed("minutes", String.valueOf(minutes))});
    }

    static String serialize(Location l) {
        return l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch();
    }

    static Location deserialize(String s) {
        if (s == null) {
            return null;
        }
        String[] a = s.split(";");
        World $stack0 = a.length == 6 ? Bukkit.getWorld(a[0]) : null;
        World w = $stack0;
        if (w == null) {
            return null;
        }
        try {
            $stack0 = new Location(w, Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3]), Float.parseFloat(a[4]), Float.parseFloat(a[5]));
        } catch (NumberFormatException e) {
            return null;
        }
    }

}