// by decompiler.cc
package com.bzl.deathanimation;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;

final class MannequinBody implements Body {
    private static final double MIN_SCALE = 0.0625;
    private static final Set<Pose> VALID = validPoses();
    private static final Map<Pose, Pose> FALLBACK = Map.of(Pose.SLEEPING, Pose.SWIMMING, Pose.SWIMMING, Pose.SNEAKING, Pose.FALL_FLYING, Pose.STANDING, Pose.SNEAKING, Pose.STANDING);
    private static final Set<String> reported = new HashSet<>();
    private final Mannequin mannequin;
    private final Location feet;
    private final float yaw;
    private final AttributeInstance scaleAttr;
    private boolean removed;
    private boolean canGlide = 1;

    MannequinBody(Location feet, float yaw, Player owner) {
        this.feet = feet.clone();
        this.yaw = yaw;
        Location at = feet.clone();
        at.setPitch(0.0F);
        mannequin = (Mannequin)at.getWorld().spawn(at, Mannequin.class, m -> {
        m.setPersistent(0);
        m.addScoreboardTag("bda_fx");
        m.setProfile(ResolvableProfile.resolvableProfile(owner.getPlayerProfile()));
        m.setMainHand(owner.getMainHand());
        m.setImmovable(1);
        m.setGravity(0);
        m.setInvulnerable(1);
        m.setSilent(1);
        m.setCollidable(0);
        m.setBodyYaw(yaw);
        try {
            m.setDescription(null);
        } catch (RuntimeException runtimeException) {
            return;
        }
    });
        scaleAttr = mannequin.getAttribute(Attribute.SCALE);
    }

    static void report() {
        if (VALID.isEmpty()) {
            Bukkit.getLogger().warning("[King Hardcore] no mannequin poses available");
        }
    }

    private static Set<Pose> validPoses() {
        try {
            label0: {
                Set<Pose> poses = Mannequin.validPoses();
                Bukkit.getLogger().info("[King Hardcore] Mannequin poses allowed by this server: " + String.valueOf(poses));
                Set<Pose> $stack0;
                if (poses.isEmpty()) {
                    $stack0 = EnumSet.allOf(Pose.class);
                    break label0;
                }
                $stack0 = poses;
            }
        } catch (RuntimeException | LinkageError e) {
            return EnumSet.allOf(Pose.class);
        }
    }

    public void pose(Body.Stage stage, float progress, float[] p, double ox, double oy, double oz, float scale) {
        if (removed) {
            return;
        }
        MannequinBody $stack0;
        double $stack1;
        double $stack2;
        double $stack3;
        float $stack4;
        switch (stage) {
            case FALL:
                setPose(Pose.SLEEPING);
            case GET_UP:
                $stack0 = this;
                if (progress < 0.25F) {
                    $stack1 = Pose.SWIMMING;
                } else {
                    label0: {
                        if (progress < 0.65F) {
                            $stack1 = Pose.SNEAKING;
                            break label0;
                        }
                        $stack1 = Pose.STANDING;
                    }
                }
                $stack0.setPose($stack1);
                $stack0 = this;
                $stack1 = ox;
                $stack2 = oy;
                $stack3 = oz;
                $stack4 = progress < 0.65F ? 30.0F : 0.0F;
                $stack0.move($stack1, $stack2, $stack3, $stack4, 0.0F);
            case PULL:
                setPose(Pose.FALL_FLYING);
                glide();
                float lean = Math.max(0.0F, p[0]) * 1.4F;
                move(ox, oy + (double)p[6], oz, -90.0F + Math.min(70.0F, lean), (p[3] - p[4]) * 0.4F);
                scale(scale);
            case DESCEND:
                setPose(Pose.FALL_FLYING);
                glide();
                move(ox, oy, oz, -78.0F, (1.0F - progress) * 180.0F);
                scale(scale);
            case LAND:
                $stack0 = this;
                $stack1 = progress < 0.5F ? Pose.SNEAKING : Pose.STANDING;
                $stack0.setPose($stack1);
                $stack0 = this;
                $stack1 = ox;
                $stack2 = oy;
                $stack3 = oz;
                $stack4 = progress < 0.5F ? 25.0F : 0.0F;
                $stack0.move($stack1, $stack2, $stack3, $stack4, 0.0F);
                scale(1.0F);
            case LOOK:
                setPose(Pose.STANDING);
                move(ox, oy, oz, p[5], p[0]);
                guard("body yaw", () -> mannequin.setBodyYaw(yaw));
            default:
                return;
        }
    }

    private void setPose(Pose pose) {
        Pose want = pose;
        while (!VALID.contains(want) && FALLBACK.containsKey(want)) {
            want = (Pose)FALLBACK.get(want);
        }
        if (mannequin.getPose() == want) {
            return;
        }
        Pose target = want;
        if (!guard("pose " + String.valueOf(target), () -> mannequin.setPose(target, 1))) {
            guard("pose STANDING", () -> mannequin.setPose(Pose.STANDING, 1));
        }
    }

    private void glide() {
        if (canGlide) {
            canGlide = guard("gliding", () -> mannequin.setGliding(1));
        }
    }

    private void scale(float s) {
        if (scaleAttr != null) {
            guard("scale", () -> scaleAttr.setBaseValue(Math.max(0.0625, (double)s)));
        }
    }

    private void move(double ox, double oy, double oz, float pitch, float yawOffset) {
        Location l = feet.clone().add(ox, oy, oz);
        l.setYaw(yaw + yawOffset);
        l.setPitch(pitch);
        mannequin.teleport(l);
        guard("body yaw", () -> mannequin.setBodyYaw(yaw + yawOffset));
        guard("air", () -> mannequin.setRemainingAir(mannequin.getRemainingAir() == 300 ? 299 : 300));
    }

    private static boolean guard(String what, Runnable call) {
        try {
            call.run();
            int $stack0 = 1;
        } catch (RuntimeException e) {
            if (reported.add(what)) {
                Bukkit.getLogger().warning("[King Hardcore] Mannequin refused " + what + ": " + String.valueOf(e) + " (using a fallback; the animation continues)");
            }
            return 0;
        }
    }

    public boolean ready() {
        return mannequin.isValid();
    }

    public void remove() {
        removed = 1;
        mannequin.remove();
    }

}