// by decompiler.cc
package com.bzl.deathanimation;

import java.util.List;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.WorldInfo;

private static final class VoidBiomes extends BiomeProvider {
    private VoidBiomes() {
    }

    public Biome getBiome(WorldInfo info, int x, int y, int z) {
        return Biome.THE_VOID;
    }

    public List<Biome> getBiomes(WorldInfo info) {
        return List.of(Biome.THE_VOID);
    }
}