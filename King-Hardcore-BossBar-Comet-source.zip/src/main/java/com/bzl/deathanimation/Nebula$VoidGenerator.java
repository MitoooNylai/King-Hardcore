// by decompiler.cc
package com.bzl.deathanimation;

import java.util.Random;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;

private static final class VoidGenerator extends ChunkGenerator {
    private VoidGenerator() {
    }

    public Location getFixedSpawnLocation(World world, Random random) {
        return new Location(world, 5000.5, 81.0, 5000.5);
    }
}