// by decompiler.cc
package com.bzl.deathanimation;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import javax.imageio.ImageIO;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.profile.PlayerTextures;

public final class BzlDeathAnimation extends JavaPlugin implements Listener, TabCompleter {
    static final String FX_TAG = "bda_fx";
    final NamespacedKey savedModeKey = new NamespacedKey(this, "saved_gamemode");
    final NamespacedKey pendingKey = new NamespacedKey(this, "pending_arrival");
    final Map<UUID, Cinematic> running = new HashMap<>();
    private final Map<UUID, Puppet.Colors> skins = new ConcurrentHashMap<>();
    private final Map<String, Puppet.Colors> skinsByUrl = new ConcurrentHashMap<>();
    Nebula nebula;
    Settings settings;
    private final Set<UUID> retargeting = new HashSet<>();
    static final String PERM_SKIP = "bda.command.skip";
    static final String PERM_TEST = "bda.command.test";
    static final String PERM_TEST_OTHERS = "bda.command.test.others";
    static final String PERM_RELOAD = "bda.command.reload";
    static final String PERM_BYPASS_TELEPORT = "bda.bypass.teleport";
    static final String PERM_BYPASS_COMMANDS = "bda.bypass.commands";
    static final String PERM_MENU = "bda.menu";
    static final String PERM_MENU_EDIT = "bda.menu.edit";
    static final String PERM_MENU_PLAYERS = "bda.menu.players";
    static final String PERM_MENU_MANAGE = "bda.menu.players.manage";

    public BzlDeathAnimation() {
    }

    void watch(Player player, Entity camera) {
        if (player.getGameMode() != GameMode.SPECTATOR) {
            player.setGameMode(GameMode.SPECTATOR);
        }
        retargeting.add(player.getUniqueId());
        try {
            player.setSpectatorTarget(camera);
        } catch (Throwable throwable) {
            retargeting.remove(player.getUniqueId());
            throw throwable;
        }
    }

    static void unwatch(Player player) {
        if (player.getGameMode() == GameMode.SPECTATOR) {
            player.setSpectatorTarget(null);
        }
    }

    public void onEnable() {
        settings = new Settings(this);
        if (Body.MANNEQUIN) {
            MannequinBody.report();
        }
        Bukkit.getWorlds().forEach(w -> w.getEntities().forEach(e -> {
        if (e.getScoreboardTags().contains("bda_fx")) {
            e.remove();
        }
    }));
        nebula = new Nebula(this);
        nebula.enable();
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("bda").setExecutor(this);
        getCommand("bda").setTabCompleter(this);
        Menu.start(this);
        getServer().getOnlinePlayers().forEach(this::loadSkin);
        Banner.print(this, settings);
    }

    public void onDisable() {
        Menu.closeAll();
        new ArrayList(running.values()).forEach(c -> c.finish(0));
        if (nebula != null) {
            nebula.abortReleases();
        }
    }

    Puppet.Colors skinOf(Player player) {
        return (Puppet.Colors)skins.getOrDefault(player.getUniqueId(), Puppet.Colors.DEFAULT);
    }

    boolean startCinematic(Player player) {
        try {
            running.put(player.getUniqueId(), new Cinematic(this, player));
            int $stack0 = 1;
        } catch (RuntimeException e) {
            getLogger().log(Level.SEVERE, "Could not start the death animation for " + player.getName() + "; they die normally instead.", e);
            return 0;
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        Player player;
        if (entity instanceof Player) {
            player = (Player)entity;
        } else {
            return;
        }
        if (running.containsKey(player.getUniqueId()) || nebula.busy(player)) {
            event.setCancelled(1);
            return;
        }
        if (!settings.enabled || settings.disabledWorlds.contains(player.getWorld().getName().toLowerCase(Locale.ROOT)) || !settings.exemptPermission.isBlank() && player.hasPermission(settings.exemptPermission) || (nebula.isNebula(player.getWorld()) || event.getFinalDamage() < player.getHealth() || settings.skipCauses.contains(event.getCause().name())) || settings.totemSaves && holdsTotem(player.getInventory())) {
            return;
        }
        event.setCancelled(startCinematic(player));
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        Player p = event.getPlayer();
        if (retargeting.contains(p.getUniqueId())) {
            return;
        }
        boolean inCinematic = running.containsKey(p.getUniqueId());
        boolean spectateHop = event.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE && nebula.busy(p);
        if (inCinematic || spectateHop) {
            event.setCancelled(1);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Cinematic c = (Cinematic)running.get(event.getPlayer().getUniqueId());
        if (c != null) {
            c.finish(0);
        }
        skins.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String pending = (String)player.getPersistentDataContainer().get(pendingKey, PersistentDataType.STRING);
        if (pending != null) {
            player.getPersistentDataContainer().remove(pendingKey);
            int cut = pending.indexOf(59);
            if (cut > 0) {
                Location to = Nebula.deserialize(pending.substring(cut + 1));
                if (to != null) {
                    player.teleport(to);
                }
                try {
                    player.setGameMode(GameMode.valueOf(pending.substring(0, cut)));
                } catch (IllegalArgumentException ignored) {
                    player.setGameMode(GameMode.SURVIVAL);
                }
            }
        }
        String saved = (String)player.getPersistentDataContainer().get(savedModeKey, PersistentDataType.STRING);
        if (saved != null) {
            player.getPersistentDataContainer().remove(savedModeKey);
            GameMode real;
            try {
                real = GameMode.valueOf(saved);
            } catch (IllegalArgumentException ignored) {
                real = GameMode.SURVIVAL;
                player.setGameMode(real);
                if (!nebula.isTrapped(player)) {
                    nebula.imprison(player, player.getLocation(), 1, real);
                }
            }
        }
        loadSkin(player);
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String $stack0 = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";
        String sub = $stack0;
        String string = sub;
        int i = -1;
        Player target;
        Player p;
        switch (string.hashCode()) {
            case 3347807:
                i = 0;
            case -1307827859:
                i = 1;
            case 102715:
                i = 2;
            case -1049449665:
                i = 3;
            case 3556498:
                i = 4;
            case -934641255:
                i = 5;
            case 0:
                if (string.equals("")) {
                    i = 6;
                }
            default:
                switch (i) {
                    case 0:
                    case 1:
                    case 2:
                        if (sender instanceof Player) {
                            p = (Player)sender;
                        } else {
                            tell(sender, "menu.players-only", new String[0]);
                        }
                        if (allowed(sender, "bda.menu")) {
                            AdminMenu.open(this, p);
                        }
                    case 3:
                        if (!allowed(sender, "bda.command.skip")) {
                            return 1;
                        }
                        if (args.length < 3 || !args[1].equalsIgnoreCase("skip")) {
                            tell(sender, "command.usage-skip", new String[0]);
                            return 1;
                        }
                        target = Bukkit.getPlayerExact(args[2]);
                        if (target == null) {
                            tell(sender, "command.not-online", new String[]{args[2]});
                        } else {
                            skip(sender, target);
                        }
                    case 4:
                        if (!allowed(sender, "bda.command.test")) {
                            return 1;
                        }
                        if (args.length > 1) {
                            $stack0 = Bukkit.getPlayerExact(args[1]);
                        } else {
                            label0: {
                                if (sender instanceof Player) {
                                    p = (Player)sender;
                                    $stack0 = p;
                                    break label0;
                                }
                                $stack0 = null;
                            }
                        }
                        target = $stack0;
                        if (args.length > 1 && target == null) {
                            tell(sender, "command.not-online", new String[]{args[1]});
                        } else {
                            label1: {
                                if (target == null) {
                                    tell(sender, "command.usage-test", new String[0]);
                                    break label1;
                                }
                                if (target == sender || allowed(sender, "bda.command.test.others")) {
                                    test(sender, target);
                                }
                            }
                        }
                    case 5:
                        reload(sender);
                    case 6:
                        if (sender instanceof Player) {
                            p = (Player)sender;
                            if (p.hasPermission("bda.menu")) {
                                AdminMenu.open(this, p);
                            }
                        }
                        if (hasAnyCommand(sender)) {
                            tell(sender, "command.usage", new String[0]);
                        }
                        tell(sender, "command.no-permission", new String[0]);
                    default:

                }
        }
        tell(sender, "menu.players-only", new String[0]);
        if (allowed(sender, "bda.menu")) {
            AdminMenu.open(this, p);
        }
        if (!allowed(sender, "bda.command.skip")) {
            return 1;
        }
        if (args.length < 3 || !args[1].equalsIgnoreCase("skip")) {
            tell(sender, "command.usage-skip", new String[0]);
            return 1;
        }
        target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            tell(sender, "command.not-online", new String[]{args[2]});
        } else {
            skip(sender, target);
        }
        if (!allowed(sender, "bda.command.test")) {
            return 1;
        }
        if (args.length > 1) {
            $stack0 = Bukkit.getPlayerExact(args[1]);
        } else {
            label2: {
                if (sender instanceof Player) {
                    p = (Player)sender;
                    $stack0 = p;
                    break label2;
                }
                $stack0 = null;
            }
        }
        target = $stack0;
        if (args.length > 1 && target == null) {
            tell(sender, "command.not-online", new String[]{args[1]});
        } else {
            label3: {
                if (target == null) {
                    tell(sender, "command.usage-test", new String[0]);
                    break label3;
                }
                if (target == sender || allowed(sender, "bda.command.test.others")) {
                    test(sender, target);
                }
            }
        }
        if (allowed(sender, "bda.command.reload")) {
            label4: {
                reload(sender);
                break;
                if (sender instanceof Player) {
                    p = (Player)sender;
                    if (p.hasPermission("bda.menu")) {
                        AdminMenu.open(this, p);
                        break label4;
                    }
                }
                if (hasAnyCommand(sender)) {
                    tell(sender, "command.usage", new String[0]);
                    break label4;
                }
                tell(sender, "command.no-permission", new String[0]);
                break;
                if (hasAnyCommand(sender)) {
                    tell(sender, "command.usage", new String[0]);
                    break label4;
                }
                tell(sender, "command.no-permission", new String[0]);
            }
        }
        return 1;
    }

    void skip(CommandSender sender, Player target) {
        if (!nebula.isTrapped(target)) {
            tell(sender, "command.not-in-nebula", new String[]{target.getName()});
        } else {
            label0: {
                if (running.containsKey(target.getUniqueId()) || nebula.busy(target)) {
                    tell(sender, "command.busy", new String[]{target.getName()});
                    break label0;
                }
                nebula.release(target);
                tell(sender, "command.skipped", new String[]{target.getName()});
            }
        }
    }

    void test(CommandSender sender, Player target) {
        if (running.containsKey(target.getUniqueId()) || nebula.isTrapped(target) || nebula.busy(target)) {
            tell(sender, "command.busy", new String[]{target.getName()});
        } else {
            startCinematic(target);
        }
    }

    void reload(CommandSender sender) {
        settings = new Settings(this);
        tell(sender, "command.reloaded", new String[0]);
    }

    private boolean allowed(CommandSender sender, String permission) {
        if (sender.hasPermission(permission)) {
            return 1;
        }
        tell(sender, "command.no-permission", new String[0]);
        return 0;
    }

    private static boolean hasAnyCommand(CommandSender s) {
        return s.hasPermission("bda.command.skip") || s.hasPermission("bda.command.test") || (s.hasPermission("bda.command.reload") || s.hasPermission("bda.menu"));
    }

    void tell(CommandSender to, String key, String... player) {
        if (!settings.has(key)) {
            return;
        }
        CommandSender $stack0 = to;
        Settings $stack1 = settings;
        String $stack2 = key;
        TagResolver[] $stack3 = new TagResolver[1];
        new TagResolver[1][0] = Placeholder.unparsed("player", player.length > 0 ? player[0] : to.getName());
        $stack0.sendMessage($stack1.msg($stack2, $stack3));
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List options = new ArrayList();
        String typed;
        if (args.length == 1) {
            if (sender.hasPermission("bda.menu")) {
                options.add("menu");
            }
            if (sender.hasPermission("bda.command.skip")) {
                options.add("nebula");
            }
            if (sender.hasPermission("bda.command.test")) {
                options.add("test");
            }
            options.add("reload");
        } else {
            label0: {
                if (args.length == 2 && args[0].equalsIgnoreCase("nebula") && sender.hasPermission("bda.command.skip")) {
                    options.add("skip");
                    break label0;
                }
                if (args.length == 2 && args[0].equalsIgnoreCase("test") && sender.hasPermission("bda.command.test.others")) {
                    options.addAll(playerNames());
                    break label0;
                }
                if (args.length == 3 && args[0].equalsIgnoreCase("nebula") && sender.hasPermission("bda.command.skip")) {
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (nebula.isTrapped(p)) {
                            options.add(p.getName());
                        }
                    }
                }
            }
        }
        typed = args[args.length - 1].toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.toLowerCase(Locale.ROOT).startsWith(typed)).toList();
    }

    private static List<String> playerNames() {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
    }

    private static boolean holdsTotem(PlayerInventory inv) {
        return inv.getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING || inv.getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    private void loadSkin(Player player) {
        if (Body.MANNEQUIN && !"blocks".equals(settings.body)) {
            return;
        }
        PlayerTextures textures = player.getPlayerProfile().getTextures();
        URL url = textures.getSkin();
        if (url == null) {
            return;
        }
        boolean slim = textures.getSkinModel() == PlayerTextures.SkinModel.SLIM;
        UUID id = player.getUniqueId();
        Puppet.Colors cached = (Puppet.Colors)skinsByUrl.get(url.toString());
        if (cached != null) {
            skins.put(id, cached);
            return;
        }
        getServer().getScheduler().runTaskAsynchronously(this, () -> {
        try {
            URLConnection con = url.openConnection();
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);
            InputStream in = con.getInputStream();
            try {
                BufferedImage img = ImageIO.read(in);
            } catch (Throwable throwable) {
                if (in != null) {
                    try {
                        in.close();
                    } catch (Throwable throwable2) {
                        throwable.addSuppressed(throwable2);
                    }
                }
            }
            throw throwable;
        } catch (Exception e) {
            getLogger().fine("Skin download failed for " + String.valueOf(id) + ": " + e.getMessage());
            return;
        }
    });
    }
}