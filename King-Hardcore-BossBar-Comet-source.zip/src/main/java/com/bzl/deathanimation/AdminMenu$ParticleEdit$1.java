// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.Location;
import org.bukkit.scheduler.BukkitRunnable;

class ParticleEdit$1 extends BukkitRunnable {
    int n;

    ParticleEdit$1(Fx fx, Location location) {
        this.this$0 = this$0;
        val$fx = fx;
        val$at = location;
        super();
    }

    public void run() {
        if (n >= 6 || !this$0.viewer.isOnline()) {
            cancel();
            return;
        }
        n++;
        double t = (double)n / 5.0;
        val$fx.spawn(val$at, 20, 0.5, 0.5, 0.5, 0.02, t);
        for (int i = 0; i < 12; i++) {
            double a = 6.283185307179586 * (double)i / 12.0;
            val$fx.spawn(val$at, 0, Math.cos(a), 0.15, Math.sin(a), 0.12, (double)i / 11.0);
        }
    }
}