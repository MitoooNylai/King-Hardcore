// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.entity.Player;

static final class ColorPicker extends Menu {
    private static final int MAX = 7;
    private final Fx.Slot slot;
    private final int returnPage;

    ColorPicker(BzlDeathAnimation plugin, Player viewer, Fx.Slot slot, int returnPage) {
        super(plugin, viewer);
        this.slot = slot;
        this.returnPage = returnPage;
    }

    Component title() {
        return plugin.settings.msg("menu.title.colors", new TagResolver[]{Placeholder.unparsed("name", slot.key)});
    }

    private void store(List<String> hexes) {
        save("particles.effects." + slot.key + ".colors", hexes);
        sound("entity.experience_orb.pickup", 1.4F);
    }

    void draw() {
        Fx fx = (Fx)plugin.settings.particles.get(slot);
        List<String> current = new ArrayList<>();
        int i = fx.colors.iterator();
        Color c;
        while (i.hasNext()) {
            c = (Color)i.next();
            current.add(Fx.hex(c));
        }
        header(Material.FIREWORK_STAR, "Warna: " + slot.key, new String[]{"Baris atas = warna sekarang", "(urutan gradasi).", "Partikel tanpa warna", "mengabaikan ini."});
        for (i = 0; i < Math.min(7, current.size()); i++) {
            int at = i;
            set(10 + i, Menu.swatch((Color)fx.colors.get(i), "<color:" + (String)current.get(i) + "><bold>" + (String)current.get(i), List.of("<gray>Warna ke-" + i + 1, "", "<#7FE3FF>Klik <gray>» hapus dari gradasi")), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        if (current.size() == 1) {
            sound("entity.villager.no", 1.0F);
            return;
        }
        List next = new ArrayList(current);
        next.remove(at);
        store(next);
    });
        }
        for (i = 0; i < AdminMenu.PALETTE.size() && 7 + i < INNER.length; i++) {
            int slotIndex = INNER[7 + i];
            c = (Color)AdminMenu.PALETTE.get(i);
            String hex = Fx.hex(c);
            set(slotIndex, Menu.swatch(c, "<color:" + hex + "><bold>" + (String)AdminMenu.PALETTE_NAMES.get(i), List.of("<gray>" + hex, "", "<#7FE3FF>Klik kiri <gray>» pakai warna ini saja", "<#7FE3FF>Klik kanan <gray>» tambah ke gradasi")), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        if (!e.isRightClick()) {
            store(List.of(hex));
        } else {
            label0: {
                if (current.size() >= 7) {
                    sound("entity.villager.no", 1.0F);
                    break label0;
                }
                List next = new ArrayList(current);
                next.add(hex);
                store(next);
            }
        }
    });
        }
        set(47, item(Material.LAVA_BUCKET, "<#FF6B6B><bold>Warna Default", new String[]{"<gray>Kembalikan warna slot ini", "<gray>ke bawaan plugin.", "", "<#7FE3FF>Shift + klik <gray>» reset"}), e -> {
        if (!e.isShiftClick() || !can("bda.menu.edit")) {
            return;
        }
        restore("particles.effects." + slot.key + ".colors");
        sound("block.anvil.use", 1.4F);
    });
        back(49, () -> new AdminMenu.ParticleEdit(plugin, viewer, slot, returnPage));
    }
}