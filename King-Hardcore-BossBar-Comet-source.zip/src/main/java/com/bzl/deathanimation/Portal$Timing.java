// by decompiler.cc
package com.bzl.deathanimation;

static record Timing(int fallStart, int drawStart, int assembleStart, int stepsStart, int ignite) {
}