// by decompiler.cc
package com.bzl.deathanimation;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.entity.Player;

static final class Effects extends Menu {
    Effects(BzlDeathAnimation plugin, Player viewer) {
        super(plugin, viewer);
    }

    Component title() {
        return plugin.settings.msg("menu.title.effects", new TagResolver[0]);
    }

    int rows() {
        return 4;
    }

    void draw() {
        Settings s = plugin.settings;
        header(Material.JUKEBOX, "Efek & Suara", new String[]{"Tambahan di dalam sinematik."});
        toggle(10, Material.MUSIC_DISC_OTHERSIDE, "Musik", "effects.music", s.music, new String[]{"Musik End dari bangun", "sampai mendarat di rumah."});
        toggle(11, Material.ELYTRA, "Sayap Dewi", "effects.wings", s.wings, new String[]{"Sayap mengepak + fanfare", "setelah mendarat."});
        toggle(12, Material.SPYGLASS, "Menoleh Kiri-Kanan", "effects.look-around", s.lookAround, new String[]{"Kepala menoleh saat tiba", "di Nebula."});
        toggle(14, Material.ANVIL, "Goyang Kamera", "effects.screen-shake", s.screenShake, new String[]{"Saat batu jatuh, portal", "menyala, dan mendarat."});
        toggle(15, Material.REDSTONE, "Detak Jantung", "effects.heartbeat", s.heartbeat, new String[]{"Saat terbaring & menoleh."});
        toggle(16, Material.PHANTOM_MEMBRANE, "Suara Napas", "effects.breathing", s.breathing, new String[]{"Napas terengah saat bangun", "dan menoleh."});
        back(31, () -> new AdminMenu.Main(plugin, viewer));
    }
}