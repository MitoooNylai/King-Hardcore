// by decompiler.cc
package com.bzl.deathanimation;

import org.bukkit.Location;
import org.bukkit.entity.Player;

final class Sfx {
    static volatile boolean heartbeatOn = 1;
    static volatile boolean breathingOn = 1;

    private static float note(int semitones) {
        return (float)Math.pow(2.0, (double)(semitones - 12) / 12.0);
    }

    static void major(Location at, String sound, float volume, int root) {
        chord(at, sound, volume, new int[]{root, root + 4, root + 7, root + 12});
    }

    static void minor(Location at, String sound, float volume, int root) {
        chord(at, sound, volume, new int[]{root, root + 3, root + 7});
    }

    private static void chord(Location at, String sound, float volume, int... semitones) {
        for (int s : semitones) {
            at.getWorld().playSound(at, sound, volume, note(Math.min(24, s)));
        }
    }

    static void heartbeat(Player p, float volume, float pitch) {
        if (heartbeatOn) {
            p.playSound(p, "entity.warden.heartbeat", volume, pitch);
        }
    }

    static void breatheIn(Player p) {
        if (!breathingOn) {
            return;
        }
        p.playSound(p, "entity.player.breath", 1.0F, 1.0F);
        p.playSound(p, "entity.breeze.inhale", 1.0F, 1.7F);
        p.playSound(p, "entity.wolf.pant", 0.5F, 1.35F);
    }

    static void breatheOut(Player p) {
        if (!breathingOn) {
            return;
        }
        p.playSound(p, "entity.horse.breathe", 1.0F, 1.3F);
    }

    private Sfx() {
    }

}