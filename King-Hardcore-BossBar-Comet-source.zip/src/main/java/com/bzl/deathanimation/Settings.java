// by decompiler.cc
package com.bzl.deathanimation;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

final class Settings {
    final boolean enabled;
    final boolean totemSaves;
    final Set<String> skipCauses = new HashSet<>();
    final Set<String> disabledWorlds = new HashSet<>();
    final String exemptPermission;
    final double portalDistance;
    final double portalHeight;
    final String body;
    final String nebulaWorld;
    final String returnTo;
    final int durationMinutes;
    final GameMode nebulaMode;
    final boolean ambientParticles;
    final boolean ambientSounds;
    final boolean healOnArrival;
    final boolean blockTeleport;
    final boolean blockCommands;
    final Set<String> allowedCommands = new HashSet<>();
    final boolean arrivalCinematic;
    final boolean releaseCinematic;
    final int titleFadeIn;
    final int titleStay;
    final int titleFadeOut;
    final boolean music;
    final boolean wings;
    final boolean lookAround;
    final boolean screenShake;
    final boolean heartbeat;
    final boolean breathing;
    final double particleAmount;
    final int particleViewDistance;
    final Map<Fx.Slot, Fx> particles = new EnumMap<>(Fx.Slot.class);
    private final YamlConfiguration messages;

    Settings(BzlDeathAnimation plugin) {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration c = plugin.getConfig();
        enabled = c.getBoolean("death-animation.enabled", 1);
        totemSaves = c.getBoolean("death-animation.totem-saves-player", 1);
        GameMode mode = c.getStringList("death-animation.skip-causes").iterator();
        String s;
        while (mode.hasNext()) {
            s = (String)mode.next();
            skipCauses.add(s.toUpperCase(Locale.ROOT));
        }
        portalDistance = c.getDouble("death-animation.portal-distance", 4.5);
        portalHeight = c.getDouble("death-animation.portal-height", 2.5);
        body = c.getString("death-animation.body", "auto").toLowerCase(Locale.ROOT);
        mode = c.getStringList("death-animation.disabled-worlds").iterator();
        while (mode.hasNext()) {
            String w = (String)mode.next();
            disabledWorlds.add(w.toLowerCase(Locale.ROOT));
        }
        exemptPermission = c.getString("death-animation.exempt-permission", "bda.exempt");
        nebulaWorld = c.getString("nebula.world", "nebula");
        durationMinutes = Math.max(1, c.getInt("nebula.duration-minutes", 10));
        returnTo = c.getString("nebula.return-to", "death").toLowerCase(Locale.ROOT);
        Settings $stack0;
        GameMode $stack1;
        try {
            mode = GameMode.valueOf(c.getString("nebula.gamemode", "ADVENTURE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            label0: {
                IllegalArgumentException $exc0;
                IllegalArgumentException e = $exc0;
                mode = GameMode.ADVENTURE;
                $stack0 = this;
                if (mode == GameMode.SPECTATOR) {
                    $stack1 = GameMode.ADVENTURE;
                    break label0;
                }
                $stack1 = mode;
            }
        }
        $stack0.nebulaMode = $stack1;
        ambientParticles = c.getBoolean("nebula.ambient-particles", 1);
        ambientSounds = c.getBoolean("nebula.ambient-sounds", 1);
        healOnArrival = c.getBoolean("nebula.heal-on-arrival", 1);
        blockTeleport = c.getBoolean("nebula.block-teleport-out", 1);
        blockCommands = c.getBoolean("nebula.block-commands", 1);
        s = c.getStringList("nebula.allowed-commands").iterator();
        String cmd;
        while (s.hasNext()) {
            cmd = (String)s.next();
            allowedCommands.add(cmd.toLowerCase(Locale.ROOT).replaceFirst("^/", ""));
        }
        arrivalCinematic = c.getBoolean("nebula.arrival-cinematic", 1);
        releaseCinematic = c.getBoolean("nebula.release-cinematic", 1);
        titleFadeIn = Math.max(0, c.getInt("nebula.title.fade-in-ticks", 6));
        titleStay = Math.max(0, c.getInt("nebula.title.stay-ticks", 60));
        titleFadeOut = Math.max(0, c.getInt("nebula.title.fade-out-ticks", 20));
        music = c.getBoolean("effects.music", 1);
        wings = c.getBoolean("effects.wings", 1);
        lookAround = c.getBoolean("effects.look-around", 1);
        screenShake = c.getBoolean("effects.screen-shake", 1);
        heartbeat = c.getBoolean("effects.heartbeat", 1);
        breathing = c.getBoolean("effects.breathing", 1);
        Sfx.heartbeatOn = heartbeat;
        Sfx.breathingOn = breathing;
        particleAmount = Math.max(0.0, c.getDouble("particles.amount-multiplier", 1.0));
        particleViewDistance = Math.max(8, c.getInt("particles.view-distance", 48));
        Fx.resetWarnings();
        s = Fx.Slot.values();
        cmd = s.length;
        for (int i = 0; i < cmd; i++) {
            Fx.Slot slot = s[i];
            particles.put(slot, Fx.load(c, slot, particleAmount, particleViewDistance));
        }
        Fx.install(particles);
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", 0);
        }
        messages = YamlConfiguration.loadConfiguration(file);
        InputStream bundled = plugin.getResource("messages.yml");
        if (bundled != null) {
            messages.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(bundled, StandardCharsets.UTF_8)));
        }
    }

    boolean has(String key) {
        return !raw(key).isBlank();
    }

    private String raw(String key) {
        String value = messages.getString(key);
        return value == null ? "" : value;
    }

    Component msg(String key, TagResolver... placeholders) {
        TagResolver all = TagResolver.resolver(new TagResolver[]{TagResolver.resolver(placeholders), Placeholder.parsed("prefix", raw("prefix"))});
        return MiniMessage.miniMessage().deserialize(raw(key), all);
    }
}