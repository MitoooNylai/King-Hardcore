// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Material;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkEffectMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

abstract class Menu implements InventoryHolder {
    static final int[] INNER = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    static final String NAME = "<#B8F1FF><bold>";
    static final String HINT = "<#7FE3FF>";
    static final String ON = "<#5CFF8A>";
    static final String OFF = "<#FF6B6B>";
    final BzlDeathAnimation plugin;
    final Player viewer;
    private final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<>();
    private Inventory inventory;

    Menu(BzlDeathAnimation plugin, Player viewer) {
        this.plugin = plugin;
        this.viewer = viewer;
    }

    abstract Component title();

    abstract void draw();

    int rows() {
        return 6;
    }

    boolean live() {
        return 0;
    }

    @NotNull
    @NotNull
    public Inventory getInventory() {
        return inventory;
    }

    final void open() {
        inventory = Bukkit.createInventory(this, rows() * 9, title());
        redraw();
        viewer.openInventory(inventory);
    }

    final void redraw() {
        actions.clear();
        inventory.clear();
        frame();
        draw();
    }

    final void go(Menu next) {
        sound("item.book.page_turn", 1.2F);
        Objects.requireNonNull(next);
        Bukkit.getScheduler().runTask(plugin, next::open);
    }

    final void later(Runnable r) {
        Bukkit.getScheduler().runTask(plugin, r);
    }

    private void frame() {
        int last = rows() - 1;
        ItemStack border = pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack accent = pane(Material.LIGHT_BLUE_STAINED_GLASS_PANE);
        ItemStack corner = pane(Material.CYAN_STAINED_GLASS_PANE);
        for (int i = 0; i < rows() * 9; i++) {
            int r = i / 9;
            int c = i % 9;
            int $stack0 = r == 0 || r == last;
            boolean hRow = $stack0;
            if (hRow || c == 0 || c == 8) {
                $stack0 = inventory;
                int $stack1 = i;
                ItemStack $stack2;
                if (hRow && (c == 0 || c == 8)) {
                    $stack2 = corner;
                } else {
                    label0: {
                        if (hRow && (c == 1 || c == 7)) {
                            $stack2 = accent;
                            break label0;
                        }
                        $stack2 = border;
                    }
                }
                $stack0.setItem($stack1, $stack2);
            }
        }
    }

    final void set(int slot, ItemStack item, Consumer<InventoryClickEvent> action) {
        inventory.setItem(slot, item);
        if (action != null) {
            actions.put(slot, action);
        } else {
            actions.remove(slot);
        }
    }

    final void set(int slot, ItemStack item) {
        set(slot, item, null);
    }

    final void header(Material icon, String name, String... desc) {
        set(4, glow(item(icon, "<#B8F1FF><bold>" + name, gray(desc)), 1));
    }

    final void back(int slot, Supplier<Menu> to) {
        set(slot, item(Material.ARROW, "<#7FE3FF><bold>« Kembali", new String[0]), e -> go((Menu)to.get()));
    }

    final void link(int slot, Material icon, String name, String permission, Supplier<Menu> to, String... desc) {
        List lore = gray(desc);
        lore.add("");
        lore.add(viewer.hasPermission(permission) ? "<#7FE3FF>» <gray>Klik untuk membuka" : "<#FF6B6B>✖ Butuh izin <white>" + permission);
        set(slot, item(icon, "<#B8F1FF><bold>" + name, lore), e -> {
        if (can(permission)) {
            go((Menu)to.get());
        }
    });
    }

    final void button(int slot, ItemStack icon, String permission, Consumer<InventoryClickEvent> action) {
        if (!viewer.hasPermission(permission)) {
            ItemMeta meta = icon.getItemMeta();
            List lore = meta.lore() == null ? new ArrayList() : new ArrayList(meta.lore());
            lore.add(mm("<#FF6B6B>✖ Butuh izin <white>" + permission));
            meta.lore(lore);
            icon.setItemMeta(meta);
        }
        set(slot, icon, e -> {
        if (can(permission)) {
            action.accept(e);
        }
    });
    }

    final void toggle(int slot, Material icon, String name, String path, boolean value, String... desc) {
        List lore = gray(desc);
        lore.add("");
        List<String> $stack0 = lore;
        String $stack1 = value ? "<#5CFF8A>● AKTIF" : "<#FF6B6B>● NONAKTIF";
        $stack0.add("<dark_gray>Status: " + $stack1);
        lore.add("");
        $stack0 = lore;
        $stack1 = value ? "mematikan" : "menyalakan";
        $stack0.add("<#7FE3FF>» <gray>Klik untuk " + $stack1);
        $stack0 = this;
        $stack1 = slot;
        $stack0.set($stack1, glow(item(icon, (value ? "<#5CFF8A>" : "<#FF6B6B>") + "<bold>" + name, lore), value), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        Menu $stack0 = this;
        String $stack1 = path;
        int $stack2 = !value;
        $stack0.save($stack1, $stack2);
        $stack0 = this;
        $stack1 = "block.note_block.pling";
        $stack2 = value ? 0.7F : 1.6F;
        $stack0.sound($stack1, $stack2);
    });
    }

    final void number(int slot, Material icon, String name, String path, double value, double step, double big, double min, double max, boolean whole, String unit, String... desc) {
        List lore = gray(desc);
        lore.add("");
        lore.add("<gray>Nilai: <white><bold>" + Fx.num(value) + "</bold>" + unit + " <dark_gray>(" + Fx.num(min) + " - " + Fx.num(max) + ")");
        lore.add("");
        lore.add("<#7FE3FF>Klik kiri <gray>» +" + Fx.num(step) + "   <#7FE3FF>Klik kanan <gray>» -" + Fx.num(step));
        lore.add("<#7FE3FF>Shift + klik <gray>» ±" + Fx.num(big));
        set(slot, item(icon, "<#B8F1FF><bold>" + name, lore), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        double $stack0 = e.isShiftClick() ? big : step;
        int $stack1 = e.isRightClick() ? -1 : 1;
        double d = $stack0 * (double)$stack1;
        double v = Math.max(min, Math.min(max, (double)Math.round((value + d) * 100.0) / 100.0));
        if (v == value) {
            sound("block.note_block.bass", 0.6F);
            return;
        }
        $stack0 = this;
        $stack1 = path;
        Integer $stack2 = whole ? (int)Math.round(v) : v;
        $stack0.save($stack1, $stack2);
        $stack0 = this;
        $stack1 = "block.note_block.hat";
        $stack2 = e.isRightClick() ? 0.8F : 1.4F;
        $stack0.sound($stack1, $stack2);
    });
    }

    final void cycle(int slot, Material icon, String name, String path, String current, List<String> options, List<String> labels, String... desc) {
        List lore = gray(desc);
        lore.add("");
        int at = Math.max(0, options.indexOf(current));
        for (int i = 0; i < options.size(); i++) {
            lore.add(i == at ? "<#5CFF8A>▶ <white>" + (String)labels.get(i) : "<dark_gray>  " + (String)labels.get(i));
        }
        lore.add("");
        lore.add("<#7FE3FF>Klik kiri <gray>» berikutnya   <#7FE3FF>Klik kanan <gray>» sebelumnya");
        set(slot, item(icon, "<#B8F1FF><bold>" + name, lore), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        int n = options.size();
        save(path, options.get(Math.floorMod(at + (e.isRightClick() ? -1 : 1), n)));
        sound("block.note_block.hat", 1.2F);
    });
    }

    final void save(String path, Object value) {
        plugin.getConfig().set(path, value);
        plugin.saveConfig();
        plugin.settings = new Settings(plugin);
        redraw();
    }

    final void restore(String path) {
        Configuration defaults = plugin.getConfig().getDefaults();
        Menu $stack0 = defaults == null ? null : defaults.get(path);
        Object def = $stack0;
        $stack0 = this;
        String $stack1 = path;
        Map $stack2;
        if (def instanceof ConfigurationSection s) {
            $stack2 = s.getValues(0);
        } else {
            $stack2 = def;
        }
        $stack0.save($stack1, $stack2);
    }

    final boolean can(String permission) {
        if (viewer.hasPermission(permission)) {
            return 1;
        }
        plugin.tell(viewer, "command.no-permission", new String[0]);
        sound("entity.villager.no", 1.0F);
        return 0;
    }

    final void sound(String key, float pitch) {
        viewer.playSound(viewer, key, 0.6F, pitch);
    }

    static Component mm(String text) {
        return MiniMessage.miniMessage().deserialize(text).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    static String esc(String text) {
        return MiniMessage.miniMessage().escapeTags(text);
    }

    static List<String> gray(String... lines) {
        List<String> out = new ArrayList<>();
        for (String l : lines) {
            out.add("<gray>" + l);
        }
        return out;
    }

    static ItemStack item(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(mm(name));
        List lines = new ArrayList();
        for (String l : lore) {
            lines.add(mm(l));
        }
        meta.lore(lines);
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    static ItemStack item(Material material, String name, String... lore) {
        return item(material, name, List.of(lore));
    }

    static ItemStack glow(ItemStack item, boolean on) {
        ItemMeta meta = item.getItemMeta();
        meta.setEnchantmentGlintOverride(on);
        item.setItemMeta(meta);
        return item;
    }

    static ItemStack swatch(Color color, String name, List<String> lore) {
        ItemStack item = item(Material.FIREWORK_STAR, name, lore);
        FireworkEffectMeta meta = (FireworkEffectMeta)item.getItemMeta();
        meta.setEffect(FireworkEffect.builder().withColor(color).build());
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack pane(Material m) {
        ItemStack item = new ItemStack(m);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.empty());
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    static void start(BzlDeathAnimation plugin) {
        Bukkit.getPluginManager().registerEvents(new Menu.Events(), plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
        for (Player p : Bukkit.getOnlinePlayers()) {
            InventoryHolder patt0$temp = p.getOpenInventory().getTopInventory().getHolder(0);
            if (patt0$temp instanceof Menu m) {
                if (m.live()) {
                    m.redraw();
                }
            }
        }
    }, 20L, 20L);
    }

    static void closeAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder(0) instanceof Menu) {
                p.closeInventory();
            }
        }
    }

}