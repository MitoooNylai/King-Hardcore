// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import org.joml.Quaternionf;
import org.joml.Vector3f;

private static final class Stone {
    final List<Portal.Piece> pieces = new ArrayList<>();
    Vector3f finalPos;
    Vector3f groundPos;
    Vector3f skyPos;
    Quaternionf finalRot;
    Quaternionf groundRot;
    Quaternionf skyRot;
    int fallStart;
    int assembleStart;
    int order;
    float phase;
    boolean falling;
    boolean landed;
    boolean lifted;
    boolean locked;

    private Stone() {
    }
}