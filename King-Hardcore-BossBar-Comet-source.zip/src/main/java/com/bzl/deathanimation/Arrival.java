// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

final class Arrival extends BukkitRunnable implements Sequence {
    private static final int OPEN = 10;
    private static final int EMERGE = 12;
    private static final int EMERGE_END = 26;
    private static final int CHASE_FROM = 30;
    private static final int LOOK_HOLD = 74;
    private static final int WINGS_HOLD = 104;
    private static final int WINGS_FROM = 10;
    private static final int BEATS = 3;
    private static final int BEAT_TICKS = 22;
    private static final int CAM_SMOOTH = 3;
    private static final Vector UP = new Vector(0, 1, 0);
    private static final double HIDDEN_ABOVE = 2.4;
    private static final float[] DESCEND_POSE = new float[]{10.0F, -150.0F, 30.0F, 15.0F, -10.0F, 20.0F, 0.0F};
    private static final float[] CROUCH = new float[]{-20.0F, -20.0F, 20.0F, -40.0F, -40.0F, 20.0F, 0.0F};
    private static final float[] STAND = new float[]{0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F};
    private final Player player;
    private final World world;
    private final Location dest;
    private final Location bodyTop;
    private final Location portalAt;
    private final Vector forward;
    private final Vector right;
    private final double drop;
    private final int landTick;
    private final int endTick;
    private final boolean wings;
    private final GameMode mode;
    private final Runnable onLand;
    private final NamespacedKey pendingKey;
    private Body body;
    private ItemDisplay camera;
    private Rift rift;
    private final float yaw;
    private final BzlDeathAnimation plugin;
    private final List<long[]> tickets = new ArrayList<>();
    private int warmup;
    private int liveFor;
    private boolean ready;
    private double shake;
    private double bodyOy = 2.4;
    private int tick;
    private boolean done;

    Arrival(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, boolean wings, Runnable onLand) {
        this.player = player;
        this.wings = wings;
        this.dest = dest.clone();
        world = dest.getWorld();
        this.mode = mode;
        this.onLand = onLand;
        pendingKey = plugin.pendingKey;
        this.plugin = plugin;
        yaw = dest.getYaw();
        forward = new Vector(-Math.sin(Math.toRadians((double)yaw)), 0.0, Math.cos(Math.toRadians((double)yaw)));
        right = forward.getCrossProduct(UP).normalize();
        drop = Descent.clearAbove(dest);
        bodyTop = dest.clone().add(0.0, drop, 0.0);
        portalAt = bodyTop.clone().add(0.0, 2.2, 0.0);
        landTick = 26 + (int)Math.max(50.0, Math.min(90.0, drop * 4.0));
        endTick = landTick + (wings ? 104 : 74);
        int cx = dest.getBlockX() >> 4;
        int cz = dest.getBlockZ() >> 4;
        for (int x = cx - 1; x <= cx + 1; x++) {
            for (int z = cz - 1; z <= cz + 1; z++) {
                world.addPluginChunkTicket(x, z, plugin);
                tickets.add(new long[]{(long)x, (long)z});
            }
        }
        player.getPersistentDataContainer().set(pendingKey, PersistentDataType.STRING, mode.name() + ";" + Nebula.serialize(dest));
        player.setGameMode(GameMode.SPECTATOR);
        player.teleport(shot());
        runTaskTimer(plugin, 1L, 1L);
    }

    private void begin() {
        camera = (ItemDisplay)world.spawn(shot(), ItemDisplay.class, d -> {
        d.setPersistent(0);
        d.addScoreboardTag("bda_fx");
        d.setTeleportDuration(3);
    });
        spawnBody();
        rift = new Rift(portalAt, 1.6F, 0);
        world.playSound(portalAt, "block.end_portal.spawn", 0.5F, 1.4F);
        world.playSound(portalAt, "entity.lightning_bolt.thunder", 0.4F, 1.6F);
        world.playSound(portalAt, "block.beacon.activate", 1.0F, 1.2F);
    }

    private void spawnBody() {
        body = Body.create(bodyTop, yaw, player, plugin.skinOf(player), plugin.settings.body);
        body.pose(Body.Stage.DESCEND, 1.0F, DESCEND_POSE, 0.0, 2.4, 0.0, 1.0F);
    }

    public void run() {
        if (!player.isOnline()) {
            abort();
            return;
        }
        if (!ready) {
            warmup++;
            int $stack0 = player.getWorld().equals(world) && clientHas(shot()) && clientAround(dest);
            boolean live = $stack0;
            $stack0 = this;
            $stack0.liveFor = live ? liveFor + 1 : 0;
            if (liveFor >= 30 || warmup > 140) {
                ready = 1;
                if (!player.getWorld().equals(world)) {
                    finish();
                    return;
                }
                try {
                    begin();
                } catch (RuntimeException e) {
                    plugin.getLogger().log(Level.SEVERE, "Arrival cinematic failed for " + player.getName() + "; landing them directly.", e);
                    finish();
                    return;
                }
            }
            Location hold = shot();
            if (!player.getWorld().equals(hold.getWorld()) || player.getLocation().distanceSquared(hold) > 0.01) {
                player.teleport(hold);
            }
            return;
        }
        tick++;
        if (tick == 2 || tick == 8 || (tick == 20 || tick == 40)) {
            BzlDeathAnimation.unwatch(player);
            plugin.watch(player, camera);
        }
        if (tick > 2 && player.getSpectatorTarget() != camera) {
            plugin.watch(player, camera);
        }
        if (tick == 6 && !body.ready()) {
            plugin.getLogger().warning("Arrival body for " + player.getName() + " was not in the world; respawning it.");
            body.remove();
            spawnBody();
        }
        int cut = landTick - 6;
        if (tick == cut - 1) {
            camera.setTeleportDuration(0);
        }
        if (tick == cut + 1) {
            camera.setTeleportDuration(3);
        }
        portal();
        bodyScene();
        if (wings && tick >= landTick + 10) {
            wingShow(tick - landTick - 10);
        }
        camera.teleport(shot());
        if (tick >= endTick) {
            finish();
        }
    }

    private void portal() {
        if (rift == null) {
            return;
        }
        int close = 44;
        if (tick < close) {
            rift.size(outBack(k((float)tick, 0.0F, 10.0F)), 2, tick);
        } else {
            label0: {
                if (tick <= close + 12) {
                    rift.size(1.0F - inCubic(k((float)tick, (float)close, (float)(close + 12))), 2, tick);
                    break label0;
                }
                rift.remove();
                rift = null;
                world.playSound(portalAt, "block.beacon.deactivate", 0.8F, 1.4F);
                return;
            }
        }
        for (int arm = 0; arm < 2; arm++) {
            for (int j = 0; j < 5; j++) {
                double t = (double)j / 4.0;
                double a = (double)tick * 0.25 + (double)arm * 3.141592653589793 + t * 2.2;
                double rad = 1.6 * (0.25 + 0.8 * t);
                Fx.get(Fx.Slot.RIFT_SWIRL).spawn(portalAt.clone().add(Math.cos(a) * rad, -0.1, Math.sin(a) * rad), 1, 0.0, 0.0, 0.0, 0.0, t);
            }
        }
        if (tick == 12) {
            world.playSound(portalAt, "entity.enderman.teleport", 1.0F, 0.8F);
        }
    }

    private void bodyScene() {
        if (tick < 12) {
            return;
        }
        if (tick < landTick) {
            float emerge = smooth(k((float)tick, 12.0F, 26.0F));
            float q = k((float)tick, 26.0F, (float)landTick);
            double fall = 1.0 - Math.pow((double)(1.0F - q), 1.6);
            double oy = -drop * fall + 2.4 * (double)(1.0F - emerge);
            bodyOy = oy;
            body.pose(Body.Stage.DESCEND, 1.0F, DESCEND_POSE, 0.0, oy, 0.0, 1.0F);
            Location at = bodyTop.clone().add(0.0, oy + 1.0, 0.0);
            Fx.get(Fx.Slot.DESCENT_TRAIL).spawn(at, 4, 0.28, 0.55, 0.28, 0.01);
            ring(1.2 + Math.min(1.5, drop * (1.0 - fall) * 0.08));
            if (rift != null) {
                beam();
            }
            if (tick == 26) {
                player.playSound(player, "item.elytra.flying", 0.5F, 1.3F);
            }
            return;
        }
        bodyOy = -drop;
        float g = k((float)tick, (float)landTick, (float)(landTick + 14));
        if (wings || g < 1.0F || !plugin.settings.lookAround) {
            body.pose(Body.Stage.LAND, g, g < 0.5F ? CROUCH : STAND, 0.0, -drop, 0.0, 1.0F);
        } else {
            int t = tick - landTick - 14;
            float pitch = 4.0F + (float)Math.sin((double)t * 0.13) * 7.0F;
            body.pose(Body.Stage.LOOK, k((float)t, 0.0F, 60.0F), new float[]{headYaw(t), 0.0F, 0.0F, 0.0F, 0.0F, pitch, 0.0F}, 0.0, -drop, 0.0, 1.0F);
            if (t % 12 == 0) {
                Sfx.breatheIn(player);
            }
            if (t % 12 == 6) {
                Sfx.breatheOut(player);
            }
            if (t == 10 || t == 30) {
                player.playSound(player, "entity.sniffer.sniffing", 0.7F, 1.3F);
            }
            if (t % 14 == 0) {
                Sfx.heartbeat(player, 0.8F, 1.15F);
            }
            if (t == 26) {
                player.playSound(player, "block.amethyst_block.chime", 0.6F, 0.8F);
            }
        }
        if (tick == landTick) {
            touchdown();
        }
    }

    private static float headYaw(int t) {
        if (t < 6) {
            return 0.0F;
        }
        if (t < 16) {
            return -55.0F * smooth(k((float)t, 6.0F, 16.0F));
        }
        if (t < 24) {
            return -55.0F;
        }
        if (t < 38) {
            return -55.0F + 110.0F * smooth(k((float)t, 24.0F, 38.0F));
        }
        if (t < 46) {
            return 55.0F;
        }
        if (t < 56) {
            return 55.0F * (1.0F - smooth(k((float)t, 46.0F, 56.0F)));
        }
        return 0.0F;
    }

    private void touchdown() {
        for (int i = 0; i < 28; i++) {
            double a = (double)i * 3.141592653589793 * 2.0 / 28.0;
            Location p = dest.clone().add(Math.cos(a) * 0.4, 0.1, Math.sin(a) * 0.4);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(p, 0, Math.cos(a), 0.06, Math.sin(a), 0.3);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(p, 0, Math.cos(a), 0.06, Math.sin(a), 0.3);
        }
        flash(dest.clone().add(0.0, 1.0, 0.0));
        world.playSound(dest, "entity.generic.big_fall", 1.0F, 0.7F);
        world.playSound(dest, "block.respawn_anchor.deplete", 1.0F, 1.2F);
        world.playSound(dest, "block.amethyst_block.resonate", 1.0F, 1.0F);
        if (!wings) {
            Sfx.minor(dest, "block.note_block.bell", 0.8F, 3);
        }
        player.stopSound("item.elytra.flying");
        shake += 0.35;
    }

    private void wingShow(int t) {
        Location center = dest.clone().add(0.0, 1.0, 0.0);
        float unfold = smooth(k((float)t, 0.0F, 14.0F));
        int beatsEnd = 80;
        double flap = 0.0;
        if (t >= 14 && t < beatsEnd) {
            double phase = (double)(t - 14) / 22.0;
            flap = Math.sin(phase * 3.141592653589793 * 2.0) * 1.15;
        } else if (t >= beatsEnd) {
            flap = Math.sin((double)(t - beatsEnd) * 0.15) * 0.15;
        }
        if (t < 0 || tick >= endTick - 2) {
            return;
        }
        if (tick < endTick - 6 && tick % 2 == 0) {
            drawWings(center, unfold, flap);
        }
        if (t == 0) {
            world.playSound(dest, "block.beacon.power_select", 1.0F, 1.6F);
            world.playSound(dest, "block.amethyst_block.resonate", 1.0F, 1.4F);
            world.playSound(dest, "item.armor.equip_elytra", 1.0F, 0.8F);
            Fx.get(Fx.Slot.WINGS_OPEN).spawn(center, 40, 0.4, 0.6, 0.4, 0.15);
        }
        if (t == 14) {
            player.playSound(player, "ui.toast.challenge_complete", 0.9F, 1.0F);
            Sfx.major(dest, "block.note_block.bell", 1.0F, 6);
            Sfx.major(dest, "block.note_block.chime", 0.7F, 13);
            world.playSound(dest, "entity.player.levelup", 1.0F, 0.8F);
            world.playSound(dest, "entity.firework_rocket.large_blast", 1.0F, 1.0F);
            world.playSound(dest, "entity.firework_rocket.twinkle", 1.0F, 1.2F);
            Fx.get(Fx.Slot.WINGS_OPEN).spawn(center, 120, 0.6, 1.0, 0.6, 0.5);
            flash(center);
            shake += 0.3;
        }
        if (t >= 14 && t < beatsEnd && (t - 14) % 22 == 11) {
            int beat = (t - 14) / 22;
            world.playSound(dest, "entity.ender_dragon.flap", 1.0F, 1.1F + (float)beat * 0.15F);
            world.playSound(dest, "entity.breeze.wind_burst", 0.8F, 1.2F + (float)beat * 0.1F);
            Sfx.major(dest, "block.note_block.bell", 0.6F, 8 + beat * 2);
            for (int i = 0; i < 24; i++) {
                double a = (double)i * 3.141592653589793 * 2.0 / 24.0;
                Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(dest.clone().add(Math.cos(a) * 0.6, 0.15, Math.sin(a) * 0.6), 0, Math.cos(a), 0.01, Math.sin(a), 0.35);
            }
            Fx.get(Fx.Slot.WING_BEAT).spawn(center, 40, 2.2, 1.0, 2.2, 0.02);
            shake += 0.15;
        }
        if (tick == endTick - 6) {
            Location c = center.clone().add(0.0, 0.4, 0.0);
            Fx.get(Fx.Slot.WINGS_BURST).spawn(c, 360, 2.4, 1.3, 2.4, 0.04);
            Sfx.major(dest, "block.note_block.bell", 1.0F, 13);
            world.playSound(dest, "block.respawn_anchor.set_spawn", 1.0F, 1.3F);
            world.playSound(dest, "entity.firework_rocket.twinkle_far", 1.0F, 1.0F);
        }
    }

    private void drawWings(Location center, float unfold, double flap) {
        Vector back = forward.clone().multiply(-1);
        Location shoulder = center.clone().add(0.0, 0.35, 0.0).add(back.clone().multiply(0.3));
        double span = 6.2 * (double)unfold;
        int s = -1;
        int i;
        double a;
        for (; s <= 1; s += 2) {
            Vector out = right.clone().multiply(s);
            Vector o = out.clone().multiply(Math.cos(flap)).add(UP.clone().multiply(Math.sin(flap)));
            Vector l = UP.clone().multiply(Math.cos(flap)).subtract(out.clone().multiply(Math.sin(flap)));
            Fx wing = Fx.get(Fx.Slot.WINGS);
            for (i = 0; i <= 24; i++) {
                wing.spawn(arm(shoulder, o, l, back, (double)i / 24.0, span), 1, 0.0, 0.0, 0.0, 0.0, 0.0);
            }
            for (int f = 0; f < 9; f++) {
                a = 0.14 + (double)f * 0.105;
                Location root = arm(shoulder, o, l, back, a, span);
                double len = (0.9 + 1.4 * (1.0 - Math.min(1.0, Math.abs(a - 0.6) * 1.6))) * (double)unfold;
                Vector dir = l.clone().multiply(-0.85).add(o.clone().multiply(0.35)).add(back.clone().multiply(0.15)).normalize();
                for (int j = 1; j <= 5; j++) {
                    Location p = root.clone().add(dir.clone().multiply(len * (double)j / 5.0));
                    wing.spawn(p, 1, 0.0, 0.0, 0.0, 0.0, (double)j / 5.0);
                }
            }
            Fx.get(Fx.Slot.WING_TIPS).spawn(arm(shoulder, o, l, back, 1.0, span), 1, 0.0, 0.0, 0.0, 0.005);
        }
        Location crown = center.clone().add(0.0, 1.15, 0.0);
        for (i = 0; i < 14; i++) {
            a = (double)tick * 0.08 + (double)i * 3.141592653589793 * 2.0 / 14.0;
            Fx.get(Fx.Slot.HALO).spawn(crown.clone().add(Math.cos(a) * 0.34, 0.0, Math.sin(a) * 0.34), 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private static Location arm(Location shoulder, Vector out, Vector lift, Vector back, double a, double span) {
        return shoulder.clone().add(out.clone().multiply(a * span)).add(lift.clone().multiply(Math.sin(a * 3.141592653589793 * 0.85) * 0.9 + a * 0.4)).add(back.clone().multiply(a * 0.4));
    }

    private void ring(double r) {
        if (tick % 2 != 0) {
            return;
        }
        for (int i = 0; i < 18; i++) {
            double a = (double)tick * 0.12 + (double)i * 3.141592653589793 * 2.0 / 18.0;
            Fx.get(Fx.Slot.LANDING_RING).spawn(dest.clone().add(Math.cos(a) * r, 0.1, Math.sin(a) * r), 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void beam() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < 3; i++) {
            Fx.get(Fx.Slot.LANDING_BEAM).spawn(dest.clone().add(r.nextDouble(-0.3, 0.3), r.nextDouble(0.0, drop + 2.0), r.nextDouble(-0.3, 0.3)), 1, 0.0, 0.0, 0.0, 0.005);
        }
    }

    private static void flash(Location at) {
        Fx.get(Fx.Slot.FLASH).spawn(at, 1, 0.0, 0.0, 0.0, 0.0);
    }

    private boolean clientAround(Location at) {
        for (int dx = -16; dx <= 16; dx += 16) {
            for (int dz = -16; dz <= 16; dz += 16) {
                if (!clientHas(at.clone().add((double)dx, 0.0, (double)dz))) {
                    return 0;
                }
            }
        }
        return 1;
    }

    private boolean clientHas(Location at) {
        long x = (long)(at.getBlockX() >> 4);
        long z = (long)(at.getBlockZ() >> 4);
        return player.isChunkSent(x & 4294967295L | (z & 4294967295L) << 32);
    }

    private Location shot() {
        Location center = bodyTop.clone().add(0.0, bodyOy + 1.0, 0.0);
        Location pos;
        Location look;
        if (tick < landTick - 6) {
            Location open = center.clone().add(right.clone().multiply(4.5)).add(0.0, -2.2, 0.0);
            Location openLook = portalAt.clone().subtract(0.0, 0.6, 0.0);
            Location chase = center.clone().subtract(forward.clone().multiply(4.2)).add(0.0, 1.8, 0.0);
            Location chaseLook = center.clone().add(forward.clone().multiply(0.6)).subtract(0.0, 0.3, 0.0);
            float b = smooth(k((float)tick, 12.0F, 30.0F));
            pos = lerp(open, chase, b);
            look = lerp(openLook, chaseLook, b);
        } else {
            label0: {
                float t;
                if (wings) {
                    t = smooth(k((float)tick, (float)(landTick - 6), (float)endTick));
                    pos = dest.clone().add(forward.clone().multiply(8.0F + 3.0F * t)).add(right.clone().multiply(1.0)).add(0.0, 1.2 + 1.2 * (double)t, 0.0);
                    look = dest.clone().add(0.0, 1.9, 0.0);
                    break label0;
                }
                t = smooth(k((float)tick, (float)(landTick - 6), (float)(landTick + 10)));
                Location hero = dest.clone().add(forward.clone().multiply(4.5 - (double)t)).add(right.clone().multiply(1.0)).add(0.0, 0.5, 0.0);
                Location heroLook = dest.clone().add(0.0, 1.0, 0.0);
                float c = smooth(k((float)tick, (float)(landTick + 12), (float)(landTick + 36)));
                Location close = dest.clone().add(forward.clone().multiply(1.8)).add(right.clone().multiply(0.35)).add(0.0, 1.65, 0.0);
                Location closeLook = dest.clone().add(0.0, 1.6, 0.0);
                pos = lerp(hero, close, c);
                look = lerp(heroLook, closeLook, c);
            }
        }
        if (!plugin.settings.screenShake) {
            shake = 0.0;
        }
        if (shake > 0.01) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            pos = pos.clone().add(r.nextDouble(-shake, shake), r.nextDouble(-shake, shake), r.nextDouble(-shake, shake));
            shake *= 0.8;
        }
        return clip(pos, look);
    }

    private Location clip(Location pos, Location look) {
        Vector off = pos.toVector().subtract(look.toVector());
        double len = off.length();
        if (len > 0.01) {
            RayTraceResult hit = world.rayTraceBlocks(look, off.clone().normalize(), len, FluidCollisionMode.NEVER, 1);
            if (hit != null) {
                off.normalize().multiply(Math.max(0.8, hit.getHitPosition().distance(look.toVector()) - 0.4));
            }
        }
        Location cam = look.clone().add(off);
        return cam.setDirection(look.toVector().subtract(cam.toVector()));
    }

    private static Location lerp(Location a, Location b, float t) {
        return a.clone().add(b.toVector().subtract(a.toVector()).multiply(t));
    }

    private void finish() {
        if (done) {
            return;
        }
        done = 1;
        cancel();
        if (body != null) {
            body.remove();
        }
        if (rift != null) {
            rift.remove();
        }
        if (camera != null) {
            camera.remove();
        }
        BzlDeathAnimation.unwatch(player);
        Location at = dest.clone();
        at.setPitch(0.0F);
        boolean arrived = player.teleport(at) && player.getWorld().equals(dest.getWorld());
        player.setGameMode(mode);
        player.setFallDistance(0.0F);
        if (arrived) {
            player.getPersistentDataContainer().remove(pendingKey);
        }
        player.stopSound("item.elytra.flying");
        for (long[] t : tickets) {
            world.removePluginChunkTicket((int)t[0], (int)t[1], plugin);
        }
        onLand.run();
    }

    public void abort() {
        finish();
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0F, Math.max(0.0F, (t - a) / (b - a)));
    }

    private static float smooth(float x) {
        return x * x * (3.0F - 2.0F * x);
    }

    private static float inCubic(float x) {
        return x * x * x;
    }

    private static float outBack(float x) {
        if (x <= 0.0F) {
            return 0.0F;
        }
        float c1 = 1.70158F;
        float c3 = c1 + 1.0F;
        return 1.0F + c3 * (float)Math.pow((double)(x - 1.0F), 3.0) + c1 * (float)Math.pow((double)(x - 1.0F), 2.0);
    }

}