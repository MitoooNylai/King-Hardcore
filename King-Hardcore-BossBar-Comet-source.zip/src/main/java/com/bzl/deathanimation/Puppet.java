// by decompiler.cc
package com.bzl.deathanimation;

import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.util.Transformation;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

final class Puppet implements Body {
    private static final float HEAD_Y_FIX = 0.25F;
    private static final float HEAD_YAW_FIX = 0.0F;
    private final BlockDisplay torso;
    private final BlockDisplay armL;
    private final BlockDisplay armR;
    private final BlockDisplay legL;
    private final BlockDisplay legR;
    private final ItemDisplay head;
    private final List<Display> parts;
    private final float yawRad;
    private boolean removed;

    public void pose(Body.Stage stage, float progress, float[] p, double ox, double oy, double oz, float scale) {
        if (stage == Body.Stage.LOOK) {
            pose(ox, oy, oz, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, p[5], scale, 2);
            return;
        }
        pose(ox, oy + (double)p[6], oz, p[0], p[1], p[2], p[3], p[4], p[5], scale, 2);
    }

    Puppet(Location feet, float yaw, Player owner, Puppet.Colors colors) {
        Location at = feet.clone();
        at.setYaw(0.0F);
        at.setPitch(0.0F);
        yawRad = (float)-Math.toRadians((double)yaw);
        torso = block(at, colors.torso);
        armL = block(at, colors.arms);
        armR = block(at, colors.arms);
        legL = block(at, colors.legs);
        legR = block(at, colors.legs);
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta)skull.getItemMeta();
        meta.setPlayerProfile(owner.getPlayerProfile());
        skull.setItemMeta(meta);
        head = (ItemDisplay)at.getWorld().spawn(at, ItemDisplay.class, d -> {
        d.setPersistent(0);
        d.addScoreboardTag("bda_fx");
        d.setItemStack(skull);
        d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
    });
        parts = List.of(torso, armL, armR, legL, legR, head);
        pose(0.0, 0.0, 0.0, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0);
    }

    private static BlockDisplay block(Location at, Material m) {
        return (BlockDisplay)at.getWorld().spawn(at, BlockDisplay.class, d -> {
        d.setPersistent(0);
        d.addScoreboardTag("bda_fx");
        d.setBlock(m.createBlockData());
    });
    }

    void pose(double ox, double oy, double oz, float lean, float armBack, float spread, float legLeft, float legRight, float headPitch, float scale, int interp) {
        if (removed) {
            return;
        }
        Matrix4f base = new Matrix4f().translate((float)ox, (float)oy, (float)oz).rotateY(yawRad).rotateX(rad(lean)).scale(Math.max(scale, 0.001F));
        apply(torso, new Matrix4f(base).translate(-0.25F, 0.75F, -0.125F).scale(0.5F, 0.75F, 0.25F), interp);
        apply(armL, limb(base, 0.375F, 1.5F, armBack, spread), interp);
        apply(armR, limb(base, -0.375F, 1.5F, armBack, -spread), interp);
        apply(legL, limb(base, 0.125F, 0.75F, legLeft, 0.0F), interp);
        apply(legR, limb(base, -0.125F, 0.75F, legRight, 0.0F), interp);
        apply(head, new Matrix4f(base).translate(0.0F, 1.5F, 0.0F).rotateX(rad(headPitch)).translate(0.0F, 0.5F, 0.0F).rotateY(rad(0.0F)), interp);
    }

    private static Matrix4f limb(Matrix4f base, float x, float y, float swing, float spread) {
        return new Matrix4f(base).translate(x, y, 0.0F).rotateX(rad(swing)).rotateZ(rad(spread)).translate(-0.125F, -0.75F, -0.125F).scale(0.25F, 0.75F, 0.25F);
    }

    static void apply(Display d, Matrix4f m, int interp) {
        Transformation t = new Transformation(m.getTranslation(new Vector3f()), m.getUnnormalizedRotation(new Quaternionf()), m.getScale(new Vector3f()), new Quaternionf());
        if (d.getInterpolationDuration() == interp && t.equals(d.getTransformation())) {
            return;
        }
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(interp);
        d.setTransformation(t);
    }

    static float rad(float deg) {
        return (float)Math.toRadians((double)deg);
    }

    public boolean ready() {
        return parts.stream().allMatch(Entity::isValid);
    }

    public void remove() {
        removed = 1;
        parts.forEach(Entity::remove);
    }
}