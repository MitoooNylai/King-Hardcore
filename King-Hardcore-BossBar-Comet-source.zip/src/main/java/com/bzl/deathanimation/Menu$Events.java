// by decompiler.cc
package com.bzl.deathanimation;

import java.util.function.Consumer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

private static final class Events implements Listener {
    private Events() {
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        Consumer action = top.getHolder(0);
        Menu menu;
        if (action instanceof Menu) {
            menu = (Menu)action;
        } else {
            return;
        }
        e.setCancelled(1);
        if (e.getClickedInventory() != top || e.getClick() == ClickType.DOUBLE_CLICK || !e.getWhoClicked().equals(menu.viewer)) {
            return;
        }
        action = (Consumer)menu.actions.get(e.getRawSlot());
        if (action == null) {
            return;
        }
        menu.sound("ui.button.click", 1.5F);
        action.accept(e);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder(0) instanceof Menu) {
            e.setCancelled(1);
        }
    }
}