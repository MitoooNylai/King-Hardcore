// by decompiler.cc
package com.bzl.deathanimation;

import java.util.Objects;
import io.papermc.paper.plugin.configuration.PluginMeta;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.entity.Player;

static final class Main extends Menu {
    Main(BzlDeathAnimation plugin, Player viewer) {
        super(plugin, viewer);
    }

    Component title() {
        return plugin.settings.msg("menu.title.main", new TagResolver[0]);
    }

    boolean live() {
        return 1;
    }

    void draw() {
        Settings s = plugin.settings;
        PluginMeta meta = plugin.getPluginMeta();
        int trapped = plugin.nebula.trapped().size();
        AdminMenu.Main $stack0 = this;
        int $stack1 = 4;
        Material $stack2 = Material.NETHER_STAR;
        String $stack3 = "<gradient:#B8F1FF:#3FB8FF><bold>King Hardcore";
        String[] $stack4 = new String[]{"<gray>Versi <white>" + Menu.esc(meta.getVersion()), "<gray>Author <white>" + Menu.esc(String.join(", ", meta.getAuthors())), ""};
        String[] $stack5 = new String[]{"<gray>Versi <white>" + Menu.esc(meta.getVersion()), "<gray>Author <white>" + Menu.esc(String.join(", ", meta.getAuthors())), ""};
        int $stack6 = 3;
        String $stack7 = s.enabled ? "<#5CFF8A>aktif" : "<#FF6B6B>mati";
        $stack5[$stack6] = "<gray>Animasi: " + $stack7;
        $stack5 = $stack4;
        $stack6 = 4;
        $stack7 = Body.MANNEQUIN && !"blocks".equals(s.body) ? "Mannequin" : "Blok";
        $stack5[$stack6] = "<gray>Badan: <white>" + $stack7;
        $stack4[5] = "<gray>Di Nebula: <white>" + trapped + " pemain";
        $stack4[6] = "";
        $stack4[7] = "<dark_gray>King Hardcore";
        $stack0.set($stack1, Menu.glow(item($stack2, $stack3, $stack4), 1));
        toggle(13, Material.END_CRYSTAL, "Animasi Kematian", "death-animation.enabled", s.enabled, new String[]{"Saklar utama plugin.", "Mati = pemain mati seperti biasa."});
        link(20, Material.WITHER_SKELETON_SKULL, "Kematian", "bda.menu.edit", () -> new AdminMenu.Death(plugin, viewer), new String[]{"Totem, model badan, posisi portal,", "dunia yang dikecualikan."});
        link(22, Material.END_STONE, "Nebula", "bda.menu.edit", () -> new AdminMenu.NebulaPage(plugin, viewer), new String[]{"Lama hukuman, tujuan pulang,", "aturan & sinematik Nebula."});
        link(24, Material.JUKEBOX, "Efek & Suara", "bda.menu.edit", () -> new AdminMenu.Effects(plugin, viewer), new String[]{"Musik, sayap, detak jantung,", "napas, goyang kamera."});
        link(29, Material.BLAZE_POWDER, "Editor Partikel", "bda.menu.edit", () -> new AdminMenu.Particles(plugin, viewer, 0), new String[]{"Tipe, warna, ukuran & jumlah", "dari " + Fx.Slot.values().length + " efek partikel."});
        link(31, Material.PLAYER_HEAD, "Pemain di Nebula", "bda.menu.players", () -> new AdminMenu.Players(plugin, viewer, 0), new String[]{"<white>" + trapped + " <gray>pemain sedang terkurung.", "Lihat sisa waktu, bebaskan, teleport."});
        button(33, item(Material.ARMOR_STAND, "<#B8F1FF><bold>Tes Animasi", new String[]{"<gray>Putar animasi kematian pada", "<gray>dirimu sendiri (tanpa mati).", "", "<#7FE3FF>» <gray>Klik untuk memutar"}), "bda.command.test", e -> later(() -> {
        viewer.closeInventory();
        plugin.test(viewer, viewer);
    }));
        button(48, item(Material.CLOCK, "<#B8F1FF><bold>Muat Ulang", new String[]{"<gray>Baca ulang config.yml & messages.yml", "<gray>dari file.", "", "<#7FE3FF>» <gray>Klik untuk memuat ulang"}), "bda.command.reload", e -> {
        plugin.reload(viewer);
        sound("block.amethyst_block.chime", 1.2F);
        later(this::open);
    });
        set(49, item(Material.BARRIER, "<#FF6B6B><bold>Tutup", new String[0]), e -> {
        Objects.requireNonNull(viewer);
        later(this.viewer::closeInventory);
    });
    }
}