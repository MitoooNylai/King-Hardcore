// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

final class Portal {
    private static final int STEADY_EVERY = 6;
    static final int FALL_DUR = 14;
    static final int BOUNCE_DUR = 8;
    static final int ASSEMBLE_DUR = 26;
    static final int RUNE_DUR = 8;
    private static final float LIFT_PART = 0.3F;
    private static final int LAYERS = 24;
    private static final Display.Brightness FULL_BRIGHT = new Display.Brightness(15, 15);
    private static final Display.Brightness PORTAL_LIT = new Display.Brightness(10, 15);
    private static final float CORE_R = 1.45F;
    private static final float EDGE_R = 1.62F;
    private static final float[] CROWN = new float[]{14.0F, 36.0F, 58.0F, 80.0F, 100.0F, 122.0F, 144.0F, 166.0F};
    private static final float[] FRAME = new float[]{196.0F, 218.0F, 240.0F, 300.0F, 322.0F, 344.0F};
    private static final float[] PENTA = new float[]{0.5F, 0.561F, 0.63F, 0.749F, 0.841F, 1.0F, 1.122F, 1.26F, 1.498F, 1.682F, 2.0F};
    private final List<BlockDisplay> core = new ArrayList<>();
    private final List<BlockDisplay> edge = new ArrayList<>();
    private final List<BlockDisplay> frame = new ArrayList<>();
    private final List<BlockDisplay> deep = new ArrayList<>();
    private static final float DEEP_R = 1.82F;
    private final List<BlockDisplay> notches = new ArrayList<>();
    private static final float FRAME_R = 2.05F;
    private static final int NOTCHES = 12;
    private final List<Portal.Stone> stones = new ArrayList<>();
    private final List<Portal.Step> steps = new ArrayList<>();
    private final List<Portal.Deco> decos = new ArrayList<>();
    private final List<Display> all = new ArrayList<>();
    private final Matrix4f face;
    private final Location at;
    private final World world;
    private final float groundY;
    private final Portal.Timing timing;
    private float lastSteps = -1.0F;

    Portal(Location center, float yaw, double heightAboveGround, Portal.Timing timing) {
        at = center.clone();
        at.setYaw(0.0F);
        at.setPitch(0.0F);
        world = at.getWorld();
        this.timing = timing;
        face = new Matrix4f().rotateY((float)-Math.toRadians((double)yaw));
        groundY = (float)-heightAboveGround;
        try {
            Random r = new Random((long)center.getBlockX() * 31L + (long)center.getBlockZ());
            int i = 0;
            BlockDisplay f;
            for (; i < 24; i++) {
                core.add(spawn(Material.WHITE_CONCRETE, 1));
                e = spawn(Material.LIGHT_BLUE_CONCRETE, 1);
                edge.add(e);
                deep.add(spawn(Material.BLUE_CONCRETE, 1));
                f = spawn(Material.POLISHED_DEEPSLATE, 0);
                f.setBrightness(PORTAL_LIT);
                frame.add(f);
            }
            for (i = 0; i < 12; i++) {
                BlockDisplay n = spawn(Material.LIGHT_BLUE_CONCRETE, 1);
                notches.add(n);
            }
            i = CROWN;
            e = i.length;
            f = 0;
            float deg;
            for (; f < e; f++) {
                deg = i[f];
                int $stack0 = deg > 60.0F && deg < 120.0F;
                boolean top = $stack0;
                $stack0 = stones;
                $stack0.add(stone(deg, (top ? 1.9F : 1.35F) + r.nextFloat() * 0.5F, 0.62F + r.nextFloat() * 0.28F, 0.5F, r));
            }
            i = FRAME;
            e = i.length;
            for (f = 0; f < e; f++) {
                deg = i[f];
                stones.add(stone(deg, 0.95F + r.nextFloat() * 0.25F, 0.7F, 0.6F, r));
            }
            List order = new ArrayList(stones);
            Collections.shuffle(order, r);
            for (i = 0; i < order.size(); i++) {
                ((Portal.Stone)order.get(i)).order = i;
                ((Portal.Stone)order.get(i)).fallStart = timing.fallStart + i * 5 / 2;
                ((Portal.Stone)order.get(i)).assembleStart = timing.assembleStart + i * 2;
            }
            buildSteps();
            buildCircle();
            buildRays(r);
            buildLanterns();
            buildBraziers();
            buildSpikes(r);
            buildCrystals(r);
            update(0, 0.0F);
        } catch (RuntimeException e) {
            remove();
            throw e;
        }
    }

    private BlockDisplay spawn(Material m, boolean bright) {
        return spawn(m.createBlockData(), bright);
    }

    private static BlockData data(String... ids) {
        String[] stringArray = ids;
        int i = stringArray.length;
        int i2 = 0;
        while (i2 < i) {
            String id = stringArray[i2];
            try {
                BlockData $stack0 = Bukkit.createBlockData(id);
            } catch (IllegalArgumentException illegalArgumentException) {
                i2++;
                continue;
            }
        }
        return Material.STONE.createBlockData();
    }

    private BlockDisplay spawn(BlockData data, boolean bright) {
        BlockDisplay d = (BlockDisplay)world.spawn(at, BlockDisplay.class, e -> {
        e.setPersistent(0);
        e.addScoreboardTag("bda_fx");
        e.setBlock(data);
        if (bright) {
            e.setBrightness(FULL_BRIGHT);
        }
    });
        all.add(d);
        return d;
    }

    private static Matrix4f box(float w, float h, float d) {
        return new Matrix4f().translate(-w / 2.0F, -h / 2.0F, -d / 2.0F).scale(w, h, d);
    }

    private Portal.Stone stone(float deg, float h, float w, float d, Random r) {
        Portal.Stone st = new Portal.Stone();
        float wu = w * 0.78F;
        add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate(0.0F, -0.175F * h, 0.0F).mul(box(w, 0.65F * h, d)));
        add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate(0.0F, 0.275F * h, 0.0F).rotateZ(0.04F).mul(box(wu, 0.45F * h, d * 0.95F)));
        add(st, Material.DEEPSLATE_TILES, new Matrix4f().translate(-w * 0.16F, h * 0.05F, -0.01F).rotateZ(0.2F).mul(box(w * 0.62F, h * 0.5F, d * 1.06F)));
        add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate(w * 0.2F, -h * 0.22F, 0.01F).rotateZ(-0.17F).mul(box(w * 0.6F, h * 0.42F, d * 1.04F)));
        float t = wu / (float)Math.sqrt(2.0);
        float[][] tiers = new float[][]{new float[]{0.0F, 1.0F, 0.92F}, new float[]{0.38F, 0.62F, 0.75F}, new float[]{0.66F, 0.34F, 0.55F}};
        int i = 0;
        float $stack0;
        float $stack1;
        for (; i < tiers.length; i++) {
            float s = t * tiers[i][1];
            $stack0 = this;
            $stack1 = st;
            $stack0.add($stack1, i == 1 ? Material.DEEPSLATE_TILES : Material.POLISHED_DEEPSLATE, new Matrix4f().translate(0.0F, h / 2.0F + wu * tiers[i][0], 0.0F).rotateZ(0.7853982F).mul(box(s, s, d * tiers[i][2])));
        }
        add(st, Material.COBBLED_DEEPSLATE, new Matrix4f().translate(w * 0.1F, -h / 2.0F, 0.0F).rotateZ(0.9853982F).mul(box(t * 0.8F, t * 0.8F, d * 0.85F)));
        for (int side = -1; side <= 1; side += 2) {
            add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate((float)side * w / 2.0F, -h * 0.18F, 0.0F).rotateY(0.7853982F).mul(box(d * 0.55F, h * 0.55F, d * 0.55F)));
        }
        if (h > 1.2F) {
            add(st, Material.DEEPSLATE_TILES, new Matrix4f().translate(-w * 0.7F, h * 0.38F, -0.1F).rotateXYZ(0.5F, 0.3F, 0.8F).mul(box(0.22F, 0.3F, 0.2F)));
        }
        float z = -d * 0.53F - 0.012F;
        float[][] pts = new float[][]{new float[]{-0.12F * w, -0.34F * h}, new float[]{0.22F * w, -0.1F * h}, new float[]{-0.2F * w, 0.12F * h}, new float[]{0.12F * w, 0.36F * h}};
        for (i = 0; i < pts.length - 1; i++) {
            rune(st, pts[i][0] + (r.nextFloat() - 0.5F) * 0.08F, pts[i][1], pts[i + 1][0] + (r.nextFloat() - 0.5F) * 0.08F, pts[i + 1][1], z);
        }
        rune(st, pts[1][0], pts[1][1], pts[1][0] + 0.18F * w, pts[1][1] + 0.12F * h, z);
        float a = (float)Math.toRadians((double)deg);
        $stack0 = 1.62F;
        $stack1 = deg > 180.0F ? 0.2F : 0.35F;
        float rad = $stack0 + $stack1 + h / 2.0F;
        st.finalPos = new Vector3f((float)Math.cos((double)a) * rad, (float)Math.sin((double)a) * rad, 0.05F);
        st.finalRot = new Quaternionf().rotateZ(a - 1.5707964F + (float)Math.toRadians((double)((r.nextFloat() - 0.5F) * 14.0F))).rotateY((float)Math.toRadians((double)((r.nextFloat() - 0.5F) * 28.0F)));
        st.groundPos = new Vector3f((r.nextFloat() - 0.5F) * 7.0F, groundY + d * 0.4F, -2.6F + r.nextFloat() * 4.2F);
        st.groundRot = new Quaternionf().rotateY(r.nextFloat() * 6.283F).rotateX(1.5707964F + (r.nextFloat() - 0.5F) * 0.4F);
        st.skyPos = new Vector3f(st.groundPos).add((r.nextFloat() - 0.5F) * 3.0F, 30.0F + r.nextFloat() * 6.0F, (r.nextFloat() - 0.5F) * 3.0F);
        st.skyRot = new Quaternionf().rotateXYZ(r.nextFloat() * 6.283F, r.nextFloat() * 6.283F, r.nextFloat() * 6.283F);
        st.phase = r.nextFloat() * 6.0F;
        return st;
    }

    private void add(Portal.Stone st, Material m, Matrix4f local) {
        BlockDisplay d = spawn(m, 0);
        d.setBrightness(PORTAL_LIT);
        st.pieces.add(new Portal.Piece(d, local, null));
    }

    private void rune(Portal.Stone st, float x0, float y0, float x1, float y1, float z) {
        float len = (float)Math.hypot((double)(x1 - x0), (double)(y1 - y0)) + 0.05F;
        float ang = (float)Math.atan2((double)(y1 - y0), (double)(x1 - x0));
        Vector3f mid = new Vector3f((x0 + x1) / 2.0F, (y0 + y1) / 2.0F, z);
        BlockDisplay d = spawn(Material.LIGHT_BLUE_CONCRETE, 1);
        st.pieces.add(new Portal.Piece(d, new Matrix4f().translate(mid).rotateZ(ang).mul(box(len, 0.07F, 0.02F)), mid));
    }

    private void buildSteps() {
        for (int i = 0; i < 3; i++) {
            float radius = 2.25F - (float)i * 0.5F;
            float height = 0.25F * (float)(i + 1);
            float depth = 0.62F;
            int segs = 7 - i * 2;
            float stepAng = (float)Math.toRadians(16.0);
            float segW = 2.0F * radius * (float)Math.tan((double)(stepAng / 2.0F)) + 0.06F;
            Material m = i == 2 ? Material.POLISHED_DEEPSLATE : Material.DEEPSLATE_TILES;
            for (int k = -(segs / 2); k <= segs / 2; k++) {
                float th = (float)k * stepAng;
                float x = (float)Math.sin((double)th) * radius;
                float z = -(float)Math.cos((double)th) * radius;
                steps.add(new Portal.Step(spawn(m, 0), new Matrix4f().translate(x, groundY + height / 2.0F, z).rotateY(-th).mul(box(segW, height, depth))));
            }
        }
    }

    private void buildCircle() {
        int segs = 24;
        float y = groundY + 0.03F;
        float rad = 3.1F;
        int i = 0;
        double a0;
        double a1;
        Vector3f p0;
        Vector3f p1;
        for (; i < segs; i++) {
            a0 = (double)i * 3.141592653589793 * 2.0 / (double)segs;
            a1 = (double)(i + 1) * 3.141592653589793 * 2.0 / (double)segs;
            p0 = new Vector3f((float)Math.cos(a0) * rad, y, (float)Math.sin(a0) * rad);
            p1 = new Vector3f((float)Math.cos(a1) * rad, y, (float)Math.sin(a1) * rad);
            groundLine(p0, p1, timing.drawStart + i, i % 2 == 0 ? PENTA[i / 2 % PENTA.length] : 0.0F);
        }
        float hr = 2.7F;
        for (int tri = 0; tri < 2; tri++) {
            for (int j = 0; j < 3; j++) {
                a0 = 1.5707963267948966 + (double)tri * 3.141592653589793 + (double)j * 3.141592653589793 * 2.0 / 3.0;
                a1 = a0 + 2.0943951023931953;
                p0 = new Vector3f((float)Math.cos(a0) * hr, y + 0.005F, (float)Math.sin(a0) * hr);
                p1 = new Vector3f((float)Math.cos(a1) * hr, y + 0.005F, (float)Math.sin(a1) * hr);
                groundLine(p0, p1, timing.drawStart + segs + (tri * 3 + j) * 2, 1.5F + (float)(tri * 3 + j) * 0.08F);
            }
        }
    }

    private void groundLine(Vector3f p0, Vector3f p1, int start, float pitch) {
        float dx = p1.x - p0.x;
        float dz = p1.z - p0.z;
        float len = (float)Math.hypot((double)dx, (double)dz) + 0.04F;
        Vector3f mid = new Vector3f(p0).add(p1).mul(0.5F);
        Matrix4f local = new Matrix4f().translate(mid).rotateY((float)-Math.atan2((double)dz, (double)dx)).mul(box(len, 0.02F, 0.08F));
        List $stack0 = decos;
        Portal.Deco new Portal.Deco;
        Portal.Deco $stack1 = new Portal.Deco;
        Portal.Deco $stack2 = new Portal.Deco;
        super(spawn(Material.LIGHT_BLUE_CONCRETE, 1), local, p0, start, 3, 0, pitch > 0.0F ? "block.note_block.chime" : null, pitch);
        $stack0.add($stack1);
    }

    private void buildRays(Random r) {
        float[] angles = new float[]{0.0F, 25.0F, 47.0F, 69.0F, 90.0F, 111.0F, 133.0F, 155.0F, 180.0F};
        for (int i = 0; i < angles.length; i++) {
            float a = (float)Math.toRadians((double)angles[i]);
            float r0 = 1.77F;
            float $stack0 = angles[i] > 40.0F && angles[i] < 140.0F ? 2.2F : 1.4F;
            float len = $stack0 + r.nextFloat() * 0.6F;
            Matrix4f local = new Matrix4f().rotateZ(a - 1.5707964F).translate(-0.6F, r0, -0.6F).scale(1.2F, len, 1.2F);
            Vector3f pivot = new Vector3f((float)Math.cos((double)a) * r0, (float)Math.sin((double)a) * r0, 0.0F);
            $stack0 = decos;
            Portal.Deco new Portal.Deco;
            Portal.Deco $stack1 = new Portal.Deco;
            Portal.Deco $stack2 = new Portal.Deco;
            super(spawn(Material.END_ROD, 1), local, pivot, timing.ignite + 2 + i, 10, 0, i % 3 == 0 ? "block.amethyst_block.resonate" : null, 1.2F + (float)i * 0.05F);
            $stack0.add($stack1);
        }
    }

    private void buildLanterns() {
        BlockData chain = data(new String[]{"minecraft:iron_chain", "minecraft:chain"});
        BlockData lantern = data(new String[]{"minecraft:soul_lantern[hanging=true]"});
        for (int side = -1; side <= 1; side += 2) {
            float x = (float)side * 2.67F;
            Vector3f pivot = new Vector3f(x, 0.9F, -0.1F);
            decos.add(new Portal.Deco(spawn(chain, 0), new Matrix4f().translate(x - 0.5F, -0.5F, -0.6F).scale(1.0F, 1.4F, 1.0F), pivot, timing.ignite + 8, 10, 1, "block.chain.place", 0.8F));
            decos.add(new Portal.Deco(spawn(lantern, 1), new Matrix4f().translate(x - 0.5F, -1.5F, -0.6F), pivot, timing.ignite + 8, 10, 1, "block.lantern.place", 0.7F));
        }
    }

    private void buildBraziers() {
        BlockData post = data(new String[]{"minecraft:deepslate_brick_wall[up=true]"});
        BlockData fire = data(new String[]{"minecraft:soul_campfire[lit=true]"});
        for (int side = -1; side <= 1; side += 2) {
            float th = (float)side * (float)Math.toRadians(50.0);
            float x = (float)Math.sin((double)th) * 3.0F;
            float z = -(float)Math.cos((double)th) * 3.0F;
            Vector3f base = new Vector3f(x, groundY, z);
            decos.add(new Portal.Deco(spawn(post, 0), new Matrix4f().translate(x - 0.5F, groundY, z - 0.5F).scale(1.0F, 1.3F, 1.0F), base, timing.stepsStart + 6, 10, 0, "block.deepslate_bricks.place", 0.7F));
            decos.add(new Portal.Deco(spawn(fire, 1), new Matrix4f().translate(x - 0.4F, groundY + 1.3F, z - 0.4F).scale(0.8F), new Vector3f(x, groundY + 1.3F, z), timing.stepsStart + 16, 6, 0, "item.firecharge.use", 0.8F));
        }
    }

    private void buildSpikes(Random r) {
        String[] parts = new String[]{"base", "frustum", "tip"};
        float[] angles = new float[]{105.0F, 130.0F, 155.0F, -105.0F, -130.0F, -155.0F};
        for (int i = 0; i < angles.length; i++) {
            float th = (float)Math.toRadians((double)angles[i]);
            float rad = 3.3F + r.nextFloat() * 0.6F;
            Vector3f base = new Vector3f((float)Math.sin((double)th) * rad, groundY, -(float)Math.cos((double)th) * rad);
            float lean = Math.signum(angles[i]) * (0.12F + r.nextFloat() * 0.15F);
            float s = 0.6F + r.nextFloat() * 0.25F;
            float spin = r.nextFloat() * 6.28F;
            for (int j = 0; j < parts.length; j++) {
                BlockData d = data(new String[]{"minecraft:pointed_dripstone[thickness=" + parts[j] + ",vertical_direction=up]"});
                List $stack0 = decos;
                Portal.Deco new Portal.Deco;
                Portal.Deco $stack1 = new Portal.Deco;
                Portal.Deco $stack2 = new Portal.Deco;
                super(spawn(d, 0), new Matrix4f().translate(base).rotateZ(-lean).rotateY(spin).translate(-s / 2.0F, (float)j * s, -s / 2.0F).scale(s), base, timing.stepsStart + 4 + i * 3, 10, 0, j == 0 ? "block.pointed_dripstone.place" : null, 0.7F);
                $stack0.add($stack1);
            }
        }
    }

    private void buildCrystals(Random r) {
        int n = 0;
        BlockData cluster = data(new String[]{"minecraft:amethyst_cluster[facing=up]"});
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 3; i++) {
                float th = (float)side * (float)Math.toRadians((double)((float)(62 + i * 14) + r.nextFloat() * 6.0F));
                float radius = 2.4F + r.nextFloat() * 0.5F;
                Vector3f base = new Vector3f((float)Math.sin((double)th) * radius, groundY, -(float)Math.cos((double)th) * radius);
                n++;
                int start = timing.stepsStart + 20 + n * 2;
                if (i != 1) {
                    decos.add(new Portal.Deco(spawn(cluster, 1), new Matrix4f().translate(base).rotateY(r.nextFloat() * 6.28F).translate(-0.45F, 0.0F, -0.45F).scale(0.9F), base, start, 8, 0, "block.amethyst_cluster.place", 1.1F));
                } else {
                    float h = 0.5F + r.nextFloat() * 0.4F;
                    BlockDisplay c = spawn(Material.LIGHT_BLUE_STAINED_GLASS, 1);
                    decos.add(new Portal.Deco(c, new Matrix4f().translate(base).rotateY(r.nextFloat() * 6.28F).rotateZ((float)side * (0.15F + r.nextFloat() * 0.3F)).rotateY(0.7853982F).translate(-0.08F, 0.0F, -0.08F).scale(0.16F, h, 0.16F), base, start, 8, 0, "block.amethyst_block.place", 1.4F));
                }
            }
        }
    }

    int update(int tick, float close) {
        float keep = Math.max(0.001F, 1.0F - close);
        int $stack0 = close > 0.0F;
        boolean closing = $stack0;
        int impacts = 0;
        float rise = stones.iterator();
        float fall;
        float rune;
        Matrix4f m;
        Location g;
        Matrix4f $stack1;
        int $stack2;
        while (rise.hasNext()) {
            Portal.Stone st = (Portal.Stone)rise.next();
            fall = k((float)tick, (float)st.fallStart, (float)(st.fallStart + 14));
            float asm = k((float)tick, (float)st.assembleStart, (float)(st.assembleStart + 26));
            rune = k((float)tick, (float)(st.assembleStart + 26), (float)(st.assembleStart + 26 + 8));
            $stack0 = tick >= st.fallStart && tick <= st.fallStart + 14 + 8 || tick >= st.assembleStart && tick <= st.assembleStart + 26 + 8;
            boolean moving = $stack0;
            $stack0 = tick < st.fallStart;
            boolean waiting = $stack0;
            $stack0 = (tick + st.order) % 6 == 0;
            boolean bobTick = $stack0;
            if (!moving && !closing && tick != 0) {
                if (waiting || asm <= 0.0F) {
                    continue;
                }
                if (!bobTick) {
                    continue;
                }
            }
            float scale;
            Portal.Piece p;
            if (rune >= 1.0F && bobTick) {
                int b = 10 + Math.round(5.0F * (0.5F + 0.5F * (float)Math.sin((double)tick * 0.15 + (double)st.phase)));
                Display.Brightness shimmer = new Display.Brightness(b, b);
                scale = st.pieces.iterator();
                while (scale.hasNext()) {
                    p = (Portal.Piece)scale.next();
                    if (p.runePivot != null) {
                        p.d.setBrightness(shimmer);
                    }
                }
            }
            scale = keep;
            Vector3f pos;
            Quaternionf rot;
            float len;
            if (waiting) {
                pos = st.skyPos;
                rot = st.skyRot;
                scale = 0.001F;
            } else {
                label0: {
                    if (asm <= 0.0F) {
                        pos = new Vector3f(st.skyPos).lerp(st.groundPos, fall * fall);
                        rot = new Quaternionf(st.skyRot).slerp(st.groundRot, fall).rotateX((1.0F - fall) * 9.0F);
                        if (fall >= 1.0F) {
                            float kb = k((float)tick, (float)(st.fallStart + 14), (float)(st.fallStart + 14 + 8));
                            pos.y += (float)Math.sin((double)kb * 3.141592653589793) * 0.35F * (1.0F - kb);
                            rot.rotateZ((float)Math.sin((double)kb * 3.141592653589793 * 2.0) * 0.15F * (1.0F - kb));
                        }
                        if (!st.falling) {
                            st.falling = 1;
                            g = toWorld(st.groundPos);
                            world.playSound(g, "entity.ender_dragon.flap", 0.7F, 0.5F + (float)st.order * 0.03F);
                            world.playSound(g, "entity.blaze.shoot", 0.4F, 0.5F);
                        }
                        if (fall <= 0.0F || fall >= 1.0F) {
                            break label0;
                        }
                        trail(st, pos);
                        break label0;
                    }
                    pos = assemblyPos(st, asm);
                    float e = smooth(asm);
                    rot = new Quaternionf(st.groundRot).slerp(st.finalRot, e).rotateY((1.0F - e) * 6.283F);
                    if (asm >= 1.0F) {
                        float breathe = (float)Math.sin((double)tick * 0.1 + (double)st.phase) * 0.06F;
                        len = (float)Math.hypot((double)st.finalPos.x, (double)st.finalPos.y);
                        pos.add(st.finalPos.x / len * breathe, st.finalPos.y / len * breathe + (float)Math.sin((double)tick * 0.07 + (double)st.phase) * 0.06F, 0.0F);
                    } else {
                        Fx.get(Fx.Slot.STONE_FLIGHT).spawn(toWorld(pos), 1, 0.15, 0.15, 0.15, 0.01);
                    }
                    if (!st.locked && asm >= 1.0F) {
                        st.locked = 1;
                        lockIn(st, toWorld(pos));
                    }
                }
            }
            if (!st.landed && fall >= 1.0F) {
                st.landed = 1;
                impacts++;
                impact(toWorld(st.groundPos));
            }
            if (!st.lifted && asm > 0.0F) {
                st.lifted = 1;
                g = toWorld(st.groundPos);
                Fx.get(Fx.Slot.STONE_LIFTOFF).spawn(g, 33, 0.4, 0.1, 0.4, 0.08);
                world.playSound(g, "block.deepslate.break", 0.6F, 0.8F);
                world.playSound(g, "block.beacon.power_select", 0.6F, 0.6F + (float)st.order * 0.05F);
            }
            if (tick == st.assembleStart + 26 + 3) {
                world.playSound(toWorld(pos), "block.amethyst_block.chime", 1.0F, 1.2F + (float)st.order * 0.04F);
            }
            m = new Matrix4f(face).scale(scale).translate(pos).rotate(rot);
            $stack0 = moving || closing ? 2 : 6;
            int interp = $stack0;
            len = st.pieces.iterator();
            while (len.hasNext()) {
                p = (Portal.Piece)len.next();
                Matrix4f local = p.local;
                if (p.runePivot != null && rune < 1.0F) {
                    float rs = Math.max(0.001F, rune);
                    local = new Matrix4f().translate(p.runePivot).scale(rs).translate(-p.runePivot.x, -p.runePivot.y, -p.runePivot.z).mul(p.local);
                }
                $stack0 = p.d;
                $stack1 = new Matrix4f(m).mul(local);
                $stack2 = tick == 0 ? 0 : interp;
                Puppet.apply($stack0, $stack1, $stack2);
            }
        }
        rise = smooth(k((float)tick, (float)timing.stepsStart, (float)(timing.stepsStart + 20)));
        float stepT = rise * keep;
        if (stepT != lastSteps) {
            if (lastSteps <= 0.0F && stepT > 0.0F) {
                world.playSound(at, "block.piston.extend", 0.8F, 0.5F);
                world.playSound(at, "block.grindstone.use", 1.0F, 0.5F);
            }
            lastSteps = stepT;
            float shrink = Math.max(0.001F, keep);
            float sy = Math.max(0.001F, rise);
            for (Portal.Step s : steps) {
                Puppet.apply(s.d, new Matrix4f(face).translate(0.0F, groundY, 0.0F).scale(shrink, shrink * sy, shrink).translate(0.0F, -groundY, 0.0F).mul(s.local), 2);
            }
            if (stepT > 0.0F && stepT < 1.0F && tick % 3 == 0) {
                Fx.get(Fx.Slot.STEPS_DEBRIS).spawn(toWorld(new Vector3f(0.0F, groundY + 0.1F, -1.6F)), 12, 1.6, 0.05, 0.6, 0.0);
            }
        }
        for (Portal.Deco dc : decos) {
            $stack0 = tick >= dc.start && tick <= dc.start + dc.dur;
            boolean active = $stack0;
            $stack0 = dc.swing && tick > dc.start + dc.dur && tick % 2 == 0;
            boolean swaying = $stack0;
            if (!active && !swaying && (!closing && tick != 0)) {
                continue;
            }
            if (tick == dc.start && dc.sound != null) {
                world.playSound(toWorld(dc.pivot), dc.sound, 0.9F, dc.pitch);
            }
            g = Math.max(0.001F, outBack(k((float)tick, (float)dc.start, (float)(dc.start + dc.dur))) * keep);
            m = new Matrix4f(face).translate(dc.pivot);
            if (dc.swing) {
                m.rotateZ((float)Math.sin((double)tick * 0.09 + (double)dc.pivot.x) * 0.18F);
            }
            m.scale(g).translate(-dc.pivot.x, -dc.pivot.y, -dc.pivot.z).mul(dc.local);
            $stack0 = dc.d;
            $stack1 = m;
            $stack2 = tick == 0 ? 0 : 2;
            Puppet.apply($stack0, $stack1, $stack2);
        }
        float frameS = outBack(k((float)tick, (float)(timing.ignite - 12), (float)timing.ignite)) * keep;
        float edgeS = outBack(k((float)tick, (float)timing.ignite, (float)(timing.ignite + 10))) * keep;
        float coreS = outBack(k((float)tick, (float)(timing.ignite + 5), (float)(timing.ignite + 16))) * keep;
        $stack0 = tick >= timing.ignite - 12 && tick <= timing.ignite + 16 || (closing || tick == 0);
        boolean coreAnimating = $stack0;
        if (tick == timing.ignite - 12) {
            world.playSound(at, "block.grindstone.use", 1.0F, 0.6F);
        }
        float fs;
        int i;
        float a;
        if (coreAnimating || tick > timing.ignite + 16 && tick % 4 == 0) {
            float pulse = 1.0F + 0.03F * (float)Math.sin((double)tick * 0.25);
            float cs = Math.max(0.001F, coreS * pulse);
            float es = Math.max(0.001F, edgeS * pulse);
            fs = Math.max(0.001F, frameS);
            $stack0 = coreAnimating ? 2 : 4;
            int ri = $stack0;
            for (i = 0; i < 24; i++) {
                a = (float)((double)i * 1.5707963267948966 / 24.0);
                float z = (float)i * 0.0005F;
                Puppet.apply((Display)core.get(i), new Matrix4f(face).scale(cs).rotateZ(a).translate(-1.45F, -1.45F, z).scale(2.9F, 2.9F, 0.03F), ri);
                Puppet.apply((Display)edge.get(i), new Matrix4f(face).scale(es).rotateZ(a).translate(-1.62F, -1.62F, 0.06F + z).scale(3.24F, 3.24F, 0.03F), ri);
                Puppet.apply((Display)deep.get(i), new Matrix4f(face).scale(es).rotateZ(a).translate(-1.82F, -1.82F, 0.12F + z).scale(3.64F, 3.64F, 0.03F), ri);
                Puppet.apply((Display)frame.get(i), new Matrix4f(face).scale(fs).rotateZ(a).translate(-2.05F, -2.05F, 0.18F + z).scale(4.1F, 4.1F, 0.03F), ri);
            }
        }
        $stack0 = tick >= timing.ignite && tick <= timing.ignite + 2 + 12 + 4;
        boolean dialLighting = $stack0;
        if (dialLighting || closing || tick == 0 || tick > timing.ignite && tick % 4 == 0) {
            fs = Math.max(0.001F, frameS);
            for (i = 0; i < 12; i++) {
                int start = timing.ignite + 2 + i;
                if (tick == start) {
                    world.playSound(at, "block.amethyst_block.chime", 0.7F, 0.9F + (float)i * 0.08F);
                }
                float ns = Math.max(0.001F, outBack(k((float)tick, (float)start, (float)(start + 4))));
                a = (float)((double)i * 3.141592653589793 * 2.0 / 12.0) + (float)tick * 0.01F;
                $stack0 = (Display)notches.get(i);
                $stack1 = new Matrix4f(face).scale(fs).rotateZ(a).translate(1.85F, 0.0F, 0.1F).scale(ns).translate(-0.13F, -0.035F, 0.0F).scale(0.26F, 0.07F, 0.02F);
                $stack2 = dialLighting ? 2 : 4;
                Puppet.apply($stack0, $stack1, $stack2);
            }
        }
        return impacts;
    }

    private Vector3f assemblyPos(Portal.Stone st, float asm) {
        Vector3f lift = new Vector3f(st.groundPos).add(0.0F, 2.2F, 0.0F);
        if (asm < 0.3F) {
            return new Vector3f(st.groundPos).lerp(lift, smooth(asm / 0.3F));
        }
        float e = (asm - 0.3F) / 0.7F;
        float rs = (float)Math.hypot((double)lift.x, (double)lift.y);
        float as = (float)Math.atan2((double)lift.y, (double)lift.x);
        float rf = (float)Math.hypot((double)st.finalPos.x, (double)st.finalPos.y);
        float af = (float)Math.atan2((double)st.finalPos.y, (double)st.finalPos.x);
        float a = af + (as - af) * (1.0F - smooth(e)) + (1.0F - smooth(e)) * 3.1415927F;
        float rad = rs + (rf - rs) * outBack(e);
        return new Vector3f((float)Math.cos((double)a) * rad, (float)Math.sin((double)a) * rad, lift.z + (st.finalPos.z - lift.z) * smooth(e));
    }

    private void lockIn(Portal.Stone st, Location w) {
        float pitch = 0.6F + (float)st.order * 0.08F;
        world.playSound(w, "block.respawn_anchor.charge", 1.0F, pitch);
        world.playSound(w, "block.end_portal_frame.fill", 1.0F, pitch);
        world.playSound(w, "block.deepslate.place", 0.8F, 0.7F);
        Fx.get(Fx.Slot.STONE_LOCK).spawn(w, 36, 0.3, 0.45, 0.22, 0.06);
    }

    private void trail(Portal.Stone st, Vector3f pos) {
        Fx.get(Fx.Slot.STONE_TRAIL).spawn(toWorld(pos), 6, 0.22, 0.22, 0.22, 0.015);
    }

    private void impact(Location g) {
        Fx.get(Fx.Slot.STONE_IMPACT).spawn(g, 63, 0.55, 0.15, 0.55, 0.1);
        for (int i = 0; i < 14; i++) {
            double a = (double)i * 3.141592653589793 * 2.0 / 14.0;
            Fx.get(Fx.Slot.STONE_IMPACT_RING).spawn(g.clone().add(Math.cos(a) * 0.5, 0.1, Math.sin(a) * 0.5), 0, Math.cos(a), 0.02, Math.sin(a), 0.25);
        }
        world.playSound(g, "entity.generic.explode", 0.7F, 1.3F);
        world.playSound(g, "block.anvil.land", 0.35F, 0.5F);
        world.playSound(g, "block.deepslate.place", 1.0F, 0.6F);
    }

    Location toWorld(Vector3f local) {
        Vector3f v = face.transformPosition(new Vector3f(local));
        return at.clone().add((double)v.x, (double)v.y, (double)v.z);
    }

    void remove() {
        all.forEach(Entity::remove);
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0F, Math.max(0.0F, (t - a) / (b - a)));
    }

    private static float smooth(float x) {
        return x * x * (3.0F - 2.0F * x);
    }

    private static float outBack(float x) {
        if (x <= 0.0F) {
            return 0.0F;
        }
        float c1 = 1.70158F;
        float c3 = c1 + 1.0F;
        return 1.0F + c3 * (float)Math.pow((double)(x - 1.0F), 3.0) + c1 * (float)Math.pow((double)(x - 1.0F), 2.0);
    }

}