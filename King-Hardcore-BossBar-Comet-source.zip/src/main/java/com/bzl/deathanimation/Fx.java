// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import com.destroystokyo.paper.ParticleBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

final class Fx {
    private static final Set<String> warned = new HashSet<>();
    private static volatile Map<Fx.Slot, Fx> current = Map.of();
    private static final Fx OFF = new Fx(Fx.Slot.FLASH, 0, List.of(), List.of(), List.of(Color.WHITE), 1.0F, 0.0, Material.STONE.createBlockData(), 0.0, 0);
    final Fx.Slot slot;
    final boolean enabled;
    final List<Particle> types;
    final List<Double> weights;
    private final double weightSum;
    final List<Color> colors;
    final float size;
    final double amount;
    final BlockData block;
    private final double globalAmount;
    private final int viewDistance;
    private int rotation;

    static Fx get(Fx.Slot slot) {
        Fx fx = (Fx)current.get(slot);
        return fx != null ? fx : OFF;
    }

    static void install(Map<Fx.Slot, Fx> slots) {
        current = Map.copyOf(slots);
    }

    private Fx(Fx.Slot slot, boolean enabled, List<Particle> types, List<Double> weights, List<Color> colors, float size, double amount, BlockData block, double globalAmount, int viewDistance) {
        this.slot = slot;
        this.enabled = enabled;
        this.types = types;
        this.weights = weights;
        weightSum = weights.stream().mapToDouble(Double::doubleValue).sum();
        this.colors = colors;
        this.size = size;
        this.amount = amount;
        this.block = block;
        this.globalAmount = globalAmount;
        this.viewDistance = viewDistance;
    }

    static Fx load(ConfigurationSection root, Fx.Slot slot, double globalAmount, int viewDistance) {
        String base = "particles.effects." + slot.key + ".";
        List types = new ArrayList();
        List weights = new ArrayList();
        List colors = root.getStringList(base + "particles").iterator();
        String entry;
        while (colors.hasNext()) {
            entry = (String)colors.next();
            String[] parts = entry.split("\\*", 2);
            String name = parts[0].trim().toUpperCase(Locale.ROOT);
            double weight = 1.0;
            if (parts.length == 2) {
                try {
                    weight = Math.max(0.0, Double.parseDouble(parts[1].trim()));
                } catch (NumberFormatException e) {
                    warnOnce(slot.key + ":" + entry, "bad weight in '" + entry + "' (particles.effects." + slot.key + "), using 1");
                }
            }
            try {
                types.add(Particle.valueOf(name));
                weights.add(weight);
            } catch (IllegalArgumentException e) {
                warnOnce(slot.key + ":" + name, "unknown particle '" + name + "' in particles.effects." + slot.key + " (skipped)");
                continue;
            }
        }
        colors = new ArrayList();
        for (String hex : root.getStringList(base + "colors")) {
            Color c = parseColor(hex);
            if (c != null) {
                colors.add(c);
            } else {
                warnOnce(slot.key + ":" + hex, "bad colour '" + hex + "' in particles.effects." + slot.key + " (use #RRGGBB)");
            }
        }
        if (colors.isEmpty()) {
            colors.add(Color.WHITE);
        }
        BlockData block = null;
        String blockName = root.getString(base + "block", "");
        if (!blockName.isBlank()) {
            label0: {
                Material m = Material.matchMaterial(blockName);
                if (m != null && m.isBlock()) {
                    block = m.createBlockData();
                    break label0;
                }
                warnOnce(slot.key + ":" + blockName, "bad block '" + blockName + "' in particles.effects." + slot.key);
            }
        }
        if (block == null) {
            block = Material.DEEPSLATE.createBlockData();
        }
        return new Fx(slot, root.getBoolean(base + "enabled", 1), types, weights, colors, (float)Math.max(0.05, root.getDouble(base + "size", 1.0)), Math.max(0.0, root.getDouble(base + "amount", 1.0)), block, globalAmount, viewDistance);
    }

    void spawn(Location at, int count, double dx, double dy, double dz, double speed, double t) {
        if (!enabled || types.isEmpty() || (weightSum <= 0.0 || at.getWorld() == null)) {
            return;
        }
        if (count == 0) {
            if (amount * globalAmount <= 0.0) {
                return;
            }
            emit(null, next(), at, 0, dx, dy, dz, speed, t);
            return;
        }
        double total = (double)count * amount * globalAmount;
        for (int i = 0; i < types.size(); i++) {
            int n = stochasticRound(total * (Double)weights.get(i) / weightSum);
            if (n > 0) {
                emit(null, (Particle)types.get(i), at, n, dx, dy, dz, speed, t);
            }
        }
    }

    void spawn(Location at, int count, double dx, double dy, double dz, double speed) {
        spawn(at, count, dx, dy, dz, speed, 0.0);
    }

    void spawnFor(Player p, Location at, int count, double dx, double dy, double dz, double speed, double t) {
        if (!enabled || types.isEmpty()) {
            return;
        }
        int $stack0 = count == 0 ? 0 : scaled(count);
        int total = $stack0;
        if (count != 0 && total <= 0) {
            return;
        }
        $stack0 = this;
        Player $stack1 = p;
        Particle $stack2;
        if (count == 0) {
            $stack2 = next();
        } else {
            rotation++;
            $stack2 = (Particle)types.get(Math.floorMod(rotation, types.size()));
        }
        $stack0.emit($stack1, $stack2, at, total, dx, dy, dz, speed, t);
    }

    private int scaled(int count) {
        return stochasticRound((double)count * amount * globalAmount);
    }

    private static int stochasticRound(double n) {
        int $stack0;
        if (n >= 1.0) {
            $stack0 = (int)Math.round(n);
        } else {
            label0: {
                if (ThreadLocalRandom.current().nextDouble() < n) {
                    $stack0 = 1;
                    break label0;
                }
                $stack0 = 0;
            }
        }
        return $stack0;
    }

    private Particle next() {
        rotation++;
        return (Particle)types.get(Math.floorMod(rotation, types.size()));
    }

    private void emit(Player only, Particle type, Location at, int count, double dx, double dy, double dz, double speed, double t) {
        Object data;
        try {
            data = dataFor(type, t);
        } catch (UnsupportedOperationException e) {
            warnOnce("data:" + String.valueOf(type), "particle " + String.valueOf(type) + " needs data this plugin can't build; use another type in particles.effects." + slot.key);
            return;
        }
        ParticleBuilder b = new ParticleBuilder(type).location(at).count(count).offset(dx, dy, dz).extra(speed);
        if (data != null) {
            b.data(data);
        }
        if (only != null) {
            b.receivers(new Player[]{only});
        } else {
            b.receivers(viewDistance);
        }
        try {
            b.spawn();
        } catch (IllegalArgumentException e) {
            warnOnce("spawn:" + String.valueOf(type), "particle " + String.valueOf(type) + " could not be spawned (" + e.getMessage() + ") in particles.effects." + slot.key);
            return;
        }
    }

    private Object dataFor(Particle type, double t) {
        Class want = type.getDataType();
        if (want == Void.class) {
            return null;
        }
        if (want == Particle.DustOptions.class) {
            return new Particle.DustOptions(color(t), size);
        }
        if (want == Particle.DustTransition.class) {
            return new Particle.DustTransition((Color)colors.get(0), (Color)colors.get(colors.size() - 1), size);
        }
        if (want == BlockData.class) {
            return block;
        }
        if (want == Color.class) {
            return color(t);
        }
        if (want == Float.class) {
            return size;
        }
        if (want == Integer.class) {
            return 0;
        }
        if (want == ItemStack.class) {
            ItemStack new ItemStack;
            ItemStack $stack0 = new ItemStack;
            ItemStack $stack1 = new ItemStack;
            super(block.getMaterial().isItem() ? block.getMaterial() : Material.STONE);
            return $stack0;
        }
        throw new UnsupportedOperationException();
    }

    static boolean supported(Particle type) {
        Class<?> want = type.getDataType();
        return want == Void.class || want == Particle.DustOptions.class || (want == Particle.DustTransition.class || want == BlockData.class) || (want == Color.class || want == Float.class || (want == Integer.class || want == ItemStack.class));
    }

    List<String> entries() {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < types.size(); i++) {
            double w = (Double)weights.get(i);
            out.add(w == 1.0 ? ((Particle)types.get(i)).name() : ((Particle)types.get(i)).name() + "*" + num(w));
        }
        return out;
    }

    static String num(double v) {
        return v == Math.rint(v) ? String.valueOf((long)v) : String.valueOf((double)Math.round(v * 100.0) / 100.0);
    }

    Color color(double t) {
        if (colors.size() == 1) {
            return (Color)colors.get(0);
        }
        double x = Math.max(0.0, Math.min(1.0, t)) * (double)(colors.size() - 1);
        int i = Math.min(colors.size() - 2, (int)x);
        double f = x - (double)i;
        Color a = (Color)colors.get(i);
        Color b = (Color)colors.get(i + 1);
        return Color.fromRGB((int)Math.round((double)a.getRed() + (double)(b.getRed() - a.getRed()) * f), (int)Math.round((double)a.getGreen() + (double)(b.getGreen() - a.getGreen()) * f), (int)Math.round((double)a.getBlue() + (double)(b.getBlue() - a.getBlue()) * f));
    }

    static Color parseColor(String hex) {
        String h = hex.trim().replace("#", "");
        if (!h.matches("[0-9a-fA-F]{6}")) {
            return null;
        }
        return Color.fromRGB(Integer.parseInt(h, 16));
    }

    static String hex(Color c) {
        return String.format("#%02X%02X%02X", new Object[]{c.getRed(), c.getGreen(), c.getBlue()});
    }

    private static void warnOnce(String key, String message) {
        if (warned.add(key)) {
            Bukkit.getLogger().warning("[King Hardcore] " + message);
        }
    }

    static void resetWarnings() {
        warned.clear();
    }

}