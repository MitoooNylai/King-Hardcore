// by decompiler.cc
package com.bzl.deathanimation;

import java.awt.image.BufferedImage;
import org.bukkit.Material;

static record Colors(Material torso, Material arms, Material legs) {
    static final Puppet.Colors DEFAULT = new Puppet.Colors(Material.CYAN_CONCRETE, Material.TERRACOTTA, Material.BLUE_TERRACOTTA);
    private static final Object[][] PALETTE = new Object[][]{new Object[]{Material.WHITE_CONCRETE, 13620694}, new Object[]{Material.ORANGE_CONCRETE, 14704897}, new Object[]{Material.MAGENTA_CONCRETE, 11088031}, new Object[]{Material.LIGHT_BLUE_CONCRETE, 2394567}, new Object[]{Material.YELLOW_CONCRETE, 15838997}, new Object[]{Material.LIME_CONCRETE, 6203672}, new Object[]{Material.PINK_CONCRETE, 14050703}, new Object[]{Material.GRAY_CONCRETE, 3619390}, new Object[]{Material.LIGHT_GRAY_CONCRETE, 8224115}, new Object[]{Material.CYAN_CONCRETE, 1406856}, new Object[]{Material.PURPLE_CONCRETE, 6561948}, new Object[]{Material.BLUE_CONCRETE, 2961295}, new Object[]{Material.BROWN_CONCRETE, 6306848}, new Object[]{Material.GREEN_CONCRETE, 4807460}, new Object[]{Material.RED_CONCRETE, 9314593}, new Object[]{Material.BLACK_CONCRETE, 526863}, new Object[]{Material.WHITE_TERRACOTTA, 13808289}, new Object[]{Material.ORANGE_TERRACOTTA, 10638374}, new Object[]{Material.MAGENTA_TERRACOTTA, 9853037}, new Object[]{Material.LIGHT_BLUE_TERRACOTTA, 7433610}, new Object[]{Material.YELLOW_TERRACOTTA, 12223779}, new Object[]{Material.LIME_TERRACOTTA, 6846005}, new Object[]{Material.PINK_TERRACOTTA, 10636879}, new Object[]{Material.GRAY_TERRACOTTA, 3811876}, new Object[]{Material.LIGHT_GRAY_TERRACOTTA, 8874850}, new Object[]{Material.CYAN_TERRACOTTA, 5725019}, new Object[]{Material.PURPLE_TERRACOTTA, 7751254}, new Object[]{Material.BLUE_TERRACOTTA, 4865115}, new Object[]{Material.BROWN_TERRACOTTA, 5059364}, new Object[]{Material.GREEN_TERRACOTTA, 5002026}, new Object[]{Material.RED_TERRACOTTA, 9387311}, new Object[]{Material.BLACK_TERRACOTTA, 2430736}, new Object[]{Material.TERRACOTTA, 9985604}, new Object[]{Material.SMOOTH_SANDSTONE, 14207899}, new Object[]{Material.OAK_PLANKS, 10650190}, new Object[]{Material.BIRCH_PLANKS, 12627833}};

    static Puppet.Colors from(BufferedImage img, boolean slim) {
        int $stack0 = img.getHeight() >= 64;
        boolean modern = $stack0;
        Puppet.Colors new Puppet.Colors;
        $stack0 = new Puppet.Colors;
        Puppet.Colors $stack1 = new Puppet.Colors;
        super(nearest(average(img, 20, 20, 8, 12, modern)), nearest(average(img, 44, 20, slim ? 3 : 4, 12, modern)), nearest(average(img, 4, 20, 4, 12, modern)));
        return $stack0;
    }

    private static int average(BufferedImage img, int x0, int y0, int w, int h, boolean overlay) {
        long r = 0L;
        long g = 0L;
        long b = 0L;
        long n = 0L;
        for (int y = y0; y < y0 + h; y++) {
            for (int x = x0; x < x0 + w; x++) {
                int px = img.getRGB(x, y);
                if (overlay) {
                    int top = img.getRGB(x, y + 16);
                    if (top >>> 24 > 128) {
                        px = top;
                    }
                }
                if (px >>> 24 >= 128) {
                    r += (long)(px >> 16 & 255);
                    g += (long)(px >> 8 & 255);
                    b += (long)(px & 255);
                    n += 1L;
                }
            }
        }
        if (n == 0L) {
            return 9985604;
        }
        return (int)(r / n) << 16 | (int)(g / n) << 8 | (int)(b / n);
    }

    private static Material nearest(int rgb) {
        Material best = Material.TERRACOTTA;
        long bestD = 9223372036854775807L;
        for (Object[] e : PALETTE) {
            int c = (Integer)e[1];
            long dr = (long)((rgb >> 16 & 255) - (c >> 16 & 255));
            long dg = (long)((rgb >> 8 & 255) - (c >> 8 & 255));
            long db = (long)((rgb & 255) - (c & 255));
            long d = 2L * dr * dr + 4L * dg * dg + 3L * db * db;
            if (d < bestD) {
                bestD = d;
                best = (Material)e[0];
            }
        }
        return best;
    }

}