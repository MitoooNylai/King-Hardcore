// by decompiler.cc
package com.bzl.deathanimation;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;

final class Banner {
    private static final String[] BDA = new String[]{"########  ########     ###", "##     ## ##     ##   ## ##", "##     ## ##     ##  ##   ##", "########  ##     ## ##     ##", "##     ## ##     ## #########", "##     ## ##     ## ##     ##", "########  ########  ##     ##"};
    private static final String RULE = "=".repeat(70);
    private static final String THIN = "-".repeat(70);
    private static final TextColor ICE = TextColor.color(8381439);
    private static final TextColor DEEP = TextColor.color(4176127);
    private static final TextColor PALE = TextColor.color(12120575);

    static void print(BzlDeathAnimation plugin, Settings settings) {
        ConsoleCommandSender console = Bukkit.getConsoleSender();
        console.sendMessage(Component.text(RULE, NamedTextColor.DARK_GRAY));
        console.sendMessage(Component.text("  B Z L   D E V E L O P E R", DEEP, new TextDecoration[]{TextDecoration.BOLD}));
        console.sendMessage(Component.text(RULE, NamedTextColor.DARK_GRAY));
        console.sendMessage(Component.empty());
        for (String line : BDA) {
            console.sendMessage(Component.text("  " + line, ICE));
        }
        console.sendMessage(Component.empty());
        console.sendMessage(Component.text("  Death Animation", PALE, new TextDecoration[]{TextDecoration.BOLD}));
        console.sendMessage(Component.empty());
        console.sendMessage(Component.text(THIN, NamedTextColor.DARK_GRAY));
        row(console, "Plugin", "King Hardcore v" + plugin.getPluginMeta().getVersion());
        row(console, "Author", String.join(", ", plugin.getPluginMeta().getAuthors()));
        row(console, "Menu", "/bda menu  (permission bda.menu)");
        row(console, "Server", Bukkit.getName() + " " + Bukkit.getMinecraftVersion());
        row(console, "Body", Body.MANNEQUIN && !"blocks".equals(settings.body) ? "Mannequin (full skin)" : "Block body (player head)");
        row(console, "Nebula", "world '" + settings.nebulaWorld + "', " + settings.durationMinutes + " min");
        row(console, "Particles", settings.particles.size() + " effects, x" + settings.particleAmount);
        console.sendMessage(Component.text(RULE, NamedTextColor.DARK_GRAY));
    }

    private static void row(ConsoleCommandSender console, String label, String value) {
        console.sendMessage(((TextComponent)Component.text("  " + String.format("%-10s", new Object[]{label}), NamedTextColor.GRAY).append(Component.text(": ", NamedTextColor.DARK_GRAY))).append(Component.text(value, NamedTextColor.WHITE)));
    }

    private Banner() {
    }

}