// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;

final class AdminMenu {
    private static final String BRAND = "<gradient:#B8F1FF:#3FB8FF><bold>";
    private static final List<Color> PALETTE = new ArrayList<>();
    private static final List<String> PALETTE_NAMES = new ArrayList<>();

    static void open(BzlDeathAnimation plugin, Player viewer) {
        new AdminMenu.Main(plugin, viewer).open();
    }

    private static String time(long millis) {
        long s = (millis + 999L) / 1000L;
        return String.format("%02d:%02d", new Object[]{s / 60L, s % 60L});
    }

    private static void pager(Menu m, int page, int pages, IntConsumer to) {
        if (page > 0) {
            m.set(m.rows() * 9 - 6, Menu.item(Material.SPECTRAL_ARROW, "<#7FE3FF><bold>« Halaman " + page, new String[]{"<gray>Halaman " + page + 1 + " dari " + pages}), e -> to.accept(page - 1));
        }
        if (page < pages - 1) {
            m.set(m.rows() * 9 - 4, Menu.item(Material.SPECTRAL_ARROW, "<#7FE3FF><bold>Halaman " + page + 2 + " »", new String[]{"<gray>Halaman " + page + 1 + " dari " + pages}), e -> to.accept(page + 1));
        }
    }

    static List<String> describe(Fx fx) {
        List<String> lore = Menu.gray(new String[]{fx.slot.description, ""});
        List<String> $stack0 = lore;
        String $stack1 = fx.enabled ? "<#5CFF8A>● AKTIF" : "<#FF6B6B>● NONAKTIF";
        $stack0.add("<dark_gray>Status: " + $stack1);
        List<String> types = new ArrayList<>();
        int i = 0;
        double w;
        for (; i < fx.types.size(); i++) {
            w = (Double)fx.weights.get(i);
            $stack0 = types;
            $stack1 = ((Particle)fx.types.get(i)).name();
            $stack0.add("" + $stack1 + (w == 1.0 ? "" : " ×" + Fx.num(w)));
        }
        $stack0 = lore;
        $stack1 = types.isEmpty() ? "<#FF6B6B>(kosong)" : String.join(", ", types);
        $stack0.add("<gray>Partikel: <white>" + $stack1);
        StringBuilder colors = new StringBuilder();
        for (Color c : fx.colors) {
            colors.append("<color:").append(Fx.hex(c)).append(">■</color>");
        }
        lore.add("<gray>Warna: " + String.valueOf(colors));
        lore.add("<gray>Ukuran: <white>" + Fx.num((double)fx.size) + "   <gray>Jumlah: <white>x" + Fx.num(fx.amount));
        if (fx.types.stream().anyMatch(t -> t.getDataType() == BlockData.class)) {
            lore.add("<gray>Blok: <white>" + fx.block.getMaterial().getKey().getKey());
        }
        return lore;
    }

    private static List<Particle> choices() {
        return Arrays.stream(Particle.values()).filter(Fx::supported).sorted(Comparator.comparing(Enum::name)).toList();
    }

    private AdminMenu() {
    }

    static {
        String[][] brand = DyeColor.values();
        int i = brand.length;
        int i2 = 0;
        DyeColor d;
        for (; i2 < i; i2++) {
            d = brand[i2];
            PALETTE.add(d.getColor());
            PALETTE_NAMES.add(d.name().toLowerCase(Locale.ROOT).replace(95, 32));
        }
        brand = new String[][]{new String[]{"#FFFFFF", "putih terang"}, new String[]{"#B8F1FF", "es pucat"}, new String[]{"#7FE3FF", "es"}, new String[]{"#3FB8FF", "biru portal"}, new String[]{"#FFD86B", "emas"}};
        i = brand;
        i2 = i.length;
        for (d = 0; d < i2; d++) {
            String[] b = i[d];
            PALETTE.add(Fx.parseColor(b[0]));
            PALETTE_NAMES.add(b[1]);
        }
    }
}