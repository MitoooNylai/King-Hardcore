// by decompiler.cc
package com.bzl.deathanimation;

import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;

static final class ParticleEdit extends Menu {
    private final Fx.Slot slot;
    private final int returnPage;

    ParticleEdit(BzlDeathAnimation plugin, Player viewer, Fx.Slot slot, int returnPage) {
        super(plugin, viewer);
        this.slot = slot;
        this.returnPage = returnPage;
    }

    Component title() {
        return plugin.settings.msg("menu.title.particle", new TagResolver[]{Placeholder.unparsed("name", slot.key)});
    }

    int rows() {
        return 5;
    }

    private String path(String field) {
        return "particles.effects." + slot.key + "." + field;
    }

    void draw() {
        Fx fx = (Fx)plugin.settings.particles.get(slot);
        set(4, Menu.glow(item(slot.icon, "<#B8F1FF><bold>" + slot.key, AdminMenu.describe(fx)), 1));
        AdminMenu.ParticleEdit $stack0 = this;
        int $stack1 = 19;
        Material $stack2 = fx.enabled ? Material.LIME_DYE : Material.GRAY_DYE;
        $stack0.toggle($stack1, $stack2, "Aktif", path("enabled"), fx.enabled, new String[]{"Mati = efek ini tidak", "menggambar apa pun."});
        List<String> types = gray(new String[]{"Partikel yang digambar.", "Bisa campuran beberapa tipe.", ""});
        List colors = fx.entries().iterator();
        String entry;
        while (colors.hasNext()) {
            entry = (String)colors.next();
            types.add("<dark_gray>  • <white>" + entry);
        }
        types.add("");
        types.add("<#7FE3FF>» <gray>Klik untuk memilih");
        set(20, item(Material.BLAZE_POWDER, "<#B8F1FF><bold>Tipe Partikel", types), e -> go(new AdminMenu.ParticlePicker(plugin, viewer, slot, returnPage, 0)));
        colors = gray(new String[]{"Untuk partikel berwarna (DUST,", "DUST_COLOR_TRANSITION, ...).", "Beberapa warna = gradasi.", ""});
        for (Color c : fx.colors) {
            colors.add("<color:" + Fx.hex(c) + ">■ <white>" + Fx.hex(c));
        }
        colors.add("");
        colors.add("<#7FE3FF>» <gray>Klik untuk memilih");
        set(21, Menu.swatch((Color)fx.colors.get(0), "<#B8F1FF><bold>Warna", colors), e -> go(new AdminMenu.ColorPicker(plugin, viewer, slot, returnPage)));
        number(22, Material.SLIME_BALL, "Ukuran", path("size"), (double)fx.size, 0.1, 0.5, 0.1, 4.0, 0, "", new String[]{"Ukuran partikel berwarna."});
        number(23, Material.HOPPER, "Jumlah", path("amount"), fx.amount, 0.1, 0.5, 0.0, 10.0, 0, "x", new String[]{"Pengali jumlah partikel slot ini."});
        Material held = viewer.getInventory().getItemInMainHand().getType();
        $stack0 = fx.block.getMaterial().isItem() ? fx.block.getMaterial() : Material.STONE;
        Material shown = $stack0;
        $stack0 = this;
        $stack1 = 24;
        $stack2 = shown;
        String $stack3 = "<#B8F1FF><bold>Blok";
        String[] $stack4 = new String[]{"<gray>Untuk partikel blok (BLOCK,", "<gray>FALLING_DUST, BLOCK_MARKER ...).", "", "<gray>Sekarang: <white>" + fx.block.getMaterial().getKey().getKey(), "", "<#7FE3FF>Klik kiri <gray>» pakai blok di tanganmu"};
        new String[]{"<gray>Untuk partikel blok (BLOCK,", "<gray>FALLING_DUST, BLOCK_MARKER ...).", "", "<gray>Sekarang: <white>" + fx.block.getMaterial().getKey().getKey(), "", "<#7FE3FF>Klik kiri <gray>» pakai blok di tanganmu"}[6] = "<dark_gray>  (di tangan: " + (held.isBlock() && !held.isAir() ? held.getKey().getKey() : "bukan blok") + ")";
        $stack4[7] = "<#7FE3FF>Klik kanan <gray>» kembali ke default";
        $stack0.set($stack1, item($stack2, $stack3, $stack4), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        if (e.isRightClick()) {
            restore(path("block"));
        } else {
            label0: {
                if (held.isBlock() && !held.isAir()) {
                    save(path("block"), held.getKey().getKey());
                    sound("block.stone.place", 1.0F);
                    break label0;
                }
                plugin.tell(viewer, "menu.hold-block", new String[0]);
                sound("entity.villager.no", 1.0F);
            }
        }
    });
        set(25, item(Material.ENDER_EYE, "<#B8F1FF><bold>Pratinjau", new String[]{"<gray>Munculkan efek ini di depanmu", "<gray>beberapa kali (tutup menu untuk", "<gray>melihat lebih jelas).", "", "<#7FE3FF>» <gray>Klik untuk melihat"}), e -> preview(fx));
        set(42, item(Material.LAVA_BUCKET, "<#FF6B6B><bold>Reset ke Default", new String[]{"<gray>Kembalikan slot ini ke bawaan", "<gray>plugin (tipe, warna, ukuran ...).", "", "<#7FE3FF>Shift + klik <gray>» reset"}), e -> {
        if (!e.isShiftClick() || !can("bda.menu.edit")) {
            return;
        }
        restore("particles.effects." + slot.key);
        sound("block.anvil.use", 1.4F);
    });
        back(40, () -> new AdminMenu.Particles(plugin, viewer, returnPage));
    }

    private void preview(Fx fx) {
        Location at = viewer.getEyeLocation().add(viewer.getLocation().getDirection().multiply(2.5));
        sound("block.amethyst_block.chime", 1.6F);
        new AdminMenu.ParticleEdit$1(this, fx, at).runTaskTimer(plugin, 0L, 8L);
    }
}