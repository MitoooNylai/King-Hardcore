// by decompiler.cc
package com.bzl.deathanimation;

import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.entity.Player;

static final class Particles extends Menu {
    private final int page;

    Particles(BzlDeathAnimation plugin, Player viewer, int page) {
        super(plugin, viewer);
        this.page = page;
    }

    Component title() {
        return plugin.settings.msg("menu.title.particles", new TagResolver[0]);
    }

    void draw() {
        Settings s = plugin.settings;
        Fx.Slot[] slots = Fx.Slot.values();
        int pages = (slots.length + INNER.length - 1) / INNER.length;
        header(Material.BLAZE_POWDER, "Editor Partikel", new String[]{"Setiap efek di animasi adalah", "satu slot. Kode mengatur bentuk,", "slot mengatur isi.", "", "<white>" + slots.length + " <gray>slot"});
        label0: for (int i = 0; i < INNER.length; i++) {
            int idx = page * INNER.length + i;
            if (idx >= slots.length) {
                break label0;
            }
            Fx.Slot slot = slots[idx];
            Fx fx = (Fx)s.particles.get(slot);
            List lore = AdminMenu.describe(fx);
            lore.add("");
            lore.add("<#7FE3FF>Klik kiri <gray>» edit");
            List<String> $stack0 = lore;
            String $stack1 = fx.enabled ? "matikan" : "nyalakan";
            $stack0.add("<#7FE3FF>Klik kanan <gray>» " + $stack1);
            $stack0 = this;
            $stack1 = INNER[i];
            $stack0.set($stack1, Menu.glow(item(slot.icon, (fx.enabled ? "<#5CFF8A>" : "<#FF6B6B>") + "<bold>" + slot.key, lore), fx.enabled), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        if (e.isRightClick()) {
            AdminMenu.Particles $stack0 = this;
            String $stack1 = "particles.effects." + slot.key + ".enabled";
            int $stack2 = !fx.enabled;
            $stack0.save($stack1, $stack2);
            $stack0 = this;
            $stack1 = "block.note_block.pling";
            $stack2 = fx.enabled ? 0.7F : 1.6F;
            $stack0.sound($stack1, $stack2);
        } else {
            go(new AdminMenu.ParticleEdit(plugin, viewer, slot, page));
        }
    });
        }
        number(46, Material.GLOWSTONE_DUST, "Pengali Jumlah", "particles.amount-multiplier", s.particleAmount, 0.1, 0.5, 0.0, 5.0, 0, "x", new String[]{"Mengalikan SEMUA partikel.", "Turunkan di server ramai."});
        number(52, Material.SPYGLASS, "Jarak Pandang", "particles.view-distance", (double)s.particleViewDistance, 8.0, 32.0, 8.0, 256.0, 1, " blok", new String[]{"Pemain lebih jauh dari ini", "tidak menerima partikel."});
        AdminMenu.pager(this, page, pages, p -> go(new AdminMenu.Particles(plugin, viewer, p)));
        back(49, () -> new AdminMenu.Main(plugin, viewer));
    }
}