// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

static final class Players extends Menu {
    private final int page;

    Players(BzlDeathAnimation plugin, Player viewer, int page) {
        super(plugin, viewer);
        this.page = page;
    }

    Component title() {
        return plugin.settings.msg("menu.title.players", new TagResolver[0]);
    }

    boolean live() {
        return 1;
    }

    void draw() {
        List<Player> trapped = plugin.nebula.trapped();
        int pages = Math.max(1, (trapped.size() + INNER.length - 1) / INNER.length);
        int shown = Math.min(page, pages - 1);
        boolean manage = viewer.hasPermission("bda.menu.players.manage");
        header(Material.ENDER_EYE, "Pemain di Nebula", new String[]{"<white>" + trapped.size() + " <gray>pemain terkurung", "(hanya yang online).", "", "<dark_gray>Diperbarui setiap detik."});
        if (trapped.isEmpty()) {
            set(22, item(Material.GLASS_BOTTLE, "<gray><bold>Nebula kosong", new String[]{"<dark_gray>Tidak ada pemain yang terkurung."}));
        }
        label0: for (int i = 0; i < INNER.length; i++) {
            int idx = shown * INNER.length + i;
            if (idx >= trapped.size()) {
                break label0;
            }
            Player p = (Player)trapped.get(idx);
            set(INNER[i], head(p, manage), e -> act(p, e.isRightClick(), e.isShiftClick()));
        }
        if (!trapped.isEmpty()) {
            button(51, item(Material.TNT, "<#FF6B6B><bold>Bebaskan Semua", new String[]{"<gray>Lepaskan semua pemain yang", "<gray>tidak sedang dalam animasi.", "", "<#7FE3FF>Shift + klik <gray>» bebaskan"}), "bda.menu.players.manage", e -> {
        if (!e.isShiftClick()) {
            return;
        }
        int n = 0;
        for (Player p : trapped) {
            if (p.isOnline() && plugin.nebula.isTrapped(p) && (!plugin.running.containsKey(p.getUniqueId()) && !plugin.nebula.busy(p))) {
                plugin.nebula.release(p);
                n++;
            }
        }
        if (plugin.settings.has("menu.released-all")) {
            viewer.sendMessage(plugin.settings.msg("menu.released-all", new TagResolver[]{Placeholder.unparsed("count", String.valueOf(n))}));
        }
        sound("entity.player.levelup", 1.2F);
        redraw();
    });
        }
        AdminMenu.pager(this, shown, pages, p -> go(new AdminMenu.Players(plugin, viewer, p)));
        back(49, () -> new AdminMenu.Main(plugin, viewer));
    }

    private ItemStack head(Player p, boolean manage) {
        String $stack0;
        if (plugin.running.containsKey(p.getUniqueId()) || plugin.nebula.busy(p)) {
            $stack0 = "<yellow>Dalam animasi";
        } else {
            label0: {
                if (plugin.nebula.isNebula(p.getWorld())) {
                    $stack0 = "<#5CFF8A>Di Nebula";
                    break label0;
                }
                $stack0 = "<#FF6B6B>Di luar Nebula (bypass)";
            }
        }
        String status = $stack0;
        List lore = new ArrayList(List.of("<gray>Sisa waktu: <white><bold>" + AdminMenu.time(plugin.nebula.remaining(p)), "<gray>Status: " + status, "<gray>Dunia: <white>" + Menu.esc(p.getWorld().getName()), ""));
        if (manage) {
            lore.add("<#7FE3FF>Klik kiri <gray>» teleport ke pemain");
            lore.add("<#7FE3FF>Klik kanan <gray>» bebaskan sekarang");
            lore.add("<#7FE3FF>Shift + kiri <gray>» +5 menit");
            lore.add("<#7FE3FF>Shift + kanan <gray>» -5 menit");
        } else {
            lore.add("<#FF6B6B>✖ Butuh izin <white>bda.menu.players.manage");
        }
        ItemStack item = item(Material.PLAYER_HEAD, "<#B8F1FF><bold>" + p.getName(), lore);
        SkullMeta meta = (SkullMeta)item.getItemMeta();
        meta.setPlayerProfile(p.getPlayerProfile());
        item.setItemMeta(meta);
        return item;
    }

    private void act(Player p, boolean right, boolean shift) {
        if (!can("bda.menu.players.manage")) {
            return;
        }
        if (!p.isOnline() || !plugin.nebula.isTrapped(p)) {
            redraw();
            return;
        }
        if (shift) {
            int $stack0 = right ? -5 : 5;
            int minutes = $stack0;
            plugin.nebula.addTime(p, (long)minutes * 60000L);
            String $stack1;
            float $stack2;
            if (plugin.settings.has("menu.time-changed")) {
                $stack0 = viewer;
                $stack1 = plugin.settings;
                $stack2 = "menu.time-changed";
                TagResolver[] $stack3 = new TagResolver[]{Placeholder.unparsed("player", p.getName())};
                new TagResolver[]{Placeholder.unparsed("player", p.getName())}[1] = Placeholder.unparsed("minutes", "" + (minutes > 0 ? "+" : "") + minutes);
                $stack3[2] = Placeholder.unparsed("time", AdminMenu.time(plugin.nebula.remaining(p)));
                $stack0.sendMessage($stack1.msg($stack2, $stack3));
            }
            $stack0 = this;
            $stack1 = "block.note_block.hat";
            $stack2 = right ? 0.8F : 1.4F;
            $stack0.sound($stack1, $stack2);
            redraw();
        } else {
            label0: {
                if (right) {
                    plugin.skip(viewer, p);
                    redraw();
                    break label0;
                }
                later(() -> {
        viewer.closeInventory();
        viewer.teleport(p);
    });
            }
        }
    }
}