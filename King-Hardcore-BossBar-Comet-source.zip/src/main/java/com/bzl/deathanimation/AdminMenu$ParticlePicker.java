// by decompiler.cc
package com.bzl.deathanimation;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

static final class ParticlePicker extends Menu {
    private final Fx.Slot slot;
    private final int returnPage;
    private final int page;

    ParticlePicker(BzlDeathAnimation plugin, Player viewer, Fx.Slot slot, int returnPage, int page) {
        super(plugin, viewer);
        this.slot = slot;
        this.returnPage = returnPage;
        this.page = page;
    }

    Component title() {
        return plugin.settings.msg("menu.title.picker", new TagResolver[]{Placeholder.unparsed("name", slot.key)});
    }

    void draw() {
        Fx fx = (Fx)plugin.settings.particles.get(slot);
        List<Particle> all = AdminMenu.choices();
        int pages = (all.size() + INNER.length - 1) / INNER.length;
        List head = gray(new String[]{"Dipakai sekarang:"});
        int i = fx.entries().iterator();
        while (i.hasNext()) {
            String entry = (String)i.next();
            head.add("<dark_gray>  • <white>" + entry);
        }
        head.add("");
        head.add("<dark_gray>Bobot campuran (NAMA*bobot) bisa");
        head.add("<dark_gray>diatur di config.yml.");
        set(4, Menu.glow(item(Material.BLAZE_POWDER, "<#B8F1FF><bold>Tipe Partikel: " + slot.key, head), 1));
        label0: for (i = 0; i < INNER.length; i++) {
            int idx = page * INNER.length + i;
            if (idx >= all.size()) {
                break label0;
            }
            Particle type = (Particle)all.get(idx);
            int at = fx.types.indexOf(type);
            int $stack0 = at >= 0;
            boolean used = $stack0;
            List lore = gray(new String[]{"Data: " + needs(type), ""});
            $stack0 = lore;
            String $stack1 = used ? "<#5CFF8A>✔ Dipakai" : "<dark_gray>Tidak dipakai";
            $stack0.add($stack1);
            lore.add("");
            lore.add("<#7FE3FF>Klik kiri <gray>» pakai ini saja");
            $stack0 = lore;
            $stack1 = used ? "hapus dari campuran" : "tambah ke campuran";
            $stack0.add("<#7FE3FF>Klik kanan <gray>» " + $stack1);
            $stack0 = this;
            $stack1 = INNER[i];
            $stack0.set($stack1, Menu.glow(item(icon(type), (used ? "<#5CFF8A>" : "<white>") + type.name(), lore), used), e -> {
        if (!can("bda.menu.edit")) {
            return;
        }
        List entries = new ArrayList(fx.entries());
        if (!e.isRightClick()) {
            entries = List.of(type.name());
        } else {
            label0: {
                if (used) {
                    if (entries.size() == 1) {
                        sound("entity.villager.no", 1.0F);
                        return;
                    }
                    entries.remove(at);
                    break label0;
                }
                entries.add(type.name());
            }
        }
        save("particles.effects." + slot.key + ".particles", entries);
        sound("entity.experience_orb.pickup", 1.4F);
    });
        }
        AdminMenu.pager(this, page, pages, p -> go(new AdminMenu.ParticlePicker(plugin, viewer, slot, returnPage, p)));
        back(49, () -> new AdminMenu.ParticleEdit(plugin, viewer, slot, returnPage));
    }

    private static String needs(Particle type) {
        Class<?> want = type.getDataType();
        if (want == Particle.DustOptions.class) {
            return "warna + ukuran";
        }
        if (want == Particle.DustTransition.class) {
            return "2 warna + ukuran";
        }
        if (want == Color.class) {
            return "warna";
        }
        if (want == BlockData.class) {
            return "blok";
        }
        if (want == ItemStack.class) {
            return "item (dari blok)";
        }
        if (want == Float.class) {
            return "ukuran";
        }
        if (want == Integer.class) {
            return "angka (0)";
        }
        return "-";
    }

    private static Material icon(Particle type) {
        Class<?> want = type.getDataType();
        if (want == Particle.DustOptions.class || want == Particle.DustTransition.class || want == Color.class) {
            return Material.RED_DYE;
        }
        if (want == BlockData.class) {
            return Material.BRICKS;
        }
        if (want == ItemStack.class) {
            return Material.ITEM_FRAME;
        }
        if (want == Float.class || want == Integer.class) {
            return Material.AMETHYST_SHARD;
        }
        return Material.GLOWSTONE_DUST;
    }
}