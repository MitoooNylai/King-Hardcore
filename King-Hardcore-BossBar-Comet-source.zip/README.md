# KingHardcore 1.0.0 — decompiled source project

This project was assembled from:
- `KingHardcore-1.0.0-sources.zip` (40 decompiled Java source files)
- `KingHardcore-1.0.0.jar` (plugin.yml, config.yml, messages.yml)

## Structure
- `src/main/java/com/bzl/deathanimation/` — Java sources
- `src/main/resources/` — plugin.yml and original YAML configuration files
- `pom.xml` — Maven build configuration targeting Paper API 1.21.11 / Java 21

## Build
Run `mvn package`. The plugin JAR will be created in `target/`.

## Important
These are decompiled sources, not the author's original project. Decompilation can change syntax, names, and structure, and some bytecode constructs may not reconstruct into compilable Java. The Maven configuration is a starting point; if compilation reports errors, those errors need to be fixed. Keep the original JAR as a backup.
