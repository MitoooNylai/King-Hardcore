# King Hardcore source (CFR decompile)

- Branding strings changed to King Hardcore.
- Nebula ActionBar countdown replaced with a blue Bukkit BossBar.
- BossBar title: `☄ Rebirth in MM:SS ☄`.
- BossBar is removed on release, player quit, or leaving the Nebula.

This is decompiled code, not the original developer source. CFR output can contain Java constructs that need manual repair. The project has not yet been successfully compiled or tested on a Paper server. Keep the original plugin JAR as backup.
