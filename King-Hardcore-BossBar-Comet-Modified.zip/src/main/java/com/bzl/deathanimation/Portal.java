/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.entity.BlockDisplay
 *  org.bukkit.entity.Display
 *  org.bukkit.entity.Display$Brightness
 *  org.bukkit.entity.Entity
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionf
 *  org.joml.Quaternionfc
 *  org.joml.Vector3f
 *  org.joml.Vector3fc
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Puppet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

final class Portal {
    private static final int STEADY_EVERY = 6;
    static final int FALL_DUR = 14;
    static final int BOUNCE_DUR = 8;
    static final int ASSEMBLE_DUR = 26;
    static final int RUNE_DUR = 8;
    private static final float LIFT_PART = 0.3f;
    private static final int LAYERS = 24;
    private static final Display.Brightness FULL_BRIGHT = new Display.Brightness(15, 15);
    private static final Display.Brightness PORTAL_LIT = new Display.Brightness(10, 15);
    private static final float CORE_R = 1.45f;
    private static final float EDGE_R = 1.62f;
    private static final float[] CROWN = new float[]{14.0f, 36.0f, 58.0f, 80.0f, 100.0f, 122.0f, 144.0f, 166.0f};
    private static final float[] FRAME = new float[]{196.0f, 218.0f, 240.0f, 300.0f, 322.0f, 344.0f};
    private static final float[] PENTA = new float[]{0.5f, 0.561f, 0.63f, 0.749f, 0.841f, 1.0f, 1.122f, 1.26f, 1.498f, 1.682f, 2.0f};
    private final List<BlockDisplay> core = new ArrayList<BlockDisplay>();
    private final List<BlockDisplay> edge = new ArrayList<BlockDisplay>();
    private final List<BlockDisplay> frame = new ArrayList<BlockDisplay>();
    private final List<BlockDisplay> deep = new ArrayList<BlockDisplay>();
    private static final float DEEP_R = 1.82f;
    private final List<BlockDisplay> notches = new ArrayList<BlockDisplay>();
    private static final float FRAME_R = 2.05f;
    private static final int NOTCHES = 12;
    private final List<Stone> stones = new ArrayList<Stone>();
    private final List<Step> steps = new ArrayList<Step>();
    private final List<Deco> decos = new ArrayList<Deco>();
    private final List<Display> all = new ArrayList<Display>();
    private final Matrix4f face;
    private final Location at;
    private final World world;
    private final float groundY;
    private final Timing timing;
    private float lastSteps = -1.0f;

    Portal(Location center, float yaw, double heightAboveGround, Timing timing) {
        this.at = center.clone();
        this.at.setYaw(0.0f);
        this.at.setPitch(0.0f);
        this.world = this.at.getWorld();
        this.timing = timing;
        this.face = new Matrix4f().rotateY((float)(-Math.toRadians(yaw)));
        this.groundY = (float)(-heightAboveGround);
        try {
            int i;
            Random r = new Random((long)center.getBlockX() * 31L + (long)center.getBlockZ());
            for (i = 0; i < 24; ++i) {
                this.core.add(this.spawn(Material.WHITE_CONCRETE, true));
                BlockDisplay e = this.spawn(Material.LIGHT_BLUE_CONCRETE, true);
                this.edge.add(e);
                this.deep.add(this.spawn(Material.BLUE_CONCRETE, true));
                BlockDisplay f = this.spawn(Material.POLISHED_DEEPSLATE, false);
                f.setBrightness(PORTAL_LIT);
                this.frame.add(f);
            }
            for (i = 0; i < 12; ++i) {
                BlockDisplay n = this.spawn(Material.LIGHT_BLUE_CONCRETE, true);
                this.notches.add(n);
            }
            for (float deg : CROWN) {
                boolean top = deg > 60.0f && deg < 120.0f;
                this.stones.add(this.stone(deg, (top ? 1.9f : 1.35f) + r.nextFloat() * 0.5f, 0.62f + r.nextFloat() * 0.28f, 0.5f, r));
            }
            for (float deg : FRAME) {
                this.stones.add(this.stone(deg, 0.95f + r.nextFloat() * 0.25f, 0.7f, 0.6f, r));
            }
            ArrayList<Stone> order = new ArrayList<Stone>(this.stones);
            Collections.shuffle(order, r);
            for (int i2 = 0; i2 < order.size(); ++i2) {
                ((Stone)order.get((int)i2)).order = i2;
                ((Stone)order.get((int)i2)).fallStart = timing.fallStart + i2 * 5 / 2;
                ((Stone)order.get((int)i2)).assembleStart = timing.assembleStart + i2 * 2;
            }
            this.buildSteps();
            this.buildCircle();
            this.buildRays(r);
            this.buildLanterns();
            this.buildBraziers();
            this.buildSpikes(r);
            this.buildCrystals(r);
            this.update(0, 0.0f);
        }
        catch (RuntimeException e) {
            this.remove();
            throw e;
        }
    }

    private BlockDisplay spawn(Material m, boolean bright) {
        return this.spawn(m.createBlockData(), bright);
    }

    private static BlockData data(String ... ids) {
        for (String id : ids) {
            try {
                return Bukkit.createBlockData((String)id);
            }
            catch (IllegalArgumentException illegalArgumentException) {
            }
        }
        return Material.STONE.createBlockData();
    }

    private BlockDisplay spawn(BlockData data, boolean bright) {
        BlockDisplay d = (BlockDisplay)this.world.spawn(this.at, BlockDisplay.class, e -> {
            e.setPersistent(false);
            e.addScoreboardTag("bda_fx");
            e.setBlock(data);
            if (bright) {
                e.setBrightness(FULL_BRIGHT);
            }
        });
        this.all.add((Display)d);
        return d;
    }

    private static Matrix4f box(float w, float h, float d) {
        return new Matrix4f().translate(-w / 2.0f, -h / 2.0f, -d / 2.0f).scale(w, h, d);
    }

    private Stone stone(float deg, float h, float w, float d, Random r) {
        Stone st = new Stone();
        float wu = w * 0.78f;
        this.add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate(0.0f, -0.175f * h, 0.0f).mul((Matrix4fc)Portal.box(w, 0.65f * h, d)));
        this.add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate(0.0f, 0.275f * h, 0.0f).rotateZ(0.04f).mul((Matrix4fc)Portal.box(wu, 0.45f * h, d * 0.95f)));
        this.add(st, Material.DEEPSLATE_TILES, new Matrix4f().translate(-w * 0.16f, h * 0.05f, -0.01f).rotateZ(0.2f).mul((Matrix4fc)Portal.box(w * 0.62f, h * 0.5f, d * 1.06f)));
        this.add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate(w * 0.2f, -h * 0.22f, 0.01f).rotateZ(-0.17f).mul((Matrix4fc)Portal.box(w * 0.6f, h * 0.42f, d * 1.04f)));
        float t = wu / (float)Math.sqrt(2.0);
        float[][] tiers = new float[][]{{0.0f, 1.0f, 0.92f}, {0.38f, 0.62f, 0.75f}, {0.66f, 0.34f, 0.55f}};
        for (int i = 0; i < tiers.length; ++i) {
            float s = t * tiers[i][1];
            this.add(st, i == 1 ? Material.DEEPSLATE_TILES : Material.POLISHED_DEEPSLATE, new Matrix4f().translate(0.0f, h / 2.0f + wu * tiers[i][0], 0.0f).rotateZ(0.7853982f).mul((Matrix4fc)Portal.box(s, s, d * tiers[i][2])));
        }
        this.add(st, Material.COBBLED_DEEPSLATE, new Matrix4f().translate(w * 0.1f, -h / 2.0f, 0.0f).rotateZ(0.9853982f).mul((Matrix4fc)Portal.box(t * 0.8f, t * 0.8f, d * 0.85f)));
        for (int side = -1; side <= 1; side += 2) {
            this.add(st, Material.POLISHED_DEEPSLATE, new Matrix4f().translate((float)side * w / 2.0f, -h * 0.18f, 0.0f).rotateY(0.7853982f).mul((Matrix4fc)Portal.box(d * 0.55f, h * 0.55f, d * 0.55f)));
        }
        if (h > 1.2f) {
            this.add(st, Material.DEEPSLATE_TILES, new Matrix4f().translate(-w * 0.7f, h * 0.38f, -0.1f).rotateXYZ(0.5f, 0.3f, 0.8f).mul((Matrix4fc)Portal.box(0.22f, 0.3f, 0.2f)));
        }
        float z = -d * 0.53f - 0.012f;
        float[][] pts = new float[][]{{-0.12f * w, -0.34f * h}, {0.22f * w, -0.1f * h}, {-0.2f * w, 0.12f * h}, {0.12f * w, 0.36f * h}};
        for (int i = 0; i < pts.length - 1; ++i) {
            this.rune(st, pts[i][0] + (r.nextFloat() - 0.5f) * 0.08f, pts[i][1], pts[i + 1][0] + (r.nextFloat() - 0.5f) * 0.08f, pts[i + 1][1], z);
        }
        this.rune(st, pts[1][0], pts[1][1], pts[1][0] + 0.18f * w, pts[1][1] + 0.12f * h, z);
        float a = (float)Math.toRadians(deg);
        float rad = 1.62f + (deg > 180.0f ? 0.2f : 0.35f) + h / 2.0f;
        st.finalPos = new Vector3f((float)Math.cos(a) * rad, (float)Math.sin(a) * rad, 0.05f);
        st.finalRot = new Quaternionf().rotateZ(a - 1.5707964f + (float)Math.toRadians((r.nextFloat() - 0.5f) * 14.0f)).rotateY((float)Math.toRadians((r.nextFloat() - 0.5f) * 28.0f));
        st.groundPos = new Vector3f((r.nextFloat() - 0.5f) * 7.0f, this.groundY + d * 0.4f, -2.6f + r.nextFloat() * 4.2f);
        st.groundRot = new Quaternionf().rotateY(r.nextFloat() * 6.283f).rotateX(1.5707964f + (r.nextFloat() - 0.5f) * 0.4f);
        st.skyPos = new Vector3f((Vector3fc)st.groundPos).add((r.nextFloat() - 0.5f) * 3.0f, 30.0f + r.nextFloat() * 6.0f, (r.nextFloat() - 0.5f) * 3.0f);
        st.skyRot = new Quaternionf().rotateXYZ(r.nextFloat() * 6.283f, r.nextFloat() * 6.283f, r.nextFloat() * 6.283f);
        st.phase = r.nextFloat() * 6.0f;
        return st;
    }

    private void add(Stone st, Material m, Matrix4f local) {
        BlockDisplay d = this.spawn(m, false);
        d.setBrightness(PORTAL_LIT);
        st.pieces.add(new Piece(d, local, null));
    }

    private void rune(Stone st, float x0, float y0, float x1, float y1, float z) {
        float len = (float)Math.hypot(x1 - x0, y1 - y0) + 0.05f;
        float ang = (float)Math.atan2(y1 - y0, x1 - x0);
        Vector3f mid = new Vector3f((x0 + x1) / 2.0f, (y0 + y1) / 2.0f, z);
        BlockDisplay d = this.spawn(Material.LIGHT_BLUE_CONCRETE, true);
        st.pieces.add(new Piece(d, new Matrix4f().translate((Vector3fc)mid).rotateZ(ang).mul((Matrix4fc)Portal.box(len, 0.07f, 0.02f)), mid));
    }

    private void buildSteps() {
        for (int i = 0; i < 3; ++i) {
            float radius = 2.25f - (float)i * 0.5f;
            float height = 0.25f * (float)(i + 1);
            float depth = 0.62f;
            int segs = 7 - i * 2;
            float stepAng = (float)Math.toRadians(16.0);
            float segW = 2.0f * radius * (float)Math.tan(stepAng / 2.0f) + 0.06f;
            Material m = i == 2 ? Material.POLISHED_DEEPSLATE : Material.DEEPSLATE_TILES;
            for (int k = -(segs / 2); k <= segs / 2; ++k) {
                float th = (float)k * stepAng;
                float x = (float)Math.sin(th) * radius;
                float z = -((float)Math.cos(th)) * radius;
                this.steps.add(new Step(this.spawn(m, false), new Matrix4f().translate(x, this.groundY + height / 2.0f, z).rotateY(-th).mul((Matrix4fc)Portal.box(segW, height, depth))));
            }
        }
    }

    private void buildCircle() {
        int segs = 24;
        float y = this.groundY + 0.03f;
        float rad = 3.1f;
        for (int i = 0; i < segs; ++i) {
            double a0 = (double)i * Math.PI * 2.0 / (double)segs;
            double a1 = (double)(i + 1) * Math.PI * 2.0 / (double)segs;
            Vector3f p0 = new Vector3f((float)Math.cos(a0) * rad, y, (float)Math.sin(a0) * rad);
            Vector3f p1 = new Vector3f((float)Math.cos(a1) * rad, y, (float)Math.sin(a1) * rad);
            this.groundLine(p0, p1, this.timing.drawStart + i, i % 2 == 0 ? PENTA[i / 2 % PENTA.length] : 0.0f);
        }
        float hr = 2.7f;
        for (int tri = 0; tri < 2; ++tri) {
            for (int j = 0; j < 3; ++j) {
                double a0 = 1.5707963267948966 + (double)tri * Math.PI + (double)j * Math.PI * 2.0 / 3.0;
                double a1 = a0 + 2.0943951023931953;
                Vector3f p0 = new Vector3f((float)Math.cos(a0) * hr, y + 0.005f, (float)Math.sin(a0) * hr);
                Vector3f p1 = new Vector3f((float)Math.cos(a1) * hr, y + 0.005f, (float)Math.sin(a1) * hr);
                this.groundLine(p0, p1, this.timing.drawStart + segs + (tri * 3 + j) * 2, 1.5f + (float)(tri * 3 + j) * 0.08f);
            }
        }
    }

    private void groundLine(Vector3f p0, Vector3f p1, int start, float pitch) {
        float dx = p1.x - p0.x;
        float dz = p1.z - p0.z;
        float len = (float)Math.hypot(dx, dz) + 0.04f;
        Vector3f mid = new Vector3f((Vector3fc)p0).add((Vector3fc)p1).mul(0.5f);
        Matrix4f local = new Matrix4f().translate((Vector3fc)mid).rotateY((float)(-Math.atan2(dz, dx))).mul((Matrix4fc)Portal.box(len, 0.02f, 0.08f));
        this.decos.add(new Deco(this.spawn(Material.LIGHT_BLUE_CONCRETE, true), local, p0, start, 3, false, pitch > 0.0f ? "block.note_block.chime" : null, pitch));
    }

    private void buildRays(Random r) {
        float[] angles = new float[]{0.0f, 25.0f, 47.0f, 69.0f, 90.0f, 111.0f, 133.0f, 155.0f, 180.0f};
        for (int i = 0; i < angles.length; ++i) {
            float a = (float)Math.toRadians(angles[i]);
            float r0 = 1.77f;
            float len = (angles[i] > 40.0f && angles[i] < 140.0f ? 2.2f : 1.4f) + r.nextFloat() * 0.6f;
            Matrix4f local = new Matrix4f().rotateZ(a - 1.5707964f).translate(-0.6f, r0, -0.6f).scale(1.2f, len, 1.2f);
            Vector3f pivot = new Vector3f((float)Math.cos(a) * r0, (float)Math.sin(a) * r0, 0.0f);
            this.decos.add(new Deco(this.spawn(Material.END_ROD, true), local, pivot, this.timing.ignite + 2 + i, 10, false, i % 3 == 0 ? "block.amethyst_block.resonate" : null, 1.2f + (float)i * 0.05f));
        }
    }

    private void buildLanterns() {
        BlockData chain = Portal.data("minecraft:iron_chain", "minecraft:chain");
        BlockData lantern = Portal.data("minecraft:soul_lantern[hanging=true]");
        for (int side = -1; side <= 1; side += 2) {
            float x = (float)side * 2.67f;
            Vector3f pivot = new Vector3f(x, 0.9f, -0.1f);
            this.decos.add(new Deco(this.spawn(chain, false), new Matrix4f().translate(x - 0.5f, -0.5f, -0.6f).scale(1.0f, 1.4f, 1.0f), pivot, this.timing.ignite + 8, 10, true, "block.chain.place", 0.8f));
            this.decos.add(new Deco(this.spawn(lantern, true), new Matrix4f().translate(x - 0.5f, -1.5f, -0.6f), pivot, this.timing.ignite + 8, 10, true, "block.lantern.place", 0.7f));
        }
    }

    private void buildBraziers() {
        BlockData post = Portal.data("minecraft:deepslate_brick_wall[up=true]");
        BlockData fire = Portal.data("minecraft:soul_campfire[lit=true]");
        for (int side = -1; side <= 1; side += 2) {
            float th = (float)side * (float)Math.toRadians(50.0);
            float x = (float)Math.sin(th) * 3.0f;
            float z = -((float)Math.cos(th)) * 3.0f;
            Vector3f base = new Vector3f(x, this.groundY, z);
            this.decos.add(new Deco(this.spawn(post, false), new Matrix4f().translate(x - 0.5f, this.groundY, z - 0.5f).scale(1.0f, 1.3f, 1.0f), base, this.timing.stepsStart + 6, 10, false, "block.deepslate_bricks.place", 0.7f));
            this.decos.add(new Deco(this.spawn(fire, true), new Matrix4f().translate(x - 0.4f, this.groundY + 1.3f, z - 0.4f).scale(0.8f), new Vector3f(x, this.groundY + 1.3f, z), this.timing.stepsStart + 16, 6, false, "item.firecharge.use", 0.8f));
        }
    }

    private void buildSpikes(Random r) {
        String[] parts = new String[]{"base", "frustum", "tip"};
        float[] angles = new float[]{105.0f, 130.0f, 155.0f, -105.0f, -130.0f, -155.0f};
        for (int i = 0; i < angles.length; ++i) {
            float th = (float)Math.toRadians(angles[i]);
            float rad = 3.3f + r.nextFloat() * 0.6f;
            Vector3f base = new Vector3f((float)Math.sin(th) * rad, this.groundY, -((float)Math.cos(th)) * rad);
            float lean = Math.signum(angles[i]) * (0.12f + r.nextFloat() * 0.15f);
            float s = 0.6f + r.nextFloat() * 0.25f;
            float spin = r.nextFloat() * 6.28f;
            for (int j = 0; j < parts.length; ++j) {
                BlockData d = Portal.data("minecraft:pointed_dripstone[thickness=" + parts[j] + ",vertical_direction=up]");
                this.decos.add(new Deco(this.spawn(d, false), new Matrix4f().translate((Vector3fc)base).rotateZ(-lean).rotateY(spin).translate(-s / 2.0f, (float)j * s, -s / 2.0f).scale(s), base, this.timing.stepsStart + 4 + i * 3, 10, false, j == 0 ? "block.pointed_dripstone.place" : null, 0.7f));
            }
        }
    }

    private void buildCrystals(Random r) {
        int n = 0;
        BlockData cluster = Portal.data("minecraft:amethyst_cluster[facing=up]");
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 3; ++i) {
                float th = (float)side * (float)Math.toRadians((float)(62 + i * 14) + r.nextFloat() * 6.0f);
                float radius = 2.4f + r.nextFloat() * 0.5f;
                Vector3f base = new Vector3f((float)Math.sin(th) * radius, this.groundY, -((float)Math.cos(th)) * radius);
                int start = this.timing.stepsStart + 20 + n++ * 2;
                if (i != 1) {
                    this.decos.add(new Deco(this.spawn(cluster, true), new Matrix4f().translate((Vector3fc)base).rotateY(r.nextFloat() * 6.28f).translate(-0.45f, 0.0f, -0.45f).scale(0.9f), base, start, 8, false, "block.amethyst_cluster.place", 1.1f));
                    continue;
                }
                float h = 0.5f + r.nextFloat() * 0.4f;
                BlockDisplay c = this.spawn(Material.LIGHT_BLUE_STAINED_GLASS, true);
                this.decos.add(new Deco(c, new Matrix4f().translate((Vector3fc)base).rotateY(r.nextFloat() * 6.28f).rotateZ((float)side * (0.15f + r.nextFloat() * 0.3f)).rotateY(0.7853982f).translate(-0.08f, 0.0f, -0.08f).scale(0.16f, h, 0.16f), base, start, 8, false, "block.amethyst_block.place", 1.4f));
            }
        }
    }

    int update(int tick, float close) {
        boolean dialLighting;
        boolean coreAnimating;
        float keep = Math.max(0.001f, 1.0f - close);
        boolean closing = close > 0.0f;
        int impacts = 0;
        for (Stone st : this.stones) {
            Quaternionf rot;
            Vector3f pos;
            boolean bobTick;
            float fall = Portal.k(tick, st.fallStart, st.fallStart + 14);
            float asm = Portal.k(tick, st.assembleStart, st.assembleStart + 26);
            float rune = Portal.k(tick, st.assembleStart + 26, st.assembleStart + 26 + 8);
            boolean moving = tick >= st.fallStart && tick <= st.fallStart + 14 + 8 || tick >= st.assembleStart && tick <= st.assembleStart + 26 + 8;
            boolean waiting = tick < st.fallStart;
            boolean bl = bobTick = (tick + st.order) % 6 == 0;
            if (!moving && !closing && tick != 0 && (waiting || asm <= 0.0f || !bobTick)) continue;
            if (rune >= 1.0f && bobTick) {
                int b = 10 + Math.round(5.0f * (0.5f + 0.5f * (float)Math.sin((double)tick * 0.15 + (double)st.phase)));
                Display.Brightness shimmer = new Display.Brightness(b, b);
                for (Piece p : st.pieces) {
                    if (p.runePivot == null) continue;
                    p.d.setBrightness(shimmer);
                }
            }
            float scale = keep;
            if (waiting) {
                pos = st.skyPos;
                rot = st.skyRot;
                scale = 0.001f;
            } else if (asm <= 0.0f) {
                pos = new Vector3f((Vector3fc)st.skyPos).lerp((Vector3fc)st.groundPos, fall * fall);
                rot = new Quaternionf((Quaternionfc)st.skyRot).slerp((Quaternionfc)st.groundRot, fall).rotateX((1.0f - fall) * 9.0f);
                if (fall >= 1.0f) {
                    float kb = Portal.k(tick, st.fallStart + 14, st.fallStart + 14 + 8);
                    pos.y += (float)Math.sin((double)kb * Math.PI) * 0.35f * (1.0f - kb);
                    rot.rotateZ((float)Math.sin((double)kb * Math.PI * 2.0) * 0.15f * (1.0f - kb));
                }
                if (!st.falling) {
                    st.falling = true;
                    Location g = this.toWorld(st.groundPos);
                    this.world.playSound(g, "entity.ender_dragon.flap", 0.7f, 0.5f + (float)st.order * 0.03f);
                    this.world.playSound(g, "entity.blaze.shoot", 0.4f, 0.5f);
                }
                if (fall > 0.0f && fall < 1.0f) {
                    this.trail(st, pos);
                }
            } else {
                pos = this.assemblyPos(st, asm);
                float e = Portal.smooth(asm);
                rot = new Quaternionf((Quaternionfc)st.groundRot).slerp((Quaternionfc)st.finalRot, e).rotateY((1.0f - e) * 6.283f);
                if (asm >= 1.0f) {
                    float breathe = (float)Math.sin((double)tick * 0.1 + (double)st.phase) * 0.06f;
                    float len = (float)Math.hypot(st.finalPos.x, st.finalPos.y);
                    pos.add(st.finalPos.x / len * breathe, st.finalPos.y / len * breathe + (float)Math.sin((double)tick * 0.07 + (double)st.phase) * 0.06f, 0.0f);
                } else {
                    Fx.get(Fx.Slot.STONE_FLIGHT).spawn(this.toWorld(pos), 1, 0.15, 0.15, 0.15, 0.01);
                }
                if (!st.locked && asm >= 1.0f) {
                    st.locked = true;
                    this.lockIn(st, this.toWorld(pos));
                }
            }
            if (!st.landed && fall >= 1.0f) {
                st.landed = true;
                ++impacts;
                this.impact(this.toWorld(st.groundPos));
            }
            if (!st.lifted && asm > 0.0f) {
                st.lifted = true;
                Location g = this.toWorld(st.groundPos);
                Fx.get(Fx.Slot.STONE_LIFTOFF).spawn(g, 33, 0.4, 0.1, 0.4, 0.08);
                this.world.playSound(g, "block.deepslate.break", 0.6f, 0.8f);
                this.world.playSound(g, "block.beacon.power_select", 0.6f, 0.6f + (float)st.order * 0.05f);
            }
            if (tick == st.assembleStart + 26 + 3) {
                this.world.playSound(this.toWorld(pos), "block.amethyst_block.chime", 1.0f, 1.2f + (float)st.order * 0.04f);
            }
            Matrix4f m = new Matrix4f((Matrix4fc)this.face).scale(scale).translate((Vector3fc)pos).rotate((Quaternionfc)rot);
            int interp = moving || closing ? 2 : 6;
            for (Piece p : st.pieces) {
                Matrix4f local = p.local;
                if (p.runePivot != null && rune < 1.0f) {
                    float rs = Math.max(0.001f, rune);
                    local = new Matrix4f().translate((Vector3fc)p.runePivot).scale(rs).translate(-p.runePivot.x, -p.runePivot.y, -p.runePivot.z).mul((Matrix4fc)p.local);
                }
                Puppet.apply((Display)p.d, new Matrix4f((Matrix4fc)m).mul((Matrix4fc)local), tick == 0 ? 0 : interp);
            }
        }
        float rise = Portal.smooth(Portal.k(tick, this.timing.stepsStart, this.timing.stepsStart + 20));
        float stepT = rise * keep;
        if (stepT != this.lastSteps) {
            if (this.lastSteps <= 0.0f && stepT > 0.0f) {
                this.world.playSound(this.at, "block.piston.extend", 0.8f, 0.5f);
                this.world.playSound(this.at, "block.grindstone.use", 1.0f, 0.5f);
            }
            this.lastSteps = stepT;
            float shrink = Math.max(0.001f, keep);
            float sy = Math.max(0.001f, rise);
            for (Step s : this.steps) {
                Puppet.apply((Display)s.d, new Matrix4f((Matrix4fc)this.face).translate(0.0f, this.groundY, 0.0f).scale(shrink, shrink * sy, shrink).translate(0.0f, -this.groundY, 0.0f).mul((Matrix4fc)s.local), 2);
            }
            if (stepT > 0.0f && stepT < 1.0f && tick % 3 == 0) {
                Fx.get(Fx.Slot.STEPS_DEBRIS).spawn(this.toWorld(new Vector3f(0.0f, this.groundY + 0.1f, -1.6f)), 12, 1.6, 0.05, 0.6, 0.0);
            }
        }
        for (Deco dc : this.decos) {
            boolean swaying;
            boolean active = tick >= dc.start && tick <= dc.start + dc.dur;
            boolean bl = swaying = dc.swing && tick > dc.start + dc.dur && tick % 2 == 0;
            if (!active && !swaying && !closing && tick != 0) continue;
            if (tick == dc.start && dc.sound != null) {
                this.world.playSound(this.toWorld(dc.pivot), dc.sound, 0.9f, dc.pitch);
            }
            float g = Math.max(0.001f, Portal.outBack(Portal.k(tick, dc.start, dc.start + dc.dur)) * keep);
            Matrix4f m = new Matrix4f((Matrix4fc)this.face).translate((Vector3fc)dc.pivot);
            if (dc.swing) {
                m.rotateZ((float)Math.sin((double)tick * 0.09 + (double)dc.pivot.x) * 0.18f);
            }
            m.scale(g).translate(-dc.pivot.x, -dc.pivot.y, -dc.pivot.z).mul((Matrix4fc)dc.local);
            Puppet.apply((Display)dc.d, m, tick == 0 ? 0 : 2);
        }
        float frameS = Portal.outBack(Portal.k(tick, this.timing.ignite - 12, this.timing.ignite)) * keep;
        float edgeS = Portal.outBack(Portal.k(tick, this.timing.ignite, this.timing.ignite + 10)) * keep;
        float coreS = Portal.outBack(Portal.k(tick, this.timing.ignite + 5, this.timing.ignite + 16)) * keep;
        boolean bl = coreAnimating = tick >= this.timing.ignite - 12 && tick <= this.timing.ignite + 16 || closing || tick == 0;
        if (tick == this.timing.ignite - 12) {
            this.world.playSound(this.at, "block.grindstone.use", 1.0f, 0.6f);
        }
        if (coreAnimating || tick > this.timing.ignite + 16 && tick % 4 == 0) {
            float pulse = 1.0f + 0.03f * (float)Math.sin((double)tick * 0.25);
            float cs = Math.max(0.001f, coreS * pulse);
            float es = Math.max(0.001f, edgeS * pulse);
            float fs = Math.max(0.001f, frameS);
            int ri = coreAnimating ? 2 : 4;
            for (int i = 0; i < 24; ++i) {
                float a = (float)((double)i * 1.5707963267948966 / 24.0);
                float z = (float)i * 5.0E-4f;
                Puppet.apply((Display)this.core.get(i), new Matrix4f((Matrix4fc)this.face).scale(cs).rotateZ(a).translate(-1.45f, -1.45f, z).scale(2.9f, 2.9f, 0.03f), ri);
                Puppet.apply((Display)this.edge.get(i), new Matrix4f((Matrix4fc)this.face).scale(es).rotateZ(a).translate(-1.62f, -1.62f, 0.06f + z).scale(3.24f, 3.24f, 0.03f), ri);
                Puppet.apply((Display)this.deep.get(i), new Matrix4f((Matrix4fc)this.face).scale(es).rotateZ(a).translate(-1.82f, -1.82f, 0.12f + z).scale(3.64f, 3.64f, 0.03f), ri);
                Puppet.apply((Display)this.frame.get(i), new Matrix4f((Matrix4fc)this.face).scale(fs).rotateZ(a).translate(-2.05f, -2.05f, 0.18f + z).scale(4.1f, 4.1f, 0.03f), ri);
            }
        }
        boolean bl2 = dialLighting = tick >= this.timing.ignite && tick <= this.timing.ignite + 2 + 12 + 4;
        if (dialLighting || closing || tick == 0 || tick > this.timing.ignite && tick % 4 == 0) {
            float fs = Math.max(0.001f, frameS);
            for (int i = 0; i < 12; ++i) {
                int start = this.timing.ignite + 2 + i;
                if (tick == start) {
                    this.world.playSound(this.at, "block.amethyst_block.chime", 0.7f, 0.9f + (float)i * 0.08f);
                }
                float ns = Math.max(0.001f, Portal.outBack(Portal.k(tick, start, start + 4)));
                float a = (float)((double)i * Math.PI * 2.0 / 12.0) + (float)tick * 0.01f;
                Puppet.apply((Display)this.notches.get(i), new Matrix4f((Matrix4fc)this.face).scale(fs).rotateZ(a).translate(1.85f, 0.0f, 0.1f).scale(ns).translate(-0.13f, -0.035f, 0.0f).scale(0.26f, 0.07f, 0.02f), dialLighting ? 2 : 4);
            }
        }
        return impacts;
    }

    private Vector3f assemblyPos(Stone st, float asm) {
        Vector3f lift = new Vector3f((Vector3fc)st.groundPos).add(0.0f, 2.2f, 0.0f);
        if (asm < 0.3f) {
            return new Vector3f((Vector3fc)st.groundPos).lerp((Vector3fc)lift, Portal.smooth(asm / 0.3f));
        }
        float e = (asm - 0.3f) / 0.7f;
        float rs = (float)Math.hypot(lift.x, lift.y);
        float as = (float)Math.atan2(lift.y, lift.x);
        float rf = (float)Math.hypot(st.finalPos.x, st.finalPos.y);
        float af = (float)Math.atan2(st.finalPos.y, st.finalPos.x);
        float a = af + (as - af) * (1.0f - Portal.smooth(e)) + (1.0f - Portal.smooth(e)) * (float)Math.PI;
        float rad = rs + (rf - rs) * Portal.outBack(e);
        return new Vector3f((float)Math.cos(a) * rad, (float)Math.sin(a) * rad, lift.z + (st.finalPos.z - lift.z) * Portal.smooth(e));
    }

    private void lockIn(Stone st, Location w) {
        float pitch = 0.6f + (float)st.order * 0.08f;
        this.world.playSound(w, "block.respawn_anchor.charge", 1.0f, pitch);
        this.world.playSound(w, "block.end_portal_frame.fill", 1.0f, pitch);
        this.world.playSound(w, "block.deepslate.place", 0.8f, 0.7f);
        Fx.get(Fx.Slot.STONE_LOCK).spawn(w, 36, 0.3, 0.45, 0.22, 0.06);
    }

    private void trail(Stone st, Vector3f pos) {
        Fx.get(Fx.Slot.STONE_TRAIL).spawn(this.toWorld(pos), 6, 0.22, 0.22, 0.22, 0.015);
    }

    private void impact(Location g) {
        Fx.get(Fx.Slot.STONE_IMPACT).spawn(g, 63, 0.55, 0.15, 0.55, 0.1);
        for (int i = 0; i < 14; ++i) {
            double a = (double)i * Math.PI * 2.0 / 14.0;
            Fx.get(Fx.Slot.STONE_IMPACT_RING).spawn(g.clone().add(Math.cos(a) * 0.5, 0.1, Math.sin(a) * 0.5), 0, Math.cos(a), 0.02, Math.sin(a), 0.25);
        }
        this.world.playSound(g, "entity.generic.explode", 0.7f, 1.3f);
        this.world.playSound(g, "block.anvil.land", 0.35f, 0.5f);
        this.world.playSound(g, "block.deepslate.place", 1.0f, 0.6f);
    }

    Location toWorld(Vector3f local) {
        Vector3f v = this.face.transformPosition(new Vector3f((Vector3fc)local));
        return this.at.clone().add((double)v.x, (double)v.y, (double)v.z);
    }

    void remove() {
        this.all.forEach(Entity::remove);
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0f, Math.max(0.0f, (t - a) / (b - a)));
    }

    private static float smooth(float x) {
        return x * x * (3.0f - 2.0f * x);
    }

    private static float outBack(float x) {
        if (x <= 0.0f) {
            return 0.0f;
        }
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        return 1.0f + c3 * (float)Math.pow(x - 1.0f, 3.0) + c1 * (float)Math.pow(x - 1.0f, 2.0);
    }

    record Timing(int fallStart, int drawStart, int assembleStart, int stepsStart, int ignite) {
    }

    private static final class Stone {
        final List<Piece> pieces = new ArrayList<Piece>();
        Vector3f finalPos;
        Vector3f groundPos;
        Vector3f skyPos;
        Quaternionf finalRot;
        Quaternionf groundRot;
        Quaternionf skyRot;
        int fallStart;
        int assembleStart;
        int order;
        float phase;
        boolean falling;
        boolean landed;
        boolean lifted;
        boolean locked;

        private Stone() {
        }
    }

    private record Piece(BlockDisplay d, Matrix4f local, Vector3f runePivot) {
    }

    private record Step(BlockDisplay d, Matrix4f local) {
    }

    private record Deco(BlockDisplay d, Matrix4f local, Vector3f pivot, int start, int dur, boolean swing, String sound, float pitch) {
    }
}

