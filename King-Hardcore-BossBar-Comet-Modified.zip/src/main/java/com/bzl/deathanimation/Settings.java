/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.minimessage.MiniMessage
 *  net.kyori.adventure.text.minimessage.tag.resolver.Placeholder
 *  net.kyori.adventure.text.minimessage.tag.resolver.TagResolver
 *  org.bukkit.GameMode
 *  org.bukkit.configuration.Configuration
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Sfx;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.GameMode;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

final class Settings {
    final boolean enabled;
    final boolean totemSaves;
    final Set<String> skipCauses = new HashSet<String>();
    final Set<String> disabledWorlds = new HashSet<String>();
    final String exemptPermission;
    final double portalDistance;
    final double portalHeight;
    final String body;
    final String nebulaWorld;
    final String returnTo;
    final int durationMinutes;
    final GameMode nebulaMode;
    final boolean ambientParticles;
    final boolean ambientSounds;
    final boolean healOnArrival;
    final boolean blockTeleport;
    final boolean blockCommands;
    final Set<String> allowedCommands = new HashSet<String>();
    final boolean arrivalCinematic;
    final boolean releaseCinematic;
    final int titleFadeIn;
    final int titleStay;
    final int titleFadeOut;
    final boolean music;
    final boolean wings;
    final boolean lookAround;
    final boolean screenShake;
    final boolean heartbeat;
    final boolean breathing;
    final double particleAmount;
    final int particleViewDistance;
    final Map<Fx.Slot, Fx> particles = new EnumMap<Fx.Slot, Fx>(Fx.Slot.class);
    private final YamlConfiguration messages;

    Settings(BzlDeathAnimation plugin) {
        GameMode mode;
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration c = plugin.getConfig();
        this.enabled = c.getBoolean("death-animation.enabled", true);
        this.totemSaves = c.getBoolean("death-animation.totem-saves-player", true);
        for (String s : c.getStringList("death-animation.skip-causes")) {
            this.skipCauses.add(s.toUpperCase(Locale.ROOT));
        }
        this.portalDistance = c.getDouble("death-animation.portal-distance", 4.5);
        this.portalHeight = c.getDouble("death-animation.portal-height", 2.5);
        this.body = c.getString("death-animation.body", "auto").toLowerCase(Locale.ROOT);
        for (String w : c.getStringList("death-animation.disabled-worlds")) {
            this.disabledWorlds.add(w.toLowerCase(Locale.ROOT));
        }
        this.exemptPermission = c.getString("death-animation.exempt-permission", "bda.exempt");
        this.nebulaWorld = c.getString("nebula.world", "nebula");
        this.durationMinutes = Math.max(1, c.getInt("nebula.duration-minutes", 10));
        this.returnTo = c.getString("nebula.return-to", "death").toLowerCase(Locale.ROOT);
        try {
            mode = GameMode.valueOf((String)c.getString("nebula.gamemode", "ADVENTURE").toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException e) {
            mode = GameMode.ADVENTURE;
        }
        this.nebulaMode = mode == GameMode.SPECTATOR ? GameMode.ADVENTURE : mode;
        this.ambientParticles = c.getBoolean("nebula.ambient-particles", true);
        this.ambientSounds = c.getBoolean("nebula.ambient-sounds", true);
        this.healOnArrival = c.getBoolean("nebula.heal-on-arrival", true);
        this.blockTeleport = c.getBoolean("nebula.block-teleport-out", true);
        this.blockCommands = c.getBoolean("nebula.block-commands", true);
        for (String cmd : c.getStringList("nebula.allowed-commands")) {
            this.allowedCommands.add(cmd.toLowerCase(Locale.ROOT).replaceFirst("^/", ""));
        }
        this.arrivalCinematic = c.getBoolean("nebula.arrival-cinematic", true);
        this.releaseCinematic = c.getBoolean("nebula.release-cinematic", true);
        this.titleFadeIn = Math.max(0, c.getInt("nebula.title.fade-in-ticks", 6));
        this.titleStay = Math.max(0, c.getInt("nebula.title.stay-ticks", 60));
        this.titleFadeOut = Math.max(0, c.getInt("nebula.title.fade-out-ticks", 20));
        this.music = c.getBoolean("effects.music", true);
        this.wings = c.getBoolean("effects.wings", true);
        this.lookAround = c.getBoolean("effects.look-around", true);
        this.screenShake = c.getBoolean("effects.screen-shake", true);
        this.heartbeat = c.getBoolean("effects.heartbeat", true);
        this.breathing = c.getBoolean("effects.breathing", true);
        Sfx.heartbeatOn = this.heartbeat;
        Sfx.breathingOn = this.breathing;
        this.particleAmount = Math.max(0.0, c.getDouble("particles.amount-multiplier", 1.0));
        this.particleViewDistance = Math.max(8, c.getInt("particles.view-distance", 48));
        Fx.resetWarnings();
        for (Fx.Slot slot : Fx.Slot.values()) {
            this.particles.put(slot, Fx.load((ConfigurationSection)c, slot, this.particleAmount, this.particleViewDistance));
        }
        Fx.install(this.particles);
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        this.messages = YamlConfiguration.loadConfiguration((File)file);
        InputStream bundled = plugin.getResource("messages.yml");
        if (bundled != null) {
            this.messages.setDefaults((Configuration)YamlConfiguration.loadConfiguration((Reader)new InputStreamReader(bundled, StandardCharsets.UTF_8)));
        }
    }

    boolean has(String key) {
        return !this.raw(key).isBlank();
    }

    private String raw(String key) {
        String value = this.messages.getString(key);
        return value == null ? "" : value;
    }

    Component msg(String key, TagResolver ... placeholders) {
        TagResolver all = TagResolver.resolver((TagResolver[])new TagResolver[]{TagResolver.resolver((TagResolver[])placeholders), Placeholder.parsed((String)"prefix", (String)this.raw("prefix"))});
        return MiniMessage.miniMessage().deserialize(this.raw(key), all);
    }
}

