/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  net.kyori.adventure.text.format.TextDecoration$State
 *  net.kyori.adventure.text.minimessage.MiniMessage
 *  org.bukkit.Bukkit
 *  org.bukkit.Color
 *  org.bukkit.FireworkEffect
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.Configuration
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.FireworkEffectMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.jetbrains.annotations.NotNull
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Settings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkEffectMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

abstract class Menu
implements InventoryHolder {
    static final int[] INNER = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    static final String NAME = "<#B8F1FF><bold>";
    static final String HINT = "<#7FE3FF>";
    static final String ON = "<#5CFF8A>";
    static final String OFF = "<#FF6B6B>";
    final BzlDeathAnimation plugin;
    final Player viewer;
    private final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<Integer, Consumer<InventoryClickEvent>>();
    private Inventory inventory;

    Menu(BzlDeathAnimation plugin, Player viewer) {
        this.plugin = plugin;
        this.viewer = viewer;
    }

    abstract Component title();

    abstract void draw();

    int rows() {
        return 6;
    }

    boolean live() {
        return false;
    }

    @NotNull
    public Inventory getInventory() {
        return this.inventory;
    }

    final void open() {
        this.inventory = Bukkit.createInventory((InventoryHolder)this, (int)(this.rows() * 9), (Component)this.title());
        this.redraw();
        this.viewer.openInventory(this.inventory);
    }

    final void redraw() {
        this.actions.clear();
        this.inventory.clear();
        this.frame();
        this.draw();
    }

    final void go(Menu next) {
        this.sound("item.book.page_turn", 1.2f);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, next::open);
    }

    final void later(Runnable r) {
        Bukkit.getScheduler().runTask((Plugin)this.plugin, r);
    }

    private void frame() {
        int last = this.rows() - 1;
        ItemStack border = Menu.pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack accent = Menu.pane(Material.LIGHT_BLUE_STAINED_GLASS_PANE);
        ItemStack corner = Menu.pane(Material.CYAN_STAINED_GLASS_PANE);
        for (int i = 0; i < this.rows() * 9; ++i) {
            boolean hRow;
            int r = i / 9;
            int c = i % 9;
            boolean bl = hRow = r == 0 || r == last;
            if (!hRow && c != 0 && c != 8) continue;
            this.inventory.setItem(i, hRow && (c == 0 || c == 8) ? corner : (hRow && (c == 1 || c == 7) ? accent : border));
        }
    }

    final void set(int slot, ItemStack item, Consumer<InventoryClickEvent> action) {
        this.inventory.setItem(slot, item);
        if (action != null) {
            this.actions.put(slot, action);
        } else {
            this.actions.remove(slot);
        }
    }

    final void set(int slot, ItemStack item) {
        this.set(slot, item, null);
    }

    final void header(Material icon, String name, String ... desc) {
        this.set(4, Menu.glow(Menu.item(icon, NAME + name, Menu.gray(desc)), true));
    }

    final void back(int slot, Supplier<Menu> to) {
        this.set(slot, Menu.item(Material.ARROW, "<#7FE3FF><bold>\u00ab Kembali", new String[0]), e -> this.go((Menu)to.get()));
    }

    final void link(int slot, Material icon, String name, String permission, Supplier<Menu> to, String ... desc) {
        List<String> lore = Menu.gray(desc);
        lore.add("");
        lore.add((String)(this.viewer.hasPermission(permission) ? "<#7FE3FF>\u00bb <gray>Klik untuk membuka" : "<#FF6B6B>\u2716 Butuh izin <white>" + permission));
        this.set(slot, Menu.item(icon, NAME + name, lore), e -> {
            if (this.can(permission)) {
                this.go((Menu)to.get());
            }
        });
    }

    final void button(int slot, ItemStack icon, String permission, Consumer<InventoryClickEvent> action) {
        if (!this.viewer.hasPermission(permission)) {
            ItemMeta meta = icon.getItemMeta();
            ArrayList<Component> lore = meta.lore() == null ? new ArrayList<Component>() : new ArrayList(meta.lore());
            lore.add(Menu.mm("<#FF6B6B>\u2716 Butuh izin <white>" + permission));
            meta.lore(lore);
            icon.setItemMeta(meta);
        }
        this.set(slot, icon, e -> {
            if (this.can(permission)) {
                action.accept((InventoryClickEvent)e);
            }
        });
    }

    final void toggle(int slot, Material icon, String name, String path, boolean value, String ... desc) {
        List<String> lore = Menu.gray(desc);
        lore.add("");
        lore.add("<dark_gray>Status: " + (value ? "<#5CFF8A>\u25cf AKTIF" : "<#FF6B6B>\u25cf NONAKTIF"));
        lore.add("");
        lore.add("<#7FE3FF>\u00bb <gray>Klik untuk " + (value ? "mematikan" : "menyalakan"));
        this.set(slot, Menu.glow(Menu.item(icon, (value ? ON : OFF) + "<bold>" + name, lore), value), e -> {
            if (!this.can("bda.menu.edit")) {
                return;
            }
            this.save(path, !value);
            this.sound("block.note_block.pling", value ? 0.7f : 1.6f);
        });
    }

    final void number(int slot, Material icon, String name, String path, double value, double step, double big, double min, double max, boolean whole, String unit, String ... desc) {
        List<String> lore = Menu.gray(desc);
        lore.add("");
        lore.add("<gray>Nilai: <white><bold>" + Fx.num(value) + "</bold>" + unit + " <dark_gray>(" + Fx.num(min) + " - " + Fx.num(max) + ")");
        lore.add("");
        lore.add("<#7FE3FF>Klik kiri <gray>\u00bb +" + Fx.num(step) + "   <#7FE3FF>Klik kanan <gray>\u00bb -" + Fx.num(step));
        lore.add("<#7FE3FF>Shift + klik <gray>\u00bb \u00b1" + Fx.num(big));
        this.set(slot, Menu.item(icon, NAME + name, lore), e -> {
            if (!this.can("bda.menu.edit")) {
                return;
            }
            double d = (e.isShiftClick() ? big : step) * (double)(e.isRightClick() ? -1 : 1);
            double v = Math.max(min, Math.min(max, (double)Math.round((value + d) * 100.0) / 100.0));
            if (v == value) {
                this.sound("block.note_block.bass", 0.6f);
                return;
            }
            this.save(path, whole ? (Number)((int)Math.round(v)) : (Number)v);
            this.sound("block.note_block.hat", e.isRightClick() ? 0.8f : 1.4f);
        });
    }

    final void cycle(int slot, Material icon, String name, String path, String current, List<String> options, List<String> labels, String ... desc) {
        List<String> lore = Menu.gray(desc);
        lore.add("");
        int at = Math.max(0, options.indexOf(current));
        for (int i = 0; i < options.size(); ++i) {
            lore.add(i == at ? "<#5CFF8A>\u25b6 <white>" + labels.get(i) : "<dark_gray>  " + labels.get(i));
        }
        lore.add("");
        lore.add("<#7FE3FF>Klik kiri <gray>\u00bb berikutnya   <#7FE3FF>Klik kanan <gray>\u00bb sebelumnya");
        this.set(slot, Menu.item(icon, NAME + name, lore), e -> {
            if (!this.can("bda.menu.edit")) {
                return;
            }
            int n = options.size();
            this.save(path, options.get(Math.floorMod(at + (e.isRightClick() ? -1 : 1), n)));
            this.sound("block.note_block.hat", 1.2f);
        });
    }

    final void save(String path, Object value) {
        this.plugin.getConfig().set(path, value);
        this.plugin.saveConfig();
        this.plugin.settings = new Settings(this.plugin);
        this.redraw();
    }

    final void restore(String path) {
        Object object;
        Object def;
        Configuration defaults = this.plugin.getConfig().getDefaults();
        Object object2 = def = defaults == null ? null : defaults.get(path);
        if (def instanceof ConfigurationSection) {
            ConfigurationSection s = (ConfigurationSection)def;
            object = s.getValues(false);
        } else {
            object = def;
        }
        this.save(path, object);
    }

    final boolean can(String permission) {
        if (this.viewer.hasPermission(permission)) {
            return true;
        }
        this.plugin.tell((CommandSender)this.viewer, "command.no-permission", new String[0]);
        this.sound("entity.villager.no", 1.0f);
        return false;
    }

    final void sound(String key, float pitch) {
        this.viewer.playSound((Entity)this.viewer, key, 0.6f, pitch);
    }

    static Component mm(String text) {
        return MiniMessage.miniMessage().deserialize((Object)text).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    static String esc(String text) {
        return MiniMessage.miniMessage().escapeTags(text);
    }

    static List<String> gray(String ... lines) {
        ArrayList<String> out = new ArrayList<String>();
        for (String l : lines) {
            out.add("<gray>" + l);
        }
        return out;
    }

    static ItemStack item(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Menu.mm(name));
        ArrayList<Component> lines = new ArrayList<Component>();
        for (String l : lore) {
            lines.add(Menu.mm(l));
        }
        meta.lore(lines);
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    static ItemStack item(Material material, String name, String ... lore) {
        return Menu.item(material, name, List.of(lore));
    }

    static ItemStack glow(ItemStack item, boolean on) {
        ItemMeta meta = item.getItemMeta();
        meta.setEnchantmentGlintOverride(Boolean.valueOf(on));
        item.setItemMeta(meta);
        return item;
    }

    static ItemStack swatch(Color color, String name, List<String> lore) {
        ItemStack item = Menu.item(Material.FIREWORK_STAR, name, lore);
        FireworkEffectMeta meta = (FireworkEffectMeta)item.getItemMeta();
        meta.setEffect(FireworkEffect.builder().withColor(color).build());
        item.setItemMeta((ItemMeta)meta);
        return item;
    }

    private static ItemStack pane(Material m) {
        ItemStack item = new ItemStack(m);
        ItemMeta meta = item.getItemMeta();
        meta.displayName((Component)Component.empty());
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    static void start(BzlDeathAnimation plugin) {
        Bukkit.getPluginManager().registerEvents((Listener)new Events(), (Plugin)plugin);
        Bukkit.getScheduler().runTaskTimer((Plugin)plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                Menu m;
                InventoryHolder patt0$temp = p.getOpenInventory().getTopInventory().getHolder(false);
                if (!(patt0$temp instanceof Menu) || !(m = (Menu)patt0$temp).live()) continue;
                m.redraw();
            }
        }, 20L, 20L);
    }

    static void closeAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!(p.getOpenInventory().getTopInventory().getHolder(false) instanceof Menu)) continue;
            p.closeInventory();
        }
    }

    private static final class Events
    implements Listener {
        private Events() {
        }

        @EventHandler(ignoreCancelled=true)
        public void onClick(InventoryClickEvent e) {
            Inventory top = e.getView().getTopInventory();
            InventoryHolder inventoryHolder = top.getHolder(false);
            if (!(inventoryHolder instanceof Menu)) {
                return;
            }
            Menu menu = (Menu)inventoryHolder;
            e.setCancelled(true);
            if (e.getClickedInventory() != top || e.getClick() == ClickType.DOUBLE_CLICK || !e.getWhoClicked().equals((Object)menu.viewer)) {
                return;
            }
            Consumer<InventoryClickEvent> action = menu.actions.get(e.getRawSlot());
            if (action == null) {
                return;
            }
            menu.sound("ui.button.click", 1.5f);
            action.accept(e);
        }

        @EventHandler(ignoreCancelled=true)
        public void onDrag(InventoryDragEvent e) {
            if (e.getView().getTopInventory().getHolder(false) instanceof Menu) {
                e.setCancelled(true);
            }
        }
    }
}

