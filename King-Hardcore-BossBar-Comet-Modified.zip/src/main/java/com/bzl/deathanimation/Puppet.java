/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.BlockDisplay
 *  org.bukkit.entity.Display
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.ItemDisplay
 *  org.bukkit.entity.ItemDisplay$ItemDisplayTransform
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.util.Transformation
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionf
 *  org.joml.Vector3f
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Body;
import java.awt.image.BufferedImage;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.util.Transformation;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Vector3f;

final class Puppet
implements Body {
    private static final float HEAD_Y_FIX = 0.25f;
    private static final float HEAD_YAW_FIX = 0.0f;
    private final BlockDisplay torso;
    private final BlockDisplay armL;
    private final BlockDisplay armR;
    private final BlockDisplay legL;
    private final BlockDisplay legR;
    private final ItemDisplay head;
    private final List<Display> parts;
    private final float yawRad;
    private boolean removed;

    @Override
    public void pose(Body.Stage stage, float progress, float[] p, double ox, double oy, double oz, float scale) {
        if (stage == Body.Stage.LOOK) {
            this.pose(ox, oy, oz, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, p[5], scale, 2);
            return;
        }
        this.pose(ox, oy + (double)p[6], oz, p[0], p[1], p[2], p[3], p[4], p[5], scale, 2);
    }

    Puppet(Location feet, float yaw, Player owner, Colors colors) {
        Location at = feet.clone();
        at.setYaw(0.0f);
        at.setPitch(0.0f);
        this.yawRad = (float)(-Math.toRadians(yaw));
        this.torso = Puppet.block(at, colors.torso);
        this.armL = Puppet.block(at, colors.arms);
        this.armR = Puppet.block(at, colors.arms);
        this.legL = Puppet.block(at, colors.legs);
        this.legR = Puppet.block(at, colors.legs);
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta)skull.getItemMeta();
        meta.setPlayerProfile(owner.getPlayerProfile());
        skull.setItemMeta((ItemMeta)meta);
        this.head = (ItemDisplay)at.getWorld().spawn(at, ItemDisplay.class, d -> {
            d.setPersistent(false);
            d.addScoreboardTag("bda_fx");
            d.setItemStack(skull);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
        });
        this.parts = List.of(this.torso, this.armL, this.armR, this.legL, this.legR, this.head);
        this.pose(0.0, 0.0, 0.0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0);
    }

    private static BlockDisplay block(Location at, Material m) {
        return (BlockDisplay)at.getWorld().spawn(at, BlockDisplay.class, d -> {
            d.setPersistent(false);
            d.addScoreboardTag("bda_fx");
            d.setBlock(m.createBlockData());
        });
    }

    void pose(double ox, double oy, double oz, float lean, float armBack, float spread, float legLeft, float legRight, float headPitch, float scale, int interp) {
        if (this.removed) {
            return;
        }
        Matrix4f base = new Matrix4f().translate((float)ox, (float)oy, (float)oz).rotateY(this.yawRad).rotateX(Puppet.rad(lean)).scale(Math.max(scale, 0.001f));
        Puppet.apply((Display)this.torso, new Matrix4f((Matrix4fc)base).translate(-0.25f, 0.75f, -0.125f).scale(0.5f, 0.75f, 0.25f), interp);
        Puppet.apply((Display)this.armL, Puppet.limb(base, 0.375f, 1.5f, armBack, spread), interp);
        Puppet.apply((Display)this.armR, Puppet.limb(base, -0.375f, 1.5f, armBack, -spread), interp);
        Puppet.apply((Display)this.legL, Puppet.limb(base, 0.125f, 0.75f, legLeft, 0.0f), interp);
        Puppet.apply((Display)this.legR, Puppet.limb(base, -0.125f, 0.75f, legRight, 0.0f), interp);
        Puppet.apply((Display)this.head, new Matrix4f((Matrix4fc)base).translate(0.0f, 1.5f, 0.0f).rotateX(Puppet.rad(headPitch)).translate(0.0f, 0.5f, 0.0f).rotateY(Puppet.rad(0.0f)), interp);
    }

    private static Matrix4f limb(Matrix4f base, float x, float y, float swing, float spread) {
        return new Matrix4f((Matrix4fc)base).translate(x, y, 0.0f).rotateX(Puppet.rad(swing)).rotateZ(Puppet.rad(spread)).translate(-0.125f, -0.75f, -0.125f).scale(0.25f, 0.75f, 0.25f);
    }

    static void apply(Display d, Matrix4f m, int interp) {
        Transformation t = new Transformation(m.getTranslation(new Vector3f()), m.getUnnormalizedRotation(new Quaternionf()), m.getScale(new Vector3f()), new Quaternionf());
        if (d.getInterpolationDuration() == interp && t.equals((Object)d.getTransformation())) {
            return;
        }
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(interp);
        d.setTransformation(t);
    }

    static float rad(float deg) {
        return (float)Math.toRadians(deg);
    }

    @Override
    public boolean ready() {
        return this.parts.stream().allMatch(Entity::isValid);
    }

    @Override
    public void remove() {
        this.removed = true;
        this.parts.forEach(Entity::remove);
    }

    record Colors(Material torso, Material arms, Material legs) {
        static final Colors DEFAULT = new Colors(Material.CYAN_CONCRETE, Material.TERRACOTTA, Material.BLUE_TERRACOTTA);
        private static final Object[][] PALETTE = new Object[][]{{Material.WHITE_CONCRETE, 13620694}, {Material.ORANGE_CONCRETE, 14704897}, {Material.MAGENTA_CONCRETE, 11088031}, {Material.LIGHT_BLUE_CONCRETE, 2394567}, {Material.YELLOW_CONCRETE, 15838997}, {Material.LIME_CONCRETE, 6203672}, {Material.PINK_CONCRETE, 14050703}, {Material.GRAY_CONCRETE, 3619390}, {Material.LIGHT_GRAY_CONCRETE, 0x7D7D73}, {Material.CYAN_CONCRETE, 1406856}, {Material.PURPLE_CONCRETE, 6561948}, {Material.BLUE_CONCRETE, 2961295}, {Material.BROWN_CONCRETE, 6306848}, {Material.GREEN_CONCRETE, 4807460}, {Material.RED_CONCRETE, 9314593}, {Material.BLACK_CONCRETE, 526863}, {Material.WHITE_TERRACOTTA, 13808289}, {Material.ORANGE_TERRACOTTA, 10638374}, {Material.MAGENTA_TERRACOTTA, 9853037}, {Material.LIGHT_BLUE_TERRACOTTA, 7433610}, {Material.YELLOW_TERRACOTTA, 12223779}, {Material.LIME_TERRACOTTA, 6846005}, {Material.PINK_TERRACOTTA, 10636879}, {Material.GRAY_TERRACOTTA, 3811876}, {Material.LIGHT_GRAY_TERRACOTTA, 8874850}, {Material.CYAN_TERRACOTTA, 0x575B5B}, {Material.PURPLE_TERRACOTTA, 7751254}, {Material.BLUE_TERRACOTTA, 4865115}, {Material.BROWN_TERRACOTTA, 5059364}, {Material.GREEN_TERRACOTTA, 5002026}, {Material.RED_TERRACOTTA, 9387311}, {Material.BLACK_TERRACOTTA, 2430736}, {Material.TERRACOTTA, 9985604}, {Material.SMOOTH_SANDSTONE, 14207899}, {Material.OAK_PLANKS, 10650190}, {Material.BIRCH_PLANKS, 12627833}};

        static Colors from(BufferedImage img, boolean slim) {
            boolean modern = img.getHeight() >= 64;
            return new Colors(Colors.nearest(Colors.average(img, 20, 20, 8, 12, modern)), Colors.nearest(Colors.average(img, 44, 20, slim ? 3 : 4, 12, modern)), Colors.nearest(Colors.average(img, 4, 20, 4, 12, modern)));
        }

        private static int average(BufferedImage img, int x0, int y0, int w, int h, boolean overlay) {
            long r = 0L;
            long g = 0L;
            long b = 0L;
            long n = 0L;
            for (int y = y0; y < y0 + h; ++y) {
                for (int x = x0; x < x0 + w; ++x) {
                    int top;
                    int px = img.getRGB(x, y);
                    if (overlay && (top = img.getRGB(x, y + 16)) >>> 24 > 128) {
                        px = top;
                    }
                    if (px >>> 24 < 128) continue;
                    r += (long)(px >> 16 & 0xFF);
                    g += (long)(px >> 8 & 0xFF);
                    b += (long)(px & 0xFF);
                    ++n;
                }
            }
            if (n == 0L) {
                return 9985604;
            }
            return (int)(r / n) << 16 | (int)(g / n) << 8 | (int)(b / n);
        }

        private static Material nearest(int rgb) {
            Material best = Material.TERRACOTTA;
            long bestD = Long.MAX_VALUE;
            for (Object[] e : PALETTE) {
                long db;
                long dg;
                int c = (Integer)e[1];
                long dr = (rgb >> 16 & 0xFF) - (c >> 16 & 0xFF);
                long d = 2L * dr * dr + 4L * (dg = (long)((rgb >> 8 & 0xFF) - (c >> 8 & 0xFF))) * dg + 3L * (db = (long)((rgb & 0xFF) - (c & 0xFF))) * db;
                if (d >= bestD) continue;
                bestD = d;
                best = (Material)e[0];
            }
            return best;
        }
    }
}

