/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.minimessage.tag.resolver.Placeholder
 *  net.kyori.adventure.text.minimessage.tag.resolver.TagResolver
 *  net.kyori.adventure.title.Title
 *  net.kyori.adventure.title.Title$Times
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.World
 *  org.bukkit.World$Environment
 *  org.bukkit.WorldCreator
 *  org.bukkit.block.Biome
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.CreatureSpawnEvent
 *  org.bukkit.event.entity.CreatureSpawnEvent$SpawnReason
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.generator.BiomeProvider
 *  org.bukkit.generator.ChunkGenerator
 *  org.bukkit.generator.WorldInfo
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Descent;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Release;
import com.bzl.deathanimation.Sequence;
import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

final class Nebula
implements Listener {
    private static final int IX = 5000;
    private static final int IY = 80;
    private static final int IZ = 5000;
    private static final int FALL_LIMIT = 48;
    private static final String[] AMBIENCE = new String[]{"ambient.cave", "ambient.soul_sand_valley.additions", "block.amethyst_block.chime", "ambient.warped_forest.additions", "block.beacon.ambient"};
    private final BzlDeathAnimation plugin;
    private final NamespacedKey untilKey;
    private final NamespacedKey returnKey;
    private final NamespacedKey modeKey;
    private final Map<UUID, Release> releases = new HashMap<UUID, Release>();
    private final Map<UUID, BossBar> countdownBars = new HashMap<UUID, BossBar>();
    private final Map<UUID, Sequence> arrivals = new HashMap<UUID, Sequence>();
    private World world;
    private static final int ISLAND_VERSION = 3;
    private static final double ISLAND_R = 16.3;
    private static final int CLEAR = 46;
    private static final Material[] FLOOR = new Material[]{Material.POLISHED_DEEPSLATE, Material.POLISHED_DEEPSLATE, Material.DEEPSLATE_TILES, Material.DEEPSLATE_TILES, Material.CRACKED_DEEPSLATE_TILES};
    private static final Material[] ROCK = new Material[]{Material.DEEPSLATE, Material.COBBLED_DEEPSLATE, Material.TUFF, Material.DEEPSLATE};

    Nebula(BzlDeathAnimation plugin) {
        this.plugin = plugin;
        this.untilKey = new NamespacedKey((Plugin)plugin, "nebula_until");
        this.returnKey = new NamespacedKey((Plugin)plugin, "nebula_return");
        this.modeKey = new NamespacedKey((Plugin)plugin, "nebula_mode");
    }

    void enable() {
        this.world = this.loadWorld();
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
        Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::everySecond, 20L, 20L);
    }

    boolean isNebula(World w) {
        return w.equals((Object)this.world);
    }

    boolean isTrapped(Player p) {
        return p.getPersistentDataContainer().has(this.untilKey, PersistentDataType.LONG);
    }

    Location spawn() {
        return new Location(this.world, 5000.5, 81.0, 5000.5, 180.0f, 0.0f);
    }

    private World loadWorld() {
        boolean fresh;
        String name = this.plugin.settings.nebulaWorld;
        World w = Bukkit.getWorld((String)name);
        boolean bl = fresh = w == null && !new File(Bukkit.getWorldContainer(), name).exists();
        if (w == null) {
            w = new WorldCreator(name).environment(World.Environment.THE_END).generator((ChunkGenerator)new VoidGenerator()).biomeProvider((BiomeProvider)new VoidBiomes()).generateStructures(false).createWorld();
        }
        w.setSpawnLocation(5000, 81, 5000);
        this.ensureIsland(w, fresh);
        return w;
    }

    private void ensureIsland(World w, boolean fresh) {
        NamespacedKey key = new NamespacedKey((Plugin)this.plugin, "island_version");
        Integer built = (Integer)w.getPersistentDataContainer().get(key, PersistentDataType.INTEGER);
        if (built != null && built >= 3) {
            return;
        }
        if (!fresh) {
            Nebula.clearIsland(w);
        }
        this.buildIsland(w);
        w.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, (Object)3);
    }

    private static void clearIsland(World w) {
        for (int dx = -46; dx <= 46; ++dx) {
            for (int dz = -46; dz <= 46; ++dz) {
                for (int dy = -32; dy <= 18; ++dy) {
                    Block b = w.getBlockAt(5000 + dx, 80 + dy, 5000 + dz);
                    if (b.getType().isAir()) continue;
                    b.setType(Material.AIR, false);
                }
            }
        }
    }

    Location landingSpot() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int tries = 0; tries < 12; ++tries) {
            int z;
            double a = r.nextDouble(Math.PI * 2);
            double rad = r.nextDouble(1.5, 5.5);
            int x = (int)Math.floor(Math.cos(a) * rad);
            Block floor = this.world.getBlockAt(5000 + x, 80, 5000 + (z = (int)Math.floor(Math.sin(a) * rad)));
            if (!floor.getType().isSolid() || !floor.getRelative(0, 1, 0).isPassable() || !floor.getRelative(0, 2, 0).isPassable()) continue;
            return new Location(this.world, (double)(5000 + x) + 0.5, 81.0, (double)(5000 + z) + 0.5, r.nextFloat() * 360.0f, 0.0f);
        }
        return this.spawn();
    }

    private void buildIsland(World w) {
        int i;
        int z;
        int x;
        int i2;
        Random r = new Random(7L);
        int[][] bottom = Nebula.disc(w, r, 0, 0, 0, 16.3, true);
        for (int[] o : new int[][]{{3, 0}, {-3, 0}, {0, 3}, {0, -3}}) {
            Nebula.set(w, o[0], 1, o[1], Material.END_ROD);
        }
        for (i2 = 0; i2 < 7; ++i2) {
            double a = (double)i2 * Math.PI * 2.0 / 7.0 + r.nextDouble() * 0.3;
            double rad = 9.0 + r.nextDouble() * 2.0;
            x = (int)Math.round(Math.cos(a) * rad);
            z = (int)Math.round(Math.sin(a) * rad);
            int h = 2 + r.nextInt(4);
            for (int y = 1; y <= h; ++y) {
                Nebula.set(w, x, y, z, y == h ? Material.CRACKED_DEEPSLATE_BRICKS : Material.DEEPSLATE_BRICKS);
            }
            Nebula.set(w, x, h + 1, z, h >= 4 ? Material.SEA_LANTERN : Material.AMETHYST_CLUSTER);
            Nebula.set(w, x + (r.nextBoolean() ? 1 : -1), 1, z, Material.COBBLED_DEEPSLATE);
        }
        for (i2 = 0; i2 < 8; ++i2) {
            double a = 0.39269908169872414 + (double)i2 * Math.PI / 4.0;
            int x2 = (int)Math.round(Math.cos(a) * 14.5);
            int z2 = (int)Math.round(Math.sin(a) * 14.5);
            Nebula.set(w, x2, 1, z2, Material.POLISHED_DEEPSLATE_WALL);
            Nebula.set(w, x2, 2, z2, Material.POLISHED_DEEPSLATE_WALL);
            Nebula.set(w, x2, 3, z2, Material.SOUL_LANTERN);
        }
        for (i2 = 0; i2 < 34; ++i2) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double rad = 4.0 + r.nextDouble() * 11.0;
            x = (int)Math.round(Math.cos(a) * rad);
            if (w.getBlockAt(5000 + x, 80, 5000 + (z = (int)Math.round(Math.sin(a) * rad))).getType().isAir() || !w.getBlockAt(5000 + x, 81, 5000 + z).getType().isAir()) continue;
            Nebula.set(w, x, 1, z, i2 % 3 == 0 ? Material.LARGE_AMETHYST_BUD : Material.AMETHYST_CLUSTER);
        }
        for (i2 = 0; i2 < 40; ++i2) {
            int z3;
            int x3 = r.nextInt(27) - 13;
            int b = bottom[x3 + 20][(z3 = r.nextInt(27) - 13) + 20];
            if (b == 0) continue;
            Nebula.stalactite(w, x3, b - 1, z3, 2 + r.nextInt(4));
        }
        String chain = Nebula.blockId("minecraft:iron_chain", "minecraft:chain");
        for (i = 0; i < 8; ++i) {
            int z4;
            double a = (double)i * Math.PI / 4.0;
            int x4 = (int)Math.round(Math.cos(a) * 12.0);
            int b = bottom[x4 + 20][(z4 = (int)Math.round(Math.sin(a) * 12.0)) + 20];
            if (b == 0) continue;
            int len = 2 + r.nextInt(3);
            for (int k = 1; k <= len; ++k) {
                Nebula.setData(w, x4, b - k, z4, chain);
            }
            Nebula.setData(w, x4, b - len - 1, z4, "minecraft:soul_lantern[hanging=true]");
        }
        for (i = 0; i < 6; ++i) {
            double a = (double)i * Math.PI / 3.0 + (r.nextDouble() - 0.5) * 0.5;
            double dist = 27.0 + r.nextDouble() * 6.0;
            int cx = (int)Math.round(Math.cos(a) * dist);
            int cz = (int)Math.round(Math.sin(a) * dist);
            int cy = r.nextInt(12) - 5;
            Nebula.disc(w, r, cx, cy, cz, 2.4 + r.nextDouble() * 1.4, false);
            Nebula.set(w, cx, cy + 1, cz, i % 2 == 0 ? Material.AMETHYST_CLUSTER : Material.END_ROD);
            Nebula.stalactite(w, cx, cy - 4, cz, 2 + r.nextInt(2));
        }
    }

    private static int[][] disc(World w, Random r, int ox, int oy, int oz, double radius, boolean main) {
        int[][] bottom = new int[41][41];
        int span = (int)Math.ceil(radius);
        for (int dx = -span; dx <= span; ++dx) {
            for (int dz = -span; dz <= span; ++dz) {
                boolean ring;
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > radius) continue;
                int top = 0;
                if (d > radius - 1.0 && r.nextDouble() < 0.3) {
                    top = -1;
                }
                boolean bl = ring = main && top == 0 && (d >= 6.6 && d <= 7.4 || d >= 12.6 && d <= 13.4);
                Material m = main && d < 1.6 ? Material.CHISELED_DEEPSLATE : (ring ? Material.SEA_LANTERN : FLOOR[r.nextInt(FLOOR.length)]);
                Nebula.set(w, ox + dx, oy + top, oz + dz, m);
                int depth = Math.min(12, (int)((radius - d) * 0.75)) + 1 + r.nextInt(2);
                for (int k = 1; k <= depth; ++k) {
                    Nebula.set(w, ox + dx, oy + top - k, oz + dz, ROCK[r.nextInt(ROCK.length)]);
                }
                if (Math.abs(dx) > 20 || Math.abs(dz) > 20) continue;
                bottom[dx + 20][dz + 20] = top - depth;
            }
        }
        return bottom;
    }

    private static void stalactite(World w, int x, int y, int z, int len) {
        for (int j = 0; j < len; ++j) {
            String t = j == len - 1 ? "tip" : (j == len - 2 ? "frustum" : (j == 0 ? "base" : "middle"));
            Nebula.setData(w, x, y - j, z, "minecraft:pointed_dripstone[thickness=" + t + ",vertical_direction=down]");
        }
    }

    private static void set(World w, int dx, int dy, int dz, Material m) {
        w.getBlockAt(5000 + dx, 80 + dy, 5000 + dz).setType(m, false);
    }

    private static void setData(World w, int dx, int dy, int dz, String data) {
        try {
            w.getBlockAt(5000 + dx, 80 + dy, 5000 + dz).setBlockData(Bukkit.createBlockData((String)data), false);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            // empty catch block
        }
    }

    private static String blockId(String ... ids) {
        for (String id : ids) {
            try {
                Bukkit.createBlockData((String)id);
                return id;
            }
            catch (IllegalArgumentException illegalArgumentException) {
            }
        }
        return ids[ids.length - 1];
    }

    void imprison(Player p, Location returnTo, boolean animate, GameMode realMode) {
        int minutes = this.plugin.settings.durationMinutes;
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        this.removeCountdownBar(p);
        pdc.set(this.untilKey, PersistentDataType.LONG, (Object)(System.currentTimeMillis() + (long)minutes * 60000L));
        pdc.set(this.returnKey, PersistentDataType.STRING, (Object)Nebula.serialize(returnTo));
        pdc.set(this.modeKey, PersistentDataType.STRING, (Object)(realMode == GameMode.SPECTATOR ? GameMode.SURVIVAL : realMode).name());
        if (this.plugin.settings.healOnArrival) {
            Nebula.heal(p);
        }
        Runnable welcome = () -> {
            if (!p.isOnline()) {
                return;
            }
            if (this.plugin.settings.has("nebula.title") || this.plugin.settings.has("nebula.subtitle")) {
                p.showTitle(Title.title((Component)this.msg("title", p, minutes), (Component)this.msg("subtitle", p, minutes), (Title.Times)Title.Times.times((Duration)Duration.ofMillis((long)this.plugin.settings.titleFadeIn * 50L), (Duration)Duration.ofMillis((long)this.plugin.settings.titleStay * 50L), (Duration)Duration.ofMillis((long)this.plugin.settings.titleFadeOut * 50L))));
            }
            p.playSound((Entity)p, "block.respawn_anchor.set_spawn", 1.0f, 1.2f);
        };
        if (animate && this.plugin.settings.arrivalCinematic) {
            p.playSound((Entity)p, "block.portal.travel", 0.6f, 1.4f);
            UUID id = p.getUniqueId();
            this.arrivals.put(id, Sequence.fromSky(this.plugin, p, this.landingSpot(), this.plugin.settings.nebulaMode, false, () -> {
                this.arrivals.remove(id);
                welcome.run();
            }));
        } else {
            if (!p.teleport(this.spawn()) || !this.isNebula(p.getWorld())) {
                p.getPersistentDataContainer().set(this.plugin.pendingKey, PersistentDataType.STRING, (Object)(this.plugin.settings.nebulaMode.name() + ";" + Nebula.serialize(this.spawn())));
            }
            p.setGameMode(this.plugin.settings.nebulaMode);
            welcome.run();
        }
        if (this.plugin.settings.has("nebula.broadcast")) {
            Bukkit.broadcast((Component)this.msg("broadcast", p, minutes));
        }
    }

    void release(Player p) {
        this.removeCountdownBar(p);
        Sequence arriving = this.arrivals.get(p.getUniqueId());
        if (arriving != null) {
            arriving.abort();
        }
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        Location back = this.returnLocation(p, (String)pdc.get(this.returnKey, PersistentDataType.STRING));
        GameMode mode = GameMode.SURVIVAL;
        try {
            String m = (String)pdc.get(this.modeKey, PersistentDataType.STRING);
            if (m != null) {
                mode = GameMode.valueOf((String)m);
            }
        }
        catch (IllegalArgumentException m) {
            // empty catch block
        }
        pdc.remove(this.untilKey);
        pdc.remove(this.returnKey);
        pdc.remove(this.modeKey);
        UUID id = p.getUniqueId();
        if (!this.isNebula(p.getWorld()) || !this.plugin.settings.releaseCinematic) {
            p.teleport(back);
            p.setGameMode(mode);
            p.stopSound("music.end");
            if (this.plugin.settings.has("nebula.released")) {
                p.sendMessage(this.msg("released", p, 0));
            }
            return;
        }
        if (this.releases.containsKey(id)) {
            return;
        }
        this.releases.put(id, new Release(this.plugin, p, back, mode, () -> {
            this.releases.remove(id);
            if (p.isOnline() && this.plugin.settings.has("nebula.released")) {
                p.sendMessage(this.msg("released", p, 0));
            }
        }));
    }

    List<Player> trapped() {
        ArrayList<Player> list = new ArrayList<Player>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!this.isTrapped(p)) continue;
            list.add(p);
        }
        list.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        return list;
    }

    long remaining(Player p) {
        Long until = (Long)p.getPersistentDataContainer().get(this.untilKey, PersistentDataType.LONG);
        return until == null ? 0L : Math.max(0L, until - System.currentTimeMillis());
    }

    void addTime(Player p, long millis) {
        Long until = (Long)p.getPersistentDataContainer().get(this.untilKey, PersistentDataType.LONG);
        if (until == null) {
            return;
        }
        p.getPersistentDataContainer().set(this.untilKey, PersistentDataType.LONG, (Object)Math.max(System.currentTimeMillis(), until + millis));
    }

    boolean busy(Player p) {
        return this.arrivals.containsKey(p.getUniqueId()) || this.releases.containsKey(p.getUniqueId());
    }

    void abortReleases() {
        new ArrayList<Release>(this.releases.values()).forEach(Release::abort);
        new ArrayList<Sequence>(this.arrivals.values()).forEach(Sequence::abort);
    }

    private void arrive(Player p) {
        UUID id = p.getUniqueId();
        if (this.arrivals.containsKey(id)) {
            return;
        }
        this.arrivals.put(id, new Descent(this.plugin, p, this.spawn(), this.plugin.settings.nebulaMode, () -> {
            this.arrivals.remove(id);
            if (p.isOnline()) {
                Fx.get(Fx.Slot.NEBULA_ARRIVE).spawn(p.getLocation().add(0.0, 1.0, 0.0), 40, 0.4, 0.8, 0.4, 0.12);
            }
        }));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Sequence d;
        this.removeCountdownBar(e.getPlayer());
        Release r = this.releases.get(e.getPlayer().getUniqueId());
        if (r != null) {
            r.abort();
        }
        if ((d = this.arrivals.get(e.getPlayer().getUniqueId())) != null) {
            d.abort();
        }
    }

    private Location returnLocation(Player p, String saved) {
        Location fallback;
        Location location = fallback = p.getRespawnLocation() != null ? p.getRespawnLocation() : ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
        if (!"death".equals(this.plugin.settings.returnTo)) {
            return fallback;
        }
        Location loc = Nebula.deserialize(saved);
        return loc != null && Nebula.isSafe(loc) ? loc : fallback;
    }

    private static boolean isSafe(Location loc) {
        Block feet = loc.getBlock();
        Block head = feet.getRelative(0, 1, 0);
        if (!feet.isPassable() || !head.isPassable()) {
            return false;
        }
        for (Block b : new Block[]{feet, head}) {
            Material m = b.getType();
            if (m != Material.LAVA && m != Material.FIRE && m != Material.SOUL_FIRE) continue;
            return false;
        }
        for (int i = 1; i <= 3; ++i) {
            Block below = feet.getRelative(0, -i, 0);
            if (below.getType() == Material.LAVA) {
                return false;
            }
            if (!below.getType().isSolid()) continue;
            return true;
        }
        return false;
    }

    private static void heal(Player p) {
        double max = p.getMaxHealth();
        p.setHealth(max);
        p.setFoodLevel(20);
        p.setFireTicks(0);
        p.setFallDistance(0.0f);
    }

    private void updateCountdownBar(Player player, long seconds, long millisLeft) {
        UUID id = player.getUniqueId();
        BossBar bar = this.countdownBars.get(id);
        if (bar == null) {
            bar = Bukkit.createBossBar("", BarColor.BLUE, BarStyle.SOLID);
            this.countdownBars.put(id, bar);
            bar.addPlayer(player);
        }
        long totalMillis = Math.max(60000L, (long)this.plugin.settings.durationMinutes * 60000L);
        double progress = Math.max(0.0D, Math.min(1.0D, (double)millisLeft / (double)totalMillis));
        bar.setProgress(progress);
        bar.setTitle("☄ Rebirth in " + String.format("%02d:%02d", seconds / 60L, seconds % 60L) + " ☄");
        if (!bar.getPlayers().contains(player)) bar.addPlayer(player);
    }

    private void removeCountdownBar(Player player) {
        BossBar bar = this.countdownBars.remove(player.getUniqueId());
        if (bar != null) bar.removePlayer(player);
    }

    private void everySecond() {
        long now = System.currentTimeMillis();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Long until = (Long)p.getPersistentDataContainer().get(this.untilKey, PersistentDataType.LONG);
            if (until == null) {
                this.removeCountdownBar(p);
                continue;
            }
            if (this.plugin.running.containsKey(p.getUniqueId())) continue;
            long left = until - now;
            if (left <= 0L) {
                this.release(p);
                continue;
            }
            if (!this.isNebula(p.getWorld())) {
                this.removeCountdownBar(p);
                if (p.hasPermission("bda.bypass.teleport")) continue;
                p.teleport(this.spawn());
                continue;
            }
            long s = (left + 999L) / 1000L;
            this.updateCountdownBar(p, s, left);
            if (this.plugin.settings.ambientSounds && r.nextInt(18) == 0) {
                String cue = AMBIENCE[r.nextInt(AMBIENCE.length)];
                p.playSound(p.getLocation().add(r.nextDouble(-12.0, 12.0), r.nextDouble(-6.0, 6.0), r.nextDouble(-12.0, 12.0)), cue, 0.7f, 0.7f + r.nextFloat() * 0.5f);
            }
            Location c = p.getLocation();
            for (int i = 0; this.plugin.settings.ambientParticles && i < 12; ++i) {
                Location at = c.clone().add(r.nextDouble(-14.0, 14.0), r.nextDouble(-6.0, 10.0), r.nextDouble(-14.0, 14.0));
                Fx.get(Fx.Slot.NEBULA_STARS).spawnFor(p, at, 1, 0.0, 0.0, 0.0, 0.005, 0.0);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onDamage(EntityDamageEvent e) {
        Player p;
        Entity entity = e.getEntity();
        if (!(entity instanceof Player && this.isNebula((p = (Player)entity).getWorld()) && this.isTrapped(p))) {
            return;
        }
        if (this.busy(p)) {
            e.setCancelled(true);
            return;
        }
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID || e.getFinalDamage() >= p.getHealth()) {
            e.setCancelled(true);
            Nebula.heal(p);
            this.arrive(p);
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onMove(PlayerMoveEvent e) {
        Player p;
        if (e.getTo().getY() < 48.0 && this.isNebula(e.getTo().getWorld()) && this.isTrapped(e.getPlayer()) && !this.arrivals.containsKey((p = e.getPlayer()).getUniqueId())) {
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.arrive(p));
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        if (!this.plugin.settings.blockTeleport || !this.isTrapped(p) || p.hasPermission("bda.bypass.teleport")) {
            return;
        }
        if (this.isNebula(e.getFrom().getWorld()) && !this.isNebula(e.getTo().getWorld())) {
            e.setCancelled(true);
            if (this.plugin.settings.has("nebula.blocked")) {
                p.sendMessage(this.msg("blocked", p, 0));
            }
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!this.plugin.settings.blockCommands || !this.isTrapped(p) || p.hasPermission("bda.bypass.commands")) {
            return;
        }
        String root = e.getMessage().substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        if (this.plugin.settings.allowedCommands.contains(root = root.substring(root.indexOf(58) + 1))) {
            return;
        }
        e.setCancelled(true);
        if (this.plugin.settings.has("nebula.command-blocked")) {
            p.sendMessage(this.msg("command-blocked", p, 0));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Long until = (Long)p.getPersistentDataContainer().get(this.untilKey, PersistentDataType.LONG);
        if (until == null) {
            return;
        }
        if (!this.isNebula(p.getWorld()) && until > System.currentTimeMillis() && !p.hasPermission("bda.bypass.teleport")) {
            p.teleport(this.spawn());
            p.setGameMode(this.plugin.settings.nebulaMode);
        }
        if (!this.plugin.settings.has("nebula.rejoin")) {
            return;
        }
        long s = Math.max(0L, (until - System.currentTimeMillis() + 999L) / 1000L);
        p.sendMessage(this.plugin.settings.msg("nebula.rejoin", new TagResolver[]{Placeholder.unparsed((String)"player", (String)p.getName()), Placeholder.unparsed((String)"time", (String)String.format("%02d:%02d", s / 60L, s % 60L))}));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (this.isTrapped(e.getPlayer())) {
            e.setRespawnLocation(this.spawn());
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void allowEffectBodies(CreatureSpawnEvent e) {
        if (e.getEntity().getScoreboardTags().contains("bda_fx")) {
            e.setCancelled(false);
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (e.getEntity().getScoreboardTags().contains("bda_fx")) {
            return;
        }
        CreatureSpawnEvent.SpawnReason why = e.getSpawnReason();
        if (this.isNebula(e.getLocation().getWorld()) && why != CreatureSpawnEvent.SpawnReason.CUSTOM && why != CreatureSpawnEvent.SpawnReason.COMMAND) {
            e.setCancelled(true);
        }
    }

    private Component msg(String key, Player p, int minutes) {
        return this.plugin.settings.msg("nebula." + key, new TagResolver[]{Placeholder.unparsed((String)"player", (String)p.getName()), Placeholder.unparsed((String)"minutes", (String)String.valueOf(minutes))});
    }

    static String serialize(Location l) {
        return l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch();
    }

    static Location deserialize(String s) {
        World w;
        if (s == null) {
            return null;
        }
        String[] a = s.split(";");
        World world = w = a.length == 6 ? Bukkit.getWorld((String)a[0]) : null;
        if (w == null) {
            return null;
        }
        try {
            return new Location(w, Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3]), Float.parseFloat(a[4]), Float.parseFloat(a[5]));
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    private static final class VoidGenerator
    extends ChunkGenerator {
        private VoidGenerator() {
        }

        public Location getFixedSpawnLocation(World world, Random random) {
            return new Location(world, 5000.5, 81.0, 5000.5);
        }
    }

    private static final class VoidBiomes
    extends BiomeProvider {
        private VoidBiomes() {
        }

        public Biome getBiome(WorldInfo info, int x, int y, int z) {
            return Biome.THE_VOID;
        }

        public List<Biome> getBiomes(WorldInfo info) {
            return List.of(Biome.THE_VOID);
        }
    }
}

