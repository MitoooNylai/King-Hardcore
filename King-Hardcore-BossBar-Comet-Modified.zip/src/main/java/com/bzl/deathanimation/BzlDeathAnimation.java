/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.minimessage.tag.resolver.Placeholder
 *  net.kyori.adventure.text.minimessage.tag.resolver.TagResolver
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.event.player.PlayerTeleportEvent$TeleportCause
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.profile.PlayerTextures
 *  org.bukkit.profile.PlayerTextures$SkinModel
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.AdminMenu;
import com.bzl.deathanimation.Banner;
import com.bzl.deathanimation.Body;
import com.bzl.deathanimation.Cinematic;
import com.bzl.deathanimation.MannequinBody;
import com.bzl.deathanimation.Menu;
import com.bzl.deathanimation.Nebula;
import com.bzl.deathanimation.Puppet;
import com.bzl.deathanimation.Settings;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import javax.imageio.ImageIO;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.profile.PlayerTextures;

public final class BzlDeathAnimation
extends JavaPlugin
implements Listener,
TabCompleter {
    static final String FX_TAG = "bda_fx";
    final NamespacedKey savedModeKey = new NamespacedKey((Plugin)this, "saved_gamemode");
    final NamespacedKey pendingKey = new NamespacedKey((Plugin)this, "pending_arrival");
    final Map<UUID, Cinematic> running = new HashMap<UUID, Cinematic>();
    private final Map<UUID, Puppet.Colors> skins = new ConcurrentHashMap<UUID, Puppet.Colors>();
    private final Map<String, Puppet.Colors> skinsByUrl = new ConcurrentHashMap<String, Puppet.Colors>();
    Nebula nebula;
    Settings settings;
    private final Set<UUID> retargeting = new HashSet<UUID>();
    static final String PERM_SKIP = "bda.command.skip";
    static final String PERM_TEST = "bda.command.test";
    static final String PERM_TEST_OTHERS = "bda.command.test.others";
    static final String PERM_RELOAD = "bda.command.reload";
    static final String PERM_BYPASS_TELEPORT = "bda.bypass.teleport";
    static final String PERM_BYPASS_COMMANDS = "bda.bypass.commands";
    static final String PERM_MENU = "bda.menu";
    static final String PERM_MENU_EDIT = "bda.menu.edit";
    static final String PERM_MENU_PLAYERS = "bda.menu.players";
    static final String PERM_MENU_MANAGE = "bda.menu.players.manage";

    void watch(Player player, Entity camera) {
        if (player.getGameMode() != GameMode.SPECTATOR) {
            player.setGameMode(GameMode.SPECTATOR);
        }
        this.retargeting.add(player.getUniqueId());
        try {
            player.setSpectatorTarget(camera);
        }
        finally {
            this.retargeting.remove(player.getUniqueId());
        }
    }

    static void unwatch(Player player) {
        if (player.getGameMode() == GameMode.SPECTATOR) {
            player.setSpectatorTarget(null);
        }
    }

    public void onEnable() {
        this.settings = new Settings(this);
        if (Body.MANNEQUIN) {
            MannequinBody.report();
        }
        Bukkit.getWorlds().forEach(w -> w.getEntities().forEach(e -> {
            if (e.getScoreboardTags().contains(FX_TAG)) {
                e.remove();
            }
        }));
        this.nebula = new Nebula(this);
        this.nebula.enable();
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        this.getCommand("bda").setExecutor((CommandExecutor)this);
        this.getCommand("bda").setTabCompleter((TabCompleter)this);
        Menu.start(this);
        this.getServer().getOnlinePlayers().forEach(this::loadSkin);
        Banner.print(this, this.settings);
    }

    public void onDisable() {
        Menu.closeAll();
        new ArrayList<Cinematic>(this.running.values()).forEach(c -> c.finish(false));
        if (this.nebula != null) {
            this.nebula.abortReleases();
        }
    }

    Puppet.Colors skinOf(Player player) {
        return this.skins.getOrDefault(player.getUniqueId(), Puppet.Colors.DEFAULT);
    }

    boolean startCinematic(Player player) {
        try {
            this.running.put(player.getUniqueId(), new Cinematic(this, player));
            return true;
        }
        catch (RuntimeException e) {
            this.getLogger().log(Level.SEVERE, "Could not start the death animation for " + player.getName() + "; they die normally instead.", e);
            return false;
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        if (this.running.containsKey(player.getUniqueId()) || this.nebula.busy(player)) {
            event.setCancelled(true);
            return;
        }
        if (!this.settings.enabled || this.settings.disabledWorlds.contains(player.getWorld().getName().toLowerCase(Locale.ROOT)) || !this.settings.exemptPermission.isBlank() && player.hasPermission(this.settings.exemptPermission) || this.nebula.isNebula(player.getWorld()) || event.getFinalDamage() < player.getHealth() || this.settings.skipCauses.contains(event.getCause().name()) || this.settings.totemSaves && BzlDeathAnimation.holdsTotem(player.getInventory())) {
            return;
        }
        event.setCancelled(this.startCinematic(player));
    }

    @EventHandler(ignoreCancelled=true)
    public void onTeleport(PlayerTeleportEvent event) {
        boolean spectateHop;
        Player p = event.getPlayer();
        if (this.retargeting.contains(p.getUniqueId())) {
            return;
        }
        boolean inCinematic = this.running.containsKey(p.getUniqueId());
        boolean bl = spectateHop = event.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE && this.nebula.busy(p);
        if (inCinematic || spectateHop) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Cinematic c = this.running.get(event.getPlayer().getUniqueId());
        if (c != null) {
            c.finish(false);
        }
        this.skins.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        String saved;
        Player player = event.getPlayer();
        String pending = (String)player.getPersistentDataContainer().get(this.pendingKey, PersistentDataType.STRING);
        if (pending != null) {
            player.getPersistentDataContainer().remove(this.pendingKey);
            int cut = pending.indexOf(59);
            if (cut > 0) {
                Location to = Nebula.deserialize(pending.substring(cut + 1));
                if (to != null) {
                    player.teleport(to);
                }
                try {
                    player.setGameMode(GameMode.valueOf((String)pending.substring(0, cut)));
                }
                catch (IllegalArgumentException ignored) {
                    player.setGameMode(GameMode.SURVIVAL);
                }
            }
        }
        if ((saved = (String)player.getPersistentDataContainer().get(this.savedModeKey, PersistentDataType.STRING)) != null) {
            GameMode real;
            player.getPersistentDataContainer().remove(this.savedModeKey);
            try {
                real = GameMode.valueOf((String)saved);
            }
            catch (IllegalArgumentException ignored) {
                real = GameMode.SURVIVAL;
            }
            player.setGameMode(real);
            if (!this.nebula.isTrapped(player)) {
                this.nebula.imprison(player, player.getLocation(), true, real);
            }
        }
        this.loadSkin(player);
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub;
        switch (sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "") {
            case "menu": 
            case "editor": 
            case "gui": {
                if (!(sender instanceof Player)) {
                    this.tell(sender, "menu.players-only", new String[0]);
                    break;
                }
                Player p = (Player)sender;
                if (!this.allowed(sender, PERM_MENU)) break;
                AdminMenu.open(this, p);
                break;
            }
            case "nebula": {
                if (!this.allowed(sender, PERM_SKIP)) {
                    return true;
                }
                if (args.length < 3 || !args[1].equalsIgnoreCase("skip")) {
                    this.tell(sender, "command.usage-skip", new String[0]);
                    return true;
                }
                Player target = Bukkit.getPlayerExact((String)args[2]);
                if (target == null) {
                    this.tell(sender, "command.not-online", args[2]);
                    break;
                }
                this.skip(sender, target);
                break;
            }
            case "test": {
                Player p;
                Player target;
                if (!this.allowed(sender, PERM_TEST)) {
                    return true;
                }
                Object object = args.length > 1 ? Bukkit.getPlayerExact((String)args[1]) : (target = sender instanceof Player ? (p = (Player)sender) : null);
                if (args.length > 1 && target == null) {
                    this.tell(sender, "command.not-online", args[1]);
                    break;
                }
                if (target == null) {
                    this.tell(sender, "command.usage-test", new String[0]);
                    break;
                }
                if (target != sender && !this.allowed(sender, PERM_TEST_OTHERS)) break;
                this.test(sender, target);
                break;
            }
            case "reload": {
                if (!this.allowed(sender, PERM_RELOAD)) break;
                this.reload(sender);
                break;
            }
            case "": {
                Player p;
                if (sender instanceof Player && (p = (Player)sender).hasPermission(PERM_MENU)) {
                    AdminMenu.open(this, p);
                    break;
                }
                if (BzlDeathAnimation.hasAnyCommand(sender)) {
                    this.tell(sender, "command.usage", new String[0]);
                    break;
                }
                this.tell(sender, "command.no-permission", new String[0]);
                break;
            }
            default: {
                if (BzlDeathAnimation.hasAnyCommand(sender)) {
                    this.tell(sender, "command.usage", new String[0]);
                    break;
                }
                this.tell(sender, "command.no-permission", new String[0]);
            }
        }
        return true;
    }

    void skip(CommandSender sender, Player target) {
        if (!this.nebula.isTrapped(target)) {
            this.tell(sender, "command.not-in-nebula", target.getName());
        } else if (this.running.containsKey(target.getUniqueId()) || this.nebula.busy(target)) {
            this.tell(sender, "command.busy", target.getName());
        } else {
            this.nebula.release(target);
            this.tell(sender, "command.skipped", target.getName());
        }
    }

    void test(CommandSender sender, Player target) {
        if (this.running.containsKey(target.getUniqueId()) || this.nebula.isTrapped(target) || this.nebula.busy(target)) {
            this.tell(sender, "command.busy", target.getName());
        } else {
            this.startCinematic(target);
        }
    }

    void reload(CommandSender sender) {
        this.settings = new Settings(this);
        this.tell(sender, "command.reloaded", new String[0]);
    }

    private boolean allowed(CommandSender sender, String permission) {
        if (sender.hasPermission(permission)) {
            return true;
        }
        this.tell(sender, "command.no-permission", new String[0]);
        return false;
    }

    private static boolean hasAnyCommand(CommandSender s) {
        return s.hasPermission(PERM_SKIP) || s.hasPermission(PERM_TEST) || s.hasPermission(PERM_RELOAD) || s.hasPermission(PERM_MENU);
    }

    void tell(CommandSender to, String key, String ... player) {
        if (!this.settings.has(key)) {
            return;
        }
        to.sendMessage(this.settings.msg(key, new TagResolver[]{Placeholder.unparsed((String)"player", (String)(player.length > 0 ? player[0] : to.getName()))}));
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> options = new ArrayList<String>();
        if (args.length == 1) {
            if (sender.hasPermission(PERM_MENU)) {
                options.add("menu");
            }
            if (sender.hasPermission(PERM_SKIP)) {
                options.add("nebula");
            }
            if (sender.hasPermission(PERM_TEST)) {
                options.add("test");
            }
            if (sender.hasPermission(PERM_RELOAD)) {
                options.add("reload");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("nebula") && sender.hasPermission(PERM_SKIP)) {
            options.add("skip");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("test") && sender.hasPermission(PERM_TEST_OTHERS)) {
            options.addAll(BzlDeathAnimation.playerNames());
        } else if (args.length == 3 && args[0].equalsIgnoreCase("nebula") && sender.hasPermission(PERM_SKIP)) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!this.nebula.isTrapped(p)) continue;
                options.add(p.getName());
            }
        }
        String typed = args[args.length - 1].toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.toLowerCase(Locale.ROOT).startsWith(typed)).toList();
    }

    private static List<String> playerNames() {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
    }

    private static boolean holdsTotem(PlayerInventory inv) {
        return inv.getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING || inv.getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    private void loadSkin(Player player) {
        if (Body.MANNEQUIN && !"blocks".equals(this.settings.body)) {
            return;
        }
        PlayerTextures textures = player.getPlayerProfile().getTextures();
        URL url = textures.getSkin();
        if (url == null) {
            return;
        }
        boolean slim = textures.getSkinModel() == PlayerTextures.SkinModel.SLIM;
        UUID id = player.getUniqueId();
        Puppet.Colors cached = this.skinsByUrl.get(url.toString());
        if (cached != null) {
            this.skins.put(id, cached);
            return;
        }
        this.getServer().getScheduler().runTaskAsynchronously((Plugin)this, () -> {
            try {
                BufferedImage img;
                URLConnection con = url.openConnection();
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                try (InputStream in = con.getInputStream();){
                    img = ImageIO.read(in);
                }
                if (img == null) {
                    return;
                }
                Puppet.Colors colors = Puppet.Colors.from(img, slim);
                this.skinsByUrl.put(url.toString(), colors);
                this.skins.put(id, colors);
            }
            catch (Exception e) {
                this.getLogger().fine("Skin download failed for " + String.valueOf(id) + ": " + e.getMessage());
            }
        });
    }
}

