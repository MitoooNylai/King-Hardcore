/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.BlockDisplay
 *  org.bukkit.entity.Display
 *  org.bukkit.entity.Display$Brightness
 *  org.bukkit.entity.Entity
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Puppet;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

final class Rift {
    private static final int LAYERS = 24;
    private static final int NOTCHES = 10;
    private static final int RAYS = 8;
    private static final Display.Brightness FULL_BRIGHT = new Display.Brightness(15, 15);
    private static final Display.Brightness PORTAL_LIT = new Display.Brightness(10, 15);
    private static final Material[] BAND = new Material[]{Material.WHITE_CONCRETE, Material.LIGHT_BLUE_CONCRETE, Material.BLUE_CONCRETE, Material.POLISHED_DEEPSLATE};
    private static final float[] BAND_R = new float[]{1.0f, 1.12f, 1.22f, 1.38f};
    private final List<List<BlockDisplay>> bands = new ArrayList<List<BlockDisplay>>();
    private final List<BlockDisplay> notches = new ArrayList<BlockDisplay>();
    private final List<BlockDisplay> rays = new ArrayList<BlockDisplay>();
    private final List<BlockDisplay> all = new ArrayList<BlockDisplay>();
    private final float radius;
    private final float facing;

    Rift(Location center, float radius, boolean seenFromAbove) {
        this.radius = radius;
        this.facing = seenFromAbove ? 1.0f : -1.0f;
        Location at = center.clone();
        at.setYaw(0.0f);
        at.setPitch(0.0f);
        try {
            int i;
            for (int b = 0; b < BAND.length; ++b) {
                ArrayList<BlockDisplay> band = new ArrayList<BlockDisplay>();
                for (int i2 = 0; i2 < 24; ++i2) {
                    BlockDisplay d = this.spawn(at, BAND[b]);
                    if (b == 3) {
                        d.setBrightness(PORTAL_LIT);
                    }
                    band.add(d);
                }
                this.bands.add(band);
            }
            for (i = 0; i < 10; ++i) {
                this.notches.add(this.spawn(at, Material.LIGHT_BLUE_CONCRETE));
            }
            for (i = 0; i < 8; ++i) {
                this.rays.add(this.spawn(at, Material.END_ROD));
            }
            this.size(0.0f, 0, 0);
        }
        catch (RuntimeException e) {
            this.remove();
            throw e;
        }
    }

    private BlockDisplay spawn(Location at, Material m) {
        BlockDisplay d = (BlockDisplay)at.getWorld().spawn(at, BlockDisplay.class, e -> {
            e.setPersistent(false);
            e.addScoreboardTag("bda_fx");
            e.setBlock(m.createBlockData());
            e.setBrightness(FULL_BRIGHT);
        });
        this.all.add(d);
        return d;
    }

    void size(float s, int interp, int tick) {
        float a;
        int i;
        float pulse = Math.max(0.001f, s * (1.0f + 0.04f * (float)Math.sin((double)tick * 0.3)));
        Matrix4f flat = new Matrix4f().rotateX(-1.5707964f).scale(pulse);
        boolean bandsNow = interp == 0 || tick % 2 == 0;
        for (int b = 0; bandsNow && b < BAND.length; ++b) {
            float r = this.radius * BAND_R[b];
            float z = this.facing * (0.18f - (float)b * 0.06f);
            for (int i2 = 0; i2 < 24; ++i2) {
                float a2 = (float)((double)i2 * 1.5707963267948966 / 24.0) + (float)tick * 0.02f;
                Puppet.apply((Display)this.bands.get(b).get(i2), new Matrix4f((Matrix4fc)flat).rotateZ(a2).translate(-r, -r, z - this.facing * (float)i2 * 5.0E-4f).scale(2.0f * r, 2.0f * r, 0.03f), interp == 0 ? 0 : Math.max(interp, 3));
            }
        }
        float dialR = this.radius * 1.3f;
        for (i = 0; i < 10; ++i) {
            a = (float)((double)i * Math.PI * 2.0 / 10.0) - (float)tick * 0.03f;
            Puppet.apply((Display)this.notches.get(i), new Matrix4f((Matrix4fc)flat).rotateZ(a).translate(dialR, 0.0f, this.facing > 0.0f ? 0.045f : -0.015f).translate(-0.12f * this.radius, -0.03f, 0.0f).scale(0.24f * this.radius, 0.06f, 0.01f), interp);
        }
        for (i = 0; i < 8; ++i) {
            a = (float)((double)i * Math.PI * 2.0 / 8.0) + (float)tick * 0.015f;
            float len = this.radius * (0.7f + 0.25f * (float)Math.sin((double)tick * 0.2 + (double)i));
            Puppet.apply((Display)this.rays.get(i), new Matrix4f((Matrix4fc)flat).rotateZ(a - 1.5707964f).translate(-0.5f, this.radius * 1.42f, -0.5f).scale(1.0f, len, 1.0f), interp);
        }
    }

    void remove() {
        this.all.forEach(Entity::remove);
    }
}

