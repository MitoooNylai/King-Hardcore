/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.plugin.configuration.PluginMeta
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.minimessage.tag.resolver.Placeholder
 *  net.kyori.adventure.text.minimessage.tag.resolver.TagResolver
 *  org.bukkit.Color
 *  org.bukkit.DyeColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Particle$DustOptions
 *  org.bukkit.Particle$DustTransition
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Body;
import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Menu;
import com.bzl.deathanimation.Settings;
import io.papermc.paper.plugin.configuration.PluginMeta;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

final class AdminMenu {
    private static final String BRAND = "<gradient:#B8F1FF:#3FB8FF><bold>";
    private static final List<Color> PALETTE;
    private static final List<String> PALETTE_NAMES;

    static void open(BzlDeathAnimation plugin, Player viewer) {
        new Main(plugin, viewer).open();
    }

    private static String time(long millis) {
        long s = (millis + 999L) / 1000L;
        return String.format("%02d:%02d", s / 60L, s % 60L);
    }

    private static void pager(Menu m, int page, int pages, IntConsumer to) {
        if (page > 0) {
            m.set(m.rows() * 9 - 6, Menu.item(Material.SPECTRAL_ARROW, "<#7FE3FF><bold>\u00ab Halaman " + page, "<gray>Halaman " + (page + 1) + " dari " + pages), e -> to.accept(page - 1));
        }
        if (page < pages - 1) {
            m.set(m.rows() * 9 - 4, Menu.item(Material.SPECTRAL_ARROW, "<#7FE3FF><bold>Halaman " + (page + 2) + " \u00bb", "<gray>Halaman " + (page + 1) + " dari " + pages), e -> to.accept(page + 1));
        }
    }

    static List<String> describe(Fx fx) {
        List<String> lore = Menu.gray(fx.slot.description, "");
        lore.add("<dark_gray>Status: " + (fx.enabled ? "<#5CFF8A>\u25cf AKTIF" : "<#FF6B6B>\u25cf NONAKTIF"));
        ArrayList<CallSite> types = new ArrayList<CallSite>();
        for (int i = 0; i < fx.types.size(); ++i) {
            double w = fx.weights.get(i);
            types.add((CallSite)((Object)(fx.types.get(i).name() + (String)(w == 1.0 ? "" : " \u00d7" + Fx.num(w)))));
        }
        lore.add("<gray>Partikel: <white>" + (types.isEmpty() ? "<#FF6B6B>(kosong)" : String.join((CharSequence)", ", types)));
        StringBuilder colors = new StringBuilder();
        for (Color c : fx.colors) {
            colors.append("<color:").append(Fx.hex(c)).append(">\u25a0</color>");
        }
        lore.add("<gray>Warna: " + String.valueOf(colors));
        lore.add("<gray>Ukuran: <white>" + Fx.num(fx.size) + "   <gray>Jumlah: <white>x" + Fx.num(fx.amount));
        if (fx.types.stream().anyMatch(t -> t.getDataType() == BlockData.class)) {
            lore.add("<gray>Blok: <white>" + fx.block.getMaterial().getKey().getKey());
        }
        return lore;
    }

    private static List<Particle> choices() {
        return Arrays.stream(Particle.values()).filter(Fx::supported).sorted(Comparator.comparing(Enum::name)).toList();
    }

    private AdminMenu() {
    }

    static {
        String[][] brand;
        PALETTE = new ArrayList<Color>();
        PALETTE_NAMES = new ArrayList<String>();
        for (DyeColor d : DyeColor.values()) {
            PALETTE.add(d.getColor());
            PALETTE_NAMES.add(d.name().toLowerCase(Locale.ROOT).replace('_', ' '));
        }
        for (String[] b : brand = new String[][]{{"#FFFFFF", "putih terang"}, {"#B8F1FF", "es pucat"}, {"#7FE3FF", "es"}, {"#3FB8FF", "biru portal"}, {"#FFD86B", "emas"}}) {
            PALETTE.add(Fx.parseColor(b[0]));
            PALETTE_NAMES.add(b[1]);
        }
    }

    static final class Main
    extends Menu {
        Main(BzlDeathAnimation plugin, Player viewer) {
            super(plugin, viewer);
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.main", new TagResolver[0]);
        }

        @Override
        boolean live() {
            return true;
        }

        @Override
        void draw() {
            Settings s = this.plugin.settings;
            PluginMeta meta = this.plugin.getPluginMeta();
            int trapped = this.plugin.nebula.trapped().size();
            this.set(4, Menu.glow(Main.item(Material.NETHER_STAR, "<gradient:#B8F1FF:#3FB8FF><bold>King Hardcore", "<gray>Versi <white>" + Menu.esc(meta.getVersion()), "<gray>Author <white>" + Menu.esc(String.join((CharSequence)", ", meta.getAuthors())), "", "<gray>Animasi: " + (s.enabled ? "<#5CFF8A>aktif" : "<#FF6B6B>mati"), "<gray>Badan: <white>" + (Body.MANNEQUIN && !"blocks".equals(s.body) ? "Mannequin" : "Blok"), "<gray>Di Nebula: <white>" + trapped + " pemain", "", "<dark_gray>King Hardcore"), true));
            this.toggle(13, Material.END_CRYSTAL, "Animasi Kematian", "death-animation.enabled", s.enabled, "Saklar utama plugin.", "Mati = pemain mati seperti biasa.");
            this.link(20, Material.WITHER_SKELETON_SKULL, "Kematian", "bda.menu.edit", () -> new Death(this.plugin, this.viewer), "Totem, model badan, posisi portal,", "dunia yang dikecualikan.");
            this.link(22, Material.END_STONE, "Nebula", "bda.menu.edit", () -> new NebulaPage(this.plugin, this.viewer), "Lama hukuman, tujuan pulang,", "aturan & sinematik Nebula.");
            this.link(24, Material.JUKEBOX, "Efek & Suara", "bda.menu.edit", () -> new Effects(this.plugin, this.viewer), "Musik, sayap, detak jantung,", "napas, goyang kamera.");
            this.link(29, Material.BLAZE_POWDER, "Editor Partikel", "bda.menu.edit", () -> new Particles(this.plugin, this.viewer, 0), "Tipe, warna, ukuran & jumlah", "dari " + Fx.Slot.values().length + " efek partikel.");
            this.link(31, Material.PLAYER_HEAD, "Pemain di Nebula", "bda.menu.players", () -> new Players(this.plugin, this.viewer, 0), "<white>" + trapped + " <gray>pemain sedang terkurung.", "Lihat sisa waktu, bebaskan, teleport.");
            this.button(33, Main.item(Material.ARMOR_STAND, "<#B8F1FF><bold>Tes Animasi", "<gray>Putar animasi kematian pada", "<gray>dirimu sendiri (tanpa mati).", "", "<#7FE3FF>\u00bb <gray>Klik untuk memutar"), "bda.command.test", e -> this.later(() -> {
                this.viewer.closeInventory();
                this.plugin.test((CommandSender)this.viewer, this.viewer);
            }));
            this.button(48, Main.item(Material.CLOCK, "<#B8F1FF><bold>Muat Ulang", "<gray>Baca ulang config.yml & messages.yml", "<gray>dari file.", "", "<#7FE3FF>\u00bb <gray>Klik untuk memuat ulang"), "bda.command.reload", e -> {
                this.plugin.reload((CommandSender)this.viewer);
                this.sound("block.amethyst_block.chime", 1.2f);
                this.later(this::open);
            });
            this.set(49, Main.item(Material.BARRIER, "<#FF6B6B><bold>Tutup", new String[0]), e -> this.later(() -> ((Player)this.viewer).closeInventory()));
        }
    }

    static final class Players
    extends Menu {
        private final int page;

        Players(BzlDeathAnimation plugin, Player viewer, int page) {
            super(plugin, viewer);
            this.page = page;
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.players", new TagResolver[0]);
        }

        @Override
        boolean live() {
            return true;
        }

        @Override
        void draw() {
            int idx;
            List<Player> trapped = this.plugin.nebula.trapped();
            int pages = Math.max(1, (trapped.size() + INNER.length - 1) / INNER.length);
            int shown = Math.min(this.page, pages - 1);
            boolean manage = this.viewer.hasPermission("bda.menu.players.manage");
            this.header(Material.ENDER_EYE, "Pemain di Nebula", "<white>" + trapped.size() + " <gray>pemain terkurung", "(hanya yang online).", "", "<dark_gray>Diperbarui setiap detik.");
            if (trapped.isEmpty()) {
                this.set(22, Players.item(Material.GLASS_BOTTLE, "<gray><bold>Nebula kosong", "<dark_gray>Tidak ada pemain yang terkurung."));
            }
            for (int i = 0; i < INNER.length && (idx = shown * INNER.length + i) < trapped.size(); ++i) {
                Player p2 = trapped.get(idx);
                this.set(INNER[i], this.head(p2, manage), e -> this.act(p2, e.isRightClick(), e.isShiftClick()));
            }
            if (!trapped.isEmpty()) {
                this.button(51, Players.item(Material.TNT, "<#FF6B6B><bold>Bebaskan Semua", "<gray>Lepaskan semua pemain yang", "<gray>tidak sedang dalam animasi.", "", "<#7FE3FF>Shift + klik <gray>\u00bb bebaskan"), "bda.menu.players.manage", e -> {
                    if (!e.isShiftClick()) {
                        return;
                    }
                    int n = 0;
                    for (Player p : trapped) {
                        if (!p.isOnline() || !this.plugin.nebula.isTrapped(p) || this.plugin.running.containsKey(p.getUniqueId()) || this.plugin.nebula.busy(p)) continue;
                        this.plugin.nebula.release(p);
                        ++n;
                    }
                    if (this.plugin.settings.has("menu.released-all")) {
                        this.viewer.sendMessage(this.plugin.settings.msg("menu.released-all", new TagResolver[]{Placeholder.unparsed((String)"count", (String)String.valueOf(n))}));
                    }
                    this.sound("entity.player.levelup", 1.2f);
                    this.redraw();
                });
            }
            AdminMenu.pager(this, shown, pages, p -> this.go(new Players(this.plugin, this.viewer, p)));
            this.back(49, () -> new Main(this.plugin, this.viewer));
        }

        private ItemStack head(Player p, boolean manage) {
            String status = this.plugin.running.containsKey(p.getUniqueId()) || this.plugin.nebula.busy(p) ? "<yellow>Dalam animasi" : (this.plugin.nebula.isNebula(p.getWorld()) ? "<#5CFF8A>Di Nebula" : "<#FF6B6B>Di luar Nebula (bypass)");
            ArrayList<String> lore = new ArrayList<String>(List.of("<gray>Sisa waktu: <white><bold>" + AdminMenu.time(this.plugin.nebula.remaining(p)), "<gray>Status: " + status, "<gray>Dunia: <white>" + Menu.esc(p.getWorld().getName()), ""));
            if (manage) {
                lore.add("<#7FE3FF>Klik kiri <gray>\u00bb teleport ke pemain");
                lore.add("<#7FE3FF>Klik kanan <gray>\u00bb bebaskan sekarang");
                lore.add("<#7FE3FF>Shift + kiri <gray>\u00bb +5 menit");
                lore.add("<#7FE3FF>Shift + kanan <gray>\u00bb -5 menit");
            } else {
                lore.add("<#FF6B6B>\u2716 Butuh izin <white>bda.menu.players.manage");
            }
            ItemStack item = Players.item(Material.PLAYER_HEAD, "<#B8F1FF><bold>" + p.getName(), lore);
            SkullMeta meta = (SkullMeta)item.getItemMeta();
            meta.setPlayerProfile(p.getPlayerProfile());
            item.setItemMeta((ItemMeta)meta);
            return item;
        }

        private void act(Player p, boolean right, boolean shift) {
            if (!this.can("bda.menu.players.manage")) {
                return;
            }
            if (!p.isOnline() || !this.plugin.nebula.isTrapped(p)) {
                this.redraw();
                return;
            }
            if (shift) {
                int minutes = right ? -5 : 5;
                this.plugin.nebula.addTime(p, (long)minutes * 60000L);
                if (this.plugin.settings.has("menu.time-changed")) {
                    this.viewer.sendMessage(this.plugin.settings.msg("menu.time-changed", new TagResolver[]{Placeholder.unparsed((String)"player", (String)p.getName()), Placeholder.unparsed((String)"minutes", (String)((minutes > 0 ? "+" : "") + minutes)), Placeholder.unparsed((String)"time", (String)AdminMenu.time(this.plugin.nebula.remaining(p)))}));
                }
                this.sound("block.note_block.hat", right ? 0.8f : 1.4f);
                this.redraw();
            } else if (right) {
                this.plugin.skip((CommandSender)this.viewer, p);
                this.redraw();
            } else {
                this.later(() -> {
                    this.viewer.closeInventory();
                    this.viewer.teleport((Entity)p);
                });
            }
        }
    }

    static final class ColorPicker
    extends Menu {
        private static final int MAX = 7;
        private final Fx.Slot slot;
        private final int returnPage;

        ColorPicker(BzlDeathAnimation plugin, Player viewer, Fx.Slot slot, int returnPage) {
            super(plugin, viewer);
            this.slot = slot;
            this.returnPage = returnPage;
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.colors", new TagResolver[]{Placeholder.unparsed((String)"name", (String)this.slot.key)});
        }

        private void store(List<String> hexes) {
            this.save("particles.effects." + this.slot.key + ".colors", hexes);
            this.sound("entity.experience_orb.pickup", 1.4f);
        }

        @Override
        void draw() {
            int i;
            Fx fx = this.plugin.settings.particles.get((Object)this.slot);
            ArrayList<String> current = new ArrayList<String>();
            for (Color c : fx.colors) {
                current.add(Fx.hex(c));
            }
            this.header(Material.FIREWORK_STAR, "Warna: " + this.slot.key, "Baris atas = warna sekarang", "(urutan gradasi).", "Partikel tanpa warna", "mengabaikan ini.");
            for (i = 0; i < Math.min(7, current.size()); ++i) {
                int at = i;
                this.set(10 + i, Menu.swatch(fx.colors.get(i), "<color:" + (String)current.get(i) + "><bold>" + (String)current.get(i), List.of("<gray>Warna ke-" + (i + 1), "", "<#7FE3FF>Klik <gray>\u00bb hapus dari gradasi")), e -> {
                    if (!this.can("bda.menu.edit")) {
                        return;
                    }
                    if (current.size() == 1) {
                        this.sound("entity.villager.no", 1.0f);
                        return;
                    }
                    ArrayList<String> next = new ArrayList<String>(current);
                    next.remove(at);
                    this.store(next);
                });
            }
            for (i = 0; i < PALETTE.size() && 7 + i < INNER.length; ++i) {
                int slotIndex = INNER[7 + i];
                Color c = PALETTE.get(i);
                String hex = Fx.hex(c);
                this.set(slotIndex, Menu.swatch(c, "<color:" + hex + "><bold>" + PALETTE_NAMES.get(i), List.of("<gray>" + hex, "", "<#7FE3FF>Klik kiri <gray>\u00bb pakai warna ini saja", "<#7FE3FF>Klik kanan <gray>\u00bb tambah ke gradasi")), e -> {
                    if (!this.can("bda.menu.edit")) {
                        return;
                    }
                    if (!e.isRightClick()) {
                        this.store(List.of(hex));
                    } else if (current.size() >= 7) {
                        this.sound("entity.villager.no", 1.0f);
                    } else {
                        ArrayList<String> next = new ArrayList<String>(current);
                        next.add(hex);
                        this.store(next);
                    }
                });
            }
            this.set(47, ColorPicker.item(Material.LAVA_BUCKET, "<#FF6B6B><bold>Warna Default", "<gray>Kembalikan warna slot ini", "<gray>ke bawaan plugin.", "", "<#7FE3FF>Shift + klik <gray>\u00bb reset"), e -> {
                if (!e.isShiftClick() || !this.can("bda.menu.edit")) {
                    return;
                }
                this.restore("particles.effects." + this.slot.key + ".colors");
                this.sound("block.anvil.use", 1.4f);
            });
            this.back(49, () -> new ParticleEdit(this.plugin, this.viewer, this.slot, this.returnPage));
        }
    }

    static final class ParticlePicker
    extends Menu {
        private final Fx.Slot slot;
        private final int returnPage;
        private final int page;

        ParticlePicker(BzlDeathAnimation plugin, Player viewer, Fx.Slot slot, int returnPage, int page) {
            super(plugin, viewer);
            this.slot = slot;
            this.returnPage = returnPage;
            this.page = page;
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.picker", new TagResolver[]{Placeholder.unparsed((String)"name", (String)this.slot.key)});
        }

        @Override
        void draw() {
            int idx;
            Fx fx = this.plugin.settings.particles.get((Object)this.slot);
            List<Particle> all = AdminMenu.choices();
            int pages = (all.size() + INNER.length - 1) / INNER.length;
            List<String> head = ParticlePicker.gray("Dipakai sekarang:");
            for (String entry : fx.entries()) {
                head.add("<dark_gray>  \u2022 <white>" + entry);
            }
            head.add("");
            head.add("<dark_gray>Bobot campuran (NAMA*bobot) bisa");
            head.add("<dark_gray>diatur di config.yml.");
            this.set(4, Menu.glow(ParticlePicker.item(Material.BLAZE_POWDER, "<#B8F1FF><bold>Tipe Partikel: " + this.slot.key, head), true));
            for (int i = 0; i < INNER.length && (idx = this.page * INNER.length + i) < all.size(); ++i) {
                Particle type = all.get(idx);
                int at = fx.types.indexOf(type);
                boolean used = at >= 0;
                List<String> lore = ParticlePicker.gray("Data: " + ParticlePicker.needs(type), "");
                lore.add(used ? "<#5CFF8A>\u2714 Dipakai" : "<dark_gray>Tidak dipakai");
                lore.add("");
                lore.add("<#7FE3FF>Klik kiri <gray>\u00bb pakai ini saja");
                lore.add("<#7FE3FF>Klik kanan <gray>\u00bb " + (used ? "hapus dari campuran" : "tambah ke campuran"));
                this.set(INNER[i], Menu.glow(ParticlePicker.item(ParticlePicker.icon(type), (used ? "<#5CFF8A>" : "<white>") + type.name(), lore), used), e -> {
                    if (!this.can("bda.menu.edit")) {
                        return;
                    }
                    List<String> entries = new ArrayList<String>(fx.entries());
                    if (!e.isRightClick()) {
                        entries = List.of(type.name());
                    } else if (used) {
                        if (entries.size() == 1) {
                            this.sound("entity.villager.no", 1.0f);
                            return;
                        }
                        entries.remove(at);
                    } else {
                        entries.add(type.name());
                    }
                    this.save("particles.effects." + this.slot.key + ".particles", entries);
                    this.sound("entity.experience_orb.pickup", 1.4f);
                });
            }
            AdminMenu.pager(this, this.page, pages, p -> this.go(new ParticlePicker(this.plugin, this.viewer, this.slot, this.returnPage, p)));
            this.back(49, () -> new ParticleEdit(this.plugin, this.viewer, this.slot, this.returnPage));
        }

        private static String needs(Particle type) {
            Class want = type.getDataType();
            if (want == Particle.DustOptions.class) {
                return "warna + ukuran";
            }
            if (want == Particle.DustTransition.class) {
                return "2 warna + ukuran";
            }
            if (want == Color.class) {
                return "warna";
            }
            if (want == BlockData.class) {
                return "blok";
            }
            if (want == ItemStack.class) {
                return "item (dari blok)";
            }
            if (want == Float.class) {
                return "ukuran";
            }
            if (want == Integer.class) {
                return "angka (0)";
            }
            return "-";
        }

        private static Material icon(Particle type) {
            Class want = type.getDataType();
            if (want == Particle.DustOptions.class || want == Particle.DustTransition.class || want == Color.class) {
                return Material.RED_DYE;
            }
            if (want == BlockData.class) {
                return Material.BRICKS;
            }
            if (want == ItemStack.class) {
                return Material.ITEM_FRAME;
            }
            if (want == Float.class || want == Integer.class) {
                return Material.AMETHYST_SHARD;
            }
            return Material.GLOWSTONE_DUST;
        }
    }

    static final class ParticleEdit
    extends Menu {
        private final Fx.Slot slot;
        private final int returnPage;

        ParticleEdit(BzlDeathAnimation plugin, Player viewer, Fx.Slot slot, int returnPage) {
            super(plugin, viewer);
            this.slot = slot;
            this.returnPage = returnPage;
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.particle", new TagResolver[]{Placeholder.unparsed((String)"name", (String)this.slot.key)});
        }

        @Override
        int rows() {
            return 5;
        }

        private String path(String field) {
            return "particles.effects." + this.slot.key + "." + field;
        }

        @Override
        void draw() {
            Fx fx = this.plugin.settings.particles.get((Object)this.slot);
            this.set(4, Menu.glow(ParticleEdit.item(this.slot.icon, "<#B8F1FF><bold>" + this.slot.key, AdminMenu.describe(fx)), true));
            this.toggle(19, fx.enabled ? Material.LIME_DYE : Material.GRAY_DYE, "Aktif", this.path("enabled"), fx.enabled, "Mati = efek ini tidak", "menggambar apa pun.");
            List<String> types = ParticleEdit.gray("Partikel yang digambar.", "Bisa campuran beberapa tipe.", "");
            for (String string : fx.entries()) {
                types.add("<dark_gray>  \u2022 <white>" + string);
            }
            types.add("");
            types.add("<#7FE3FF>\u00bb <gray>Klik untuk memilih");
            this.set(20, ParticleEdit.item(Material.BLAZE_POWDER, "<#B8F1FF><bold>Tipe Partikel", types), e -> this.go(new ParticlePicker(this.plugin, this.viewer, this.slot, this.returnPage, 0)));
            List<String> colors = ParticleEdit.gray("Untuk partikel berwarna (DUST,", "DUST_COLOR_TRANSITION, ...).", "Beberapa warna = gradasi.", "");
            for (Color c : fx.colors) {
                colors.add("<color:" + Fx.hex(c) + ">\u25a0 <white>" + Fx.hex(c));
            }
            colors.add("");
            colors.add("<#7FE3FF>\u00bb <gray>Klik untuk memilih");
            this.set(21, Menu.swatch(fx.colors.get(0), "<#B8F1FF><bold>Warna", colors), e -> this.go(new ColorPicker(this.plugin, this.viewer, this.slot, this.returnPage)));
            this.number(22, Material.SLIME_BALL, "Ukuran", this.path("size"), fx.size, 0.1, 0.5, 0.1, 4.0, false, "", "Ukuran partikel berwarna.");
            this.number(23, Material.HOPPER, "Jumlah", this.path("amount"), fx.amount, 0.1, 0.5, 0.0, 10.0, false, "x", "Pengali jumlah partikel slot ini.");
            Material material = this.viewer.getInventory().getItemInMainHand().getType();
            Material shown = fx.block.getMaterial().isItem() ? fx.block.getMaterial() : Material.STONE;
            this.set(24, ParticleEdit.item(shown, "<#B8F1FF><bold>Blok", "<gray>Untuk partikel blok (BLOCK,", "<gray>FALLING_DUST, BLOCK_MARKER ...).", "", "<gray>Sekarang: <white>" + fx.block.getMaterial().getKey().getKey(), "", "<#7FE3FF>Klik kiri <gray>\u00bb pakai blok di tanganmu", "<dark_gray>  (di tangan: " + (material.isBlock() && !material.isAir() ? material.getKey().getKey() : "bukan blok") + ")", "<#7FE3FF>Klik kanan <gray>\u00bb kembali ke default"), e -> {
                if (!this.can("bda.menu.edit")) {
                    return;
                }
                if (e.isRightClick()) {
                    this.restore(this.path("block"));
                } else if (held.isBlock() && !held.isAir()) {
                    this.save(this.path("block"), held.getKey().getKey());
                    this.sound("block.stone.place", 1.0f);
                } else {
                    this.plugin.tell((CommandSender)this.viewer, "menu.hold-block", new String[0]);
                    this.sound("entity.villager.no", 1.0f);
                }
            });
            this.set(25, ParticleEdit.item(Material.ENDER_EYE, "<#B8F1FF><bold>Pratinjau", "<gray>Munculkan efek ini di depanmu", "<gray>beberapa kali (tutup menu untuk", "<gray>melihat lebih jelas).", "", "<#7FE3FF>\u00bb <gray>Klik untuk melihat"), e -> this.preview(fx));
            this.set(42, ParticleEdit.item(Material.LAVA_BUCKET, "<#FF6B6B><bold>Reset ke Default", "<gray>Kembalikan slot ini ke bawaan", "<gray>plugin (tipe, warna, ukuran ...).", "", "<#7FE3FF>Shift + klik <gray>\u00bb reset"), e -> {
                if (!e.isShiftClick() || !this.can("bda.menu.edit")) {
                    return;
                }
                this.restore("particles.effects." + this.slot.key);
                this.sound("block.anvil.use", 1.4f);
            });
            this.back(40, () -> new Particles(this.plugin, this.viewer, this.returnPage));
        }

        private void preview(final Fx fx) {
            final Location at = this.viewer.getEyeLocation().add(this.viewer.getLocation().getDirection().multiply(2.5));
            this.sound("block.amethyst_block.chime", 1.6f);
            new BukkitRunnable(){
                int n;

                public void run() {
                    if (this.n >= 6 || !viewer.isOnline()) {
                        this.cancel();
                        return;
                    }
                    double t = (double)this.n++ / 5.0;
                    fx.spawn(at, 20, 0.5, 0.5, 0.5, 0.02, t);
                    for (int i = 0; i < 12; ++i) {
                        double a = Math.PI * 2 * (double)i / 12.0;
                        fx.spawn(at, 0, Math.cos(a), 0.15, Math.sin(a), 0.12, (double)i / 11.0);
                    }
                }
            }.runTaskTimer((Plugin)this.plugin, 0L, 8L);
        }
    }

    static final class Particles
    extends Menu {
        private final int page;

        Particles(BzlDeathAnimation plugin, Player viewer, int page) {
            super(plugin, viewer);
            this.page = page;
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.particles", new TagResolver[0]);
        }

        @Override
        void draw() {
            int idx;
            Settings s = this.plugin.settings;
            Fx.Slot[] slots = Fx.Slot.values();
            int pages = (slots.length + INNER.length - 1) / INNER.length;
            this.header(Material.BLAZE_POWDER, "Editor Partikel", "Setiap efek di animasi adalah", "satu slot. Kode mengatur bentuk,", "slot mengatur isi.", "", "<white>" + slots.length + " <gray>slot");
            for (int i = 0; i < INNER.length && (idx = this.page * INNER.length + i) < slots.length; ++i) {
                Fx.Slot slot = slots[idx];
                Fx fx = s.particles.get((Object)slot);
                List<String> lore = AdminMenu.describe(fx);
                lore.add("");
                lore.add("<#7FE3FF>Klik kiri <gray>\u00bb edit");
                lore.add("<#7FE3FF>Klik kanan <gray>\u00bb " + (fx.enabled ? "matikan" : "nyalakan"));
                this.set(INNER[i], Menu.glow(Particles.item(slot.icon, (fx.enabled ? "<#5CFF8A>" : "<#FF6B6B>") + "<bold>" + slot.key, lore), fx.enabled), e -> {
                    if (!this.can("bda.menu.edit")) {
                        return;
                    }
                    if (e.isRightClick()) {
                        this.save("particles.effects." + slot.key + ".enabled", !fx.enabled);
                        this.sound("block.note_block.pling", fx.enabled ? 0.7f : 1.6f);
                    } else {
                        this.go(new ParticleEdit(this.plugin, this.viewer, slot, this.page));
                    }
                });
            }
            this.number(46, Material.GLOWSTONE_DUST, "Pengali Jumlah", "particles.amount-multiplier", s.particleAmount, 0.1, 0.5, 0.0, 5.0, false, "x", "Mengalikan SEMUA partikel.", "Turunkan di server ramai.");
            this.number(52, Material.SPYGLASS, "Jarak Pandang", "particles.view-distance", s.particleViewDistance, 8.0, 32.0, 8.0, 256.0, true, " blok", "Pemain lebih jauh dari ini", "tidak menerima partikel.");
            AdminMenu.pager(this, this.page, pages, p -> this.go(new Particles(this.plugin, this.viewer, p)));
            this.back(49, () -> new Main(this.plugin, this.viewer));
        }
    }

    static final class Effects
    extends Menu {
        Effects(BzlDeathAnimation plugin, Player viewer) {
            super(plugin, viewer);
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.effects", new TagResolver[0]);
        }

        @Override
        int rows() {
            return 4;
        }

        @Override
        void draw() {
            Settings s = this.plugin.settings;
            this.header(Material.JUKEBOX, "Efek & Suara", "Tambahan di dalam sinematik.");
            this.toggle(10, Material.MUSIC_DISC_OTHERSIDE, "Musik", "effects.music", s.music, "Musik End dari bangun", "sampai mendarat di rumah.");
            this.toggle(11, Material.ELYTRA, "Sayap Dewi", "effects.wings", s.wings, "Sayap mengepak + fanfare", "setelah mendarat.");
            this.toggle(12, Material.SPYGLASS, "Menoleh Kiri-Kanan", "effects.look-around", s.lookAround, "Kepala menoleh saat tiba", "di Nebula.");
            this.toggle(14, Material.ANVIL, "Goyang Kamera", "effects.screen-shake", s.screenShake, "Saat batu jatuh, portal", "menyala, dan mendarat.");
            this.toggle(15, Material.REDSTONE, "Detak Jantung", "effects.heartbeat", s.heartbeat, "Saat terbaring & menoleh.");
            this.toggle(16, Material.PHANTOM_MEMBRANE, "Suara Napas", "effects.breathing", s.breathing, "Napas terengah saat bangun", "dan menoleh.");
            this.back(31, () -> new Main(this.plugin, this.viewer));
        }
    }

    static final class NebulaPage
    extends Menu {
        NebulaPage(BzlDeathAnimation plugin, Player viewer) {
            super(plugin, viewer);
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.nebula", new TagResolver[0]);
        }

        @Override
        int rows() {
            return 5;
        }

        @Override
        void draw() {
            Settings s = this.plugin.settings;
            this.header(Material.END_STONE, "Nebula", "Dimensi void tempat pemain", "ditahan setelah mati.");
            this.number(10, Material.CLOCK, "Lama Hukuman", "nebula.duration-minutes", s.durationMinutes, 1.0, 5.0, 1.0, 1440.0, true, " menit", "Berapa lama pemain ditahan.", "Tetap berjalan saat offline.");
            this.cycle(11, Material.RED_BED, "Tujuan Pulang", "nebula.return-to", s.returnTo, List.of("death", "spawn"), List.of("Tempat mati", "Kasur / spawn dunia"), "Ke mana pemain kembali.");
            this.cycle(12, Material.FILLED_MAP, "Gamemode di Nebula", "nebula.gamemode", s.nebulaMode.name(), List.of("ADVENTURE", "SURVIVAL", "CREATIVE"), List.of("Adventure", "Survival", "Creative"), "Adventure = bisa jalan, tidak", "bisa merusak pulau.");
            this.number(13, Material.NAME_TAG, "Lama Judul NEBULA", "nebula.title.stay-ticks", s.titleStay, 10.0, 40.0, 0.0, 400.0, true, " tick", "20 tick = 1 detik.");
            this.toggle(14, Material.GOLDEN_APPLE, "Pulihkan Saat Tiba", "nebula.heal-on-arrival", s.healOnArrival, "Darah & lapar penuh saat masuk.");
            this.toggle(15, Material.ENDER_PEARL, "Blokir Teleport Keluar", "nebula.block-teleport-out", s.blockTeleport, "/spawn, /home, /tpa ... ditolak.", "Bypass: bda.bypass.teleport");
            ArrayList<String> cmds = new ArrayList<String>(s.allowedCommands);
            cmds.sort(null);
            this.toggle(16, Material.COMMAND_BLOCK, "Blokir Command", "nebula.block-commands", s.blockCommands, "Hanya command ini yang boleh:", "<white>/" + String.join((CharSequence)" /", cmds), "Bypass: bda.bypass.commands");
            this.toggle(19, Material.ELYTRA, "Sinematik Masuk", "nebula.arrival-cinematic", s.arrivalCinematic, "Badan jatuh dari portal langit", "ke pulau Nebula.");
            this.toggle(20, Material.FEATHER, "Sinematik Pulang", "nebula.release-cinematic", s.releaseCinematic, "Portal lantai, lalu turun dari", "langit kembali ke dunia.");
            this.toggle(21, Material.AMETHYST_SHARD, "Partikel Ambient", "nebula.ambient-particles", s.ambientParticles, "Debu bintang di sekitar pemain.");
            this.toggle(22, Material.BELL, "Suara Ambient", "nebula.ambient-sounds", s.ambientSounds, "Gemuruh & bisikan dari jauh.");
            this.set(25, NebulaPage.item(Material.END_PORTAL_FRAME, "<#B8F1FF><bold>Dunia Nebula", "<gray>Nama: <white>" + Menu.esc(s.nebulaWorld), "", "<dark_gray>Ubah di config.yml -> nebula.world", "<dark_gray>(butuh restart server)"));
            this.back(40, () -> new Main(this.plugin, this.viewer));
        }
    }

    static final class Death
    extends Menu {
        Death(BzlDeathAnimation plugin, Player viewer) {
            super(plugin, viewer);
        }

        @Override
        Component title() {
            return this.plugin.settings.msg("menu.title.death", new TagResolver[0]);
        }

        @Override
        int rows() {
            return 5;
        }

        @Override
        void draw() {
            Settings s = this.plugin.settings;
            this.header(Material.WITHER_SKELETON_SKULL, "Kematian", "Yang terjadi saat pemain", "hampir mati.");
            this.toggle(10, Material.END_CRYSTAL, "Animasi Kematian", "death-animation.enabled", s.enabled, "Saklar utama plugin.");
            this.toggle(11, Material.TOTEM_OF_UNDYING, "Totem Menyelamatkan", "death-animation.totem-saves-player", s.totemSaves, "Totem di tangan = selamat cara", "vanilla, tanpa animasi.");
            this.cycle(12, Material.ARMOR_STAND, "Model Badan", "death-animation.body", s.body, List.of("auto", "mannequin", "blocks"), List.of("Otomatis", "Mannequin (skin penuh, 1.21.9+)", "Blok (semua versi)"), "Kembaran pemain di sinematik.", "Blok = pakai jika klien tidak", "menampilkan mannequin.");
            this.number(14, Material.ENDER_EYE, "Jarak Portal", "death-animation.portal-distance", s.portalDistance, 0.5, 2.0, 2.0, 12.0, false, " blok", "Jarak portal di depan pemain.");
            this.number(15, Material.LADDER, "Tinggi Portal", "death-animation.portal-height", s.portalHeight, 0.5, 1.0, 1.0, 8.0, false, " blok", "Tinggi pusat portal dari tanah.");
            String world = this.viewer.getWorld().getName();
            boolean off = s.disabledWorlds.contains(world.toLowerCase(Locale.ROOT));
            List<String> lore = Death.gray("Animasi di dunia tempatmu berdiri.", "");
            lore.add("<dark_gray>Status: " + (off ? "<#FF6B6B>\u25cf DIKECUALIKAN" : "<#5CFF8A>\u25cf AKTIF"));
            lore.add("");
            lore.add("<gray>Dunia dikecualikan:");
            List listed = this.plugin.getConfig().getStringList("death-animation.disabled-worlds");
            if (listed.isEmpty()) {
                lore.add("<dark_gray>  (tidak ada)");
            }
            for (String w : listed) {
                lore.add("<dark_gray>  \u2022 <white>" + Menu.esc(w));
            }
            lore.add("");
            lore.add("<#7FE3FF>\u00bb <gray>Klik untuk " + (off ? "mengaktifkan" : "mengecualikan") + " dunia ini");
            this.set(16, Death.item(off ? Material.DEAD_BUSH : Material.GRASS_BLOCK, "<#B8F1FF><bold>Dunia: " + Menu.esc(world), lore), e -> {
                if (!this.can("bda.menu.edit")) {
                    return;
                }
                ArrayList<String> worlds = new ArrayList<String>(listed);
                if (off) {
                    worlds.removeIf(w -> w.equalsIgnoreCase(world));
                } else {
                    worlds.add(world);
                }
                this.save("death-animation.disabled-worlds", worlds);
                this.sound("block.note_block.pling", off ? 1.6f : 0.7f);
            });
            List<String> causes = Death.gray("Sebab kematian yang tidak memutar", "animasi (pemain mati biasa):", "");
            for (String c : s.skipCauses) {
                causes.add("<dark_gray>  \u2022 <white>" + c);
            }
            causes.add("");
            causes.add("<dark_gray>Ubah di config.yml -> skip-causes");
            this.set(22, Death.item(Material.BOOK, "<#B8F1FF><bold>Sebab yang Dilewati", causes));
            this.back(40, () -> new Main(this.plugin, this.viewer));
        }
    }
}

