/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.FluidCollisionMode
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.NamespacedKey
 *  org.bukkit.World
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.util.RayTraceResult
 *  org.bukkit.util.Vector
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Nebula;
import com.bzl.deathanimation.Rift;
import com.bzl.deathanimation.Sequence;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

final class Descent
extends BukkitRunnable
implements Sequence {
    private static final int OPEN = 6;
    private static final int SKY_CLOSE = 34;
    private static final int TIMEOUT = 300;
    private static final double MAX_DROP = 22.0;
    private final Player player;
    private final Location dest;
    private final Location skyAt;
    private final World world;
    private final Runnable onLand;
    private Rift sky;
    private int tick;
    private boolean done;
    private boolean arrived = true;
    private final NamespacedKey pendingKey;

    Descent(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, Runnable onLand) {
        this.player = player;
        this.pendingKey = plugin.pendingKey;
        player.getPersistentDataContainer().set(this.pendingKey, PersistentDataType.STRING, (Object)(mode.name() + ";" + Nebula.serialize(dest)));
        this.dest = dest.clone();
        this.world = dest.getWorld();
        this.onLand = onLand;
        double drop = Descent.clearAbove(dest);
        this.skyAt = dest.clone().add(0.0, drop, 0.0);
        this.skyAt.setPitch(drop > 3.0 ? 60.0f : 0.0f);
        player.teleport(this.skyAt);
        player.setGameMode(mode);
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 300, 0, false, false, false));
        player.setFallDistance(0.0f);
        this.sky = new Rift(this.skyAt.clone().add(0.0, 2.2, 0.0), 1.6f, false);
        this.world.playSound(this.skyAt, "block.end_portal.spawn", 0.5f, 1.4f);
        this.world.playSound(this.skyAt, "entity.enderman.teleport", 1.0f, 0.8f);
        this.world.playSound(this.skyAt, "block.beacon.activate", 1.0f, 1.2f);
        Fx.get(Fx.Slot.RIFT_OPEN).spawn(this.skyAt.clone().add(0.0, 2.0, 0.0), 60, 0.5, 0.2, 0.5, 0.2);
        player.playSound((Entity)player, "item.elytra.flying", 0.45f, 1.25f);
        this.runTaskTimer((Plugin)plugin, 1L, 1L);
    }

    public void run() {
        ++this.tick;
        if (!this.player.isOnline()) {
            this.abort();
            return;
        }
        if (this.sky != null) {
            if (this.tick < 34) {
                this.sky.size(Descent.outBack(Descent.k(this.tick, 0.0f, 6.0f)), 2, this.tick);
            } else if (this.tick <= 46) {
                this.sky.size(1.0f - Descent.inCubic(Descent.k(this.tick, 34.0f, 46.0f)), 2, this.tick);
            } else {
                this.sky.remove();
                this.sky = null;
                this.world.playSound(this.skyAt, "block.beacon.deactivate", 0.8f, 1.4f);
            }
            if (this.sky != null) {
                this.swirl(this.skyAt.clone().add(0.0, 2.1, 0.0), 1.6);
            }
        }
        Location pos = this.player.getLocation();
        double above = pos.getY() - this.dest.getY();
        boolean grounded = this.player.isOnGround();
        if (grounded && this.tick > 2 || above <= 0.05 || this.tick > 300) {
            this.land();
            return;
        }
        double vy = -Math.min(0.45, 0.07 + above * 0.018);
        this.player.setVelocity(new Vector((this.dest.getX() - pos.getX()) * 0.15, vy, (this.dest.getZ() - pos.getZ()) * 0.15));
        this.player.setFallDistance(0.0f);
        Fx.get(Fx.Slot.DESCENT_TRAIL).spawn(pos.clone().add(0.0, 1.0, 0.0), 4, 0.28, 0.55, 0.28, 0.01);
        double ringR = 1.2 + Math.min(1.5, above * 0.08);
        for (int i = 0; this.tick % 2 == 0 && i < 18; ++i) {
            double a = (double)this.tick * 0.12 + (double)i * Math.PI * 2.0 / 18.0;
            Fx.get(Fx.Slot.LANDING_RING).spawn(this.dest.clone().add(Math.cos(a) * ringR, 0.1, Math.sin(a) * ringR), 1, 0.0, 0.0, 0.0, 0.0);
        }
        if (this.sky != null) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            for (int i = 0; i < 3; ++i) {
                Fx.get(Fx.Slot.LANDING_BEAM).spawn(this.dest.clone().add(r.nextDouble(-0.3, 0.3), r.nextDouble(0.0, this.skyAt.getY() - this.dest.getY() + 2.0), r.nextDouble(-0.3, 0.3)), 1, 0.0, 0.0, 0.0, 0.005);
            }
        }
    }

    private void land() {
        Location at = this.player.getLocation();
        for (int i = 0; i < 24; ++i) {
            double a = (double)i * Math.PI * 2.0 / 24.0;
            Location ring = at.clone().add(Math.cos(a) * 0.4, 0.1, Math.sin(a) * 0.4);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(ring, 0, Math.cos(a), 0.06, Math.sin(a), 0.25);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(ring, 0, Math.cos(a), 0.06, Math.sin(a), 0.25);
        }
        Fx.get(Fx.Slot.FLASH).spawn(at.clone().add(0.0, 1.0, 0.0), 1, 0.0, 0.0, 0.0, 0.0);
        this.world.playSound(at, "block.respawn_anchor.deplete", 1.0f, 1.2f);
        this.world.playSound(at, "block.amethyst_block.resonate", 1.0f, 1.0f);
        this.end();
    }

    @Override
    public void abort() {
        if (this.done) {
            return;
        }
        this.arrived = this.player.teleport(this.dest) && this.player.getWorld().equals((Object)this.dest.getWorld());
        this.end();
    }

    private void end() {
        if (this.done) {
            return;
        }
        this.done = true;
        this.cancel();
        if (this.arrived) {
            this.player.getPersistentDataContainer().remove(this.pendingKey);
        }
        if (this.sky != null) {
            this.sky.remove();
        }
        this.player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        this.player.setFallDistance(0.0f);
        this.player.stopSound("item.elytra.flying");
        this.onLand.run();
    }

    static double clearAbove(Location dest) {
        Location eye = dest.clone().add(0.0, 1.8, 0.0);
        RayTraceResult hit = dest.getWorld().rayTraceBlocks(eye, new Vector(0, 1, 0), 26.0, FluidCollisionMode.ALWAYS, true);
        double room = hit == null ? 26.0 : hit.getHitPosition().getY() - eye.getY();
        double drop = Math.min(22.0, room - 4.0);
        return drop < 3.0 ? 0.0 : drop;
    }

    private void swirl(Location c, double r) {
        for (int arm = 0; arm < 2; ++arm) {
            for (int j = 0; j < 5; ++j) {
                double t = (double)j / 4.0;
                double a = (double)this.tick * 0.25 + (double)arm * Math.PI + t * 2.2;
                double rad = r * (0.25 + 0.8 * t);
                Fx.get(Fx.Slot.RIFT_SWIRL).spawn(c.clone().add(Math.cos(a) * rad, 0.0, Math.sin(a) * rad), 1, 0.0, 0.0, 0.0, 0.0, t);
            }
        }
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0f, Math.max(0.0f, (t - a) / (b - a)));
    }

    private static float inCubic(float x) {
        return x * x * x;
    }

    private static float outBack(float x) {
        if (x <= 0.0f) {
            return 0.0f;
        }
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        return 1.0f + c3 * (float)Math.pow(x - 1.0f, 3.0) + c1 * (float)Math.pow(x - 1.0f, 2.0);
    }
}

