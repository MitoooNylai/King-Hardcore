/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.entity.Player
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Arrival;
import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Descent;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

interface Sequence {
    public void abort();

    public static Sequence fromSky(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, boolean wings, Runnable onLand) {
        return Descent.clearAbove(dest) >= 6.0 ? new Arrival(plugin, player, dest, mode, wings, onLand) : new Descent(plugin, player, dest, mode, onLand);
    }
}

