/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Nebula;
import com.bzl.deathanimation.Rift;
import com.bzl.deathanimation.Sequence;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

final class Release
extends BukkitRunnable {
    private static final int OPEN = 16;
    private static final int SINK = 34;
    private static final int ARRIVE = 46;
    private final BzlDeathAnimation plugin;
    private final Player player;
    private final Location start;
    private final Location dest;
    private final GameMode mode;
    private final Runnable onDone;
    private final Rift floor;
    private Sequence descent;
    private int tick;
    private boolean done;

    Release(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, Runnable onDone) {
        this.plugin = plugin;
        this.player = player;
        this.dest = dest.clone();
        this.mode = mode;
        this.onDone = onDone;
        this.start = player.getLocation();
        player.getPersistentDataContainer().set(plugin.pendingKey, PersistentDataType.STRING, (Object)(mode.name() + ";" + Nebula.serialize(dest)));
        this.floor = new Rift(this.start.clone().add(0.0, 0.06, 0.0), 1.3f, true);
        World w = this.start.getWorld();
        w.playSound(this.start, "block.respawn_anchor.charge", 1.0f, 0.8f);
        w.playSound(this.start, "block.beacon.activate", 1.0f, 1.3f);
        this.runTaskTimer((Plugin)plugin, 1L, 1L);
    }

    public void run() {
        ++this.tick;
        if (!this.player.isOnline()) {
            this.abort();
            return;
        }
        World w = this.start.getWorld();
        float s = Release.outBack(Release.k(this.tick, 0.0f, 16.0f));
        this.floor.size(s, 2, this.tick);
        this.swirl(w, this.start.clone().add(0.0, 0.15, 0.0), 1.3 * (double)s);
        if (this.tick < 34) {
            boolean away;
            Location now = this.player.getLocation();
            boolean bl = away = !now.getWorld().equals((Object)this.start.getWorld()) || now.distanceSquared(this.start) > 0.04;
            if (away) {
                Location hold = this.start.clone();
                hold.setYaw(now.getYaw());
                hold.setPitch(now.getPitch());
                this.player.teleport(hold);
            }
            if (this.tick == 4) {
                w.playSound(this.start, "block.portal.trigger", 0.4f, 1.6f);
            }
            if (this.tick >= 16 && this.tick % 5 == 0) {
                w.playSound(this.start, "block.respawn_anchor.charge", 1.0f, 1.0f + (float)(this.tick - 16) * 0.04f);
            }
            Fx.get(Fx.Slot.FLOOR_RISE).spawn(this.start.clone().add(0.0, 0.2, 0.0), 2, 0.6, 0.05, 0.6, 0.06);
            return;
        }
        if (this.tick == 34) {
            this.player.setGameMode(GameMode.SPECTATOR);
            this.player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false, false));
            w.playSound(this.start, "block.portal.travel", 0.4f, 1.6f);
            w.playSound(this.start, "entity.enderman.teleport", 1.0f, 0.7f);
            Fx.get(Fx.Slot.FLOOR_SINK).spawn(this.start.clone().add(0.0, 0.5, 0.0), 50, 0.3, 0.6, 0.3, 0.2);
        }
        if (this.tick < 46) {
            Location sink = this.start.clone().subtract(0.0, (double)(this.tick - 34) * 0.15, 0.0);
            sink.setYaw(this.player.getLocation().getYaw());
            sink.setPitch(this.player.getLocation().getPitch());
            this.player.teleport(sink);
            return;
        }
        this.cancel();
        this.floor.remove();
        this.descent = Sequence.fromSky(this.plugin, this.player, this.dest, this.mode, this.plugin.settings.wings, () -> {
            Location at = this.player.getLocation();
            at.getWorld().playSound(at, "entity.player.levelup", 0.6f, 1.4f);
            this.player.stopSound("music.end");
            this.finish(false);
        });
    }

    void abort() {
        if (this.done) {
            return;
        }
        if (this.descent != null) {
            this.descent.abort();
            return;
        }
        this.cancel();
        this.floor.remove();
        this.player.removePotionEffect(PotionEffectType.BLINDNESS);
        boolean arrived = this.player.teleport(this.dest) && this.player.getWorld().equals((Object)this.dest.getWorld());
        this.player.setGameMode(this.mode);
        this.player.stopSound("music.end");
        this.finish(arrived);
    }

    private void finish() {
        this.finish(true);
    }

    private void finish(boolean arrived) {
        if (this.done) {
            return;
        }
        this.done = true;
        if (arrived) {
            this.player.getPersistentDataContainer().remove(this.plugin.pendingKey);
        }
        this.onDone.run();
    }

    private void swirl(World w, Location c, double r) {
        if (r < 0.05) {
            return;
        }
        for (int arm = 0; arm < 2; ++arm) {
            for (int j = 0; j < 5; ++j) {
                double t = (double)j / 4.0;
                double a = (double)this.tick * 0.25 + (double)arm * Math.PI + t * 2.2;
                double rad = r * (0.25 + 0.8 * t);
                Fx.get(Fx.Slot.RIFT_SWIRL).spawn(c.clone().add(Math.cos(a) * rad, 0.0, Math.sin(a) * rad), 1, 0.0, 0.0, 0.0, 0.0, t);
            }
        }
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0f, Math.max(0.0f, (t - a) / (b - a)));
    }

    private static float outBack(float x) {
        if (x <= 0.0f) {
            return 0.0f;
        }
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        return 1.0f + c3 * (float)Math.pow(x - 1.0f, 3.0) + c1 * (float)Math.pow(x - 1.0f, 2.0);
    }
}

