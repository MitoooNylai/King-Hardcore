/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.destroystokyo.paper.profile.PlayerProfile
 *  io.papermc.paper.datacomponent.item.ResolvableProfile
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.entity.Mannequin
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Pose
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Body;
import com.destroystokyo.paper.profile.PlayerProfile;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;

final class MannequinBody
implements Body {
    private static final double MIN_SCALE = 0.0625;
    private static final Set<Pose> VALID = MannequinBody.validPoses();
    private static final Map<Pose, Pose> FALLBACK = Map.of(Pose.SLEEPING, Pose.SWIMMING, Pose.SWIMMING, Pose.SNEAKING, Pose.FALL_FLYING, Pose.STANDING, Pose.SNEAKING, Pose.STANDING);
    private static final Set<String> reported = new HashSet<String>();
    private final Mannequin mannequin;
    private final Location feet;
    private final float yaw;
    private final AttributeInstance scaleAttr;
    private boolean removed;
    private boolean canGlide = true;

    MannequinBody(Location feet, float yaw, Player owner) {
        this.feet = feet.clone();
        this.yaw = yaw;
        Location at = feet.clone();
        at.setPitch(0.0f);
        this.mannequin = (Mannequin)at.getWorld().spawn(at, Mannequin.class, m -> {
            m.setPersistent(false);
            m.addScoreboardTag("bda_fx");
            m.setProfile(ResolvableProfile.resolvableProfile((PlayerProfile)owner.getPlayerProfile()));
            m.setMainHand(owner.getMainHand());
            m.setImmovable(true);
            m.setGravity(false);
            m.setInvulnerable(true);
            m.setSilent(true);
            m.setCollidable(false);
            m.setBodyYaw(yaw);
            try {
                m.setDescription(null);
            }
            catch (RuntimeException runtimeException) {
                // empty catch block
            }
        });
        this.scaleAttr = this.mannequin.getAttribute(Attribute.SCALE);
    }

    static void report() {
        if (VALID.isEmpty()) {
            Bukkit.getLogger().warning("[King Hardcore] no mannequin poses available");
        }
    }

    private static Set<Pose> validPoses() {
        try {
            EnumSet<Pose> poses = Mannequin.validPoses();
            Bukkit.getLogger().info("[King Hardcore] Mannequin poses allowed by this server: " + String.valueOf(poses));
            return poses.isEmpty() ? EnumSet.allOf(Pose.class) : poses;
        }
        catch (LinkageError | RuntimeException e) {
            return EnumSet.allOf(Pose.class);
        }
    }

    @Override
    public void pose(Body.Stage stage, float progress, float[] p, double ox, double oy, double oz, float scale) {
        if (this.removed) {
            return;
        }
        switch (stage) {
            case FALL: {
                if (!(p[0] < -55.0f)) break;
                this.setPose(Pose.SLEEPING);
                break;
            }
            case GET_UP: {
                this.setPose(progress < 0.25f ? Pose.SWIMMING : (progress < 0.65f ? Pose.SNEAKING : Pose.STANDING));
                this.move(ox, oy, oz, progress < 0.65f ? 30.0f : 0.0f, 0.0f);
                break;
            }
            case PULL: {
                this.setPose(Pose.FALL_FLYING);
                this.glide();
                float lean = Math.max(0.0f, p[0]) * 1.4f;
                this.move(ox, oy + (double)p[6], oz, -90.0f + Math.min(70.0f, lean), (p[3] - p[4]) * 0.4f);
                this.scale(scale);
                break;
            }
            case DESCEND: {
                this.setPose(Pose.FALL_FLYING);
                this.glide();
                this.move(ox, oy, oz, -78.0f, (1.0f - progress) * 180.0f);
                this.scale(scale);
                break;
            }
            case LAND: {
                this.setPose(progress < 0.5f ? Pose.SNEAKING : Pose.STANDING);
                this.move(ox, oy, oz, progress < 0.5f ? 25.0f : 0.0f, 0.0f);
                this.scale(1.0f);
                break;
            }
            case LOOK: {
                this.setPose(Pose.STANDING);
                this.move(ox, oy, oz, p[5], p[0]);
                MannequinBody.guard("body yaw", () -> this.mannequin.setBodyYaw(this.yaw));
            }
        }
    }

    private void setPose(Pose pose) {
        Pose want = pose;
        while (!VALID.contains(want) && FALLBACK.containsKey(want)) {
            want = FALLBACK.get(want);
        }
        if (this.mannequin.getPose() == want) {
            return;
        }
        Pose target = want;
        if (!MannequinBody.guard("pose " + String.valueOf(target), () -> this.mannequin.setPose(target, true))) {
            MannequinBody.guard("pose STANDING", () -> this.mannequin.setPose(Pose.STANDING, true));
        }
    }

    private void glide() {
        if (this.canGlide) {
            this.canGlide = MannequinBody.guard("gliding", () -> this.mannequin.setGliding(true));
        }
    }

    private void scale(float s) {
        if (this.scaleAttr != null) {
            MannequinBody.guard("scale", () -> this.scaleAttr.setBaseValue(Math.max(0.0625, (double)s)));
        }
    }

    private void move(double ox, double oy, double oz, float pitch, float yawOffset) {
        Location l = this.feet.clone().add(ox, oy, oz);
        l.setYaw(this.yaw + yawOffset);
        l.setPitch(pitch);
        this.mannequin.teleport(l);
        MannequinBody.guard("body yaw", () -> this.mannequin.setBodyYaw(this.yaw + yawOffset));
        MannequinBody.guard("air", () -> this.mannequin.setRemainingAir(this.mannequin.getRemainingAir() == 300 ? 299 : 300));
    }

    private static boolean guard(String what, Runnable call) {
        try {
            call.run();
            return true;
        }
        catch (RuntimeException e) {
            if (reported.add(what)) {
                Bukkit.getLogger().warning("[King Hardcore] Mannequin refused " + what + ": " + String.valueOf(e) + " (using a fallback; the animation continues)");
            }
            return false;
        }
    }

    @Override
    public boolean ready() {
        return this.mannequin.isValid();
    }

    @Override
    public void remove() {
        this.removed = true;
        this.mannequin.remove();
    }
}

