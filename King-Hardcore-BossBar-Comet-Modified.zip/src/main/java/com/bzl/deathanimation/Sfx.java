/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 */
package com.bzl.deathanimation;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

final class Sfx {
    static volatile boolean heartbeatOn = true;
    static volatile boolean breathingOn = true;

    private static float note(int semitones) {
        return (float)Math.pow(2.0, (double)(semitones - 12) / 12.0);
    }

    static void major(Location at, String sound, float volume, int root) {
        Sfx.chord(at, sound, volume, root, root + 4, root + 7, root + 12);
    }

    static void minor(Location at, String sound, float volume, int root) {
        Sfx.chord(at, sound, volume, root, root + 3, root + 7);
    }

    private static void chord(Location at, String sound, float volume, int ... semitones) {
        for (int s : semitones) {
            at.getWorld().playSound(at, sound, volume, Sfx.note(Math.min(24, s)));
        }
    }

    static void heartbeat(Player p, float volume, float pitch) {
        if (heartbeatOn) {
            p.playSound((Entity)p, "entity.warden.heartbeat", volume, pitch);
        }
    }

    static void breatheIn(Player p) {
        if (!breathingOn) {
            return;
        }
        p.playSound((Entity)p, "entity.player.breath", 1.0f, 1.0f);
        p.playSound((Entity)p, "entity.breeze.inhale", 1.0f, 1.7f);
        p.playSound((Entity)p, "entity.wolf.pant", 0.5f, 1.35f);
    }

    static void breatheOut(Player p) {
        if (!breathingOn) {
            return;
        }
        p.playSound((Entity)p, "entity.horse.breathe", 1.0f, 1.3f);
    }

    private Sfx() {
    }
}

