/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.FluidCollisionMode
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.entity.BlockDisplay
 *  org.bukkit.entity.Display
 *  org.bukkit.entity.Display$Brightness
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.ItemDisplay
 *  org.bukkit.entity.Player
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.util.RayTraceResult
 *  org.bukkit.util.Vector
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Body;
import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Portal;
import com.bzl.deathanimation.Puppet;
import com.bzl.deathanimation.Sfx;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

final class Cinematic
extends BukkitRunnable {
    private static final int FALL_END = 14;
    private static final int WAKE = 54;
    private static final int CUT2 = 109;
    private static final int CUT3 = 200;
    private static final int STONE_FALL = 58;
    private static final int DRAW = 92;
    private static final int ASSEMBLE = 112;
    private static final int STEPS = 120;
    private static final int CONVERGE = 168;
    private static final int IGNITE = 178;
    private static final int GETUP_END = 235;
    private static final int PULL_START = 243;
    private static final int PULL_END = 343;
    private static final int CLOSE_END = 357;
    private static final int DONE = 377;
    private static final int[] CUTS = new int[]{54, 109, 200};
    private static final int[][] EYES_CLOSED = new int[][]{{16, 20}, {28, 33}, {40, 54}};
    private static final Display.Brightness PITCH_BLACK = new Display.Brightness(0, 0);
    private static final float[] STANDING = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
    private static final float[] LYING = new float[]{-90.0f, -30.0f, 10.0f, 0.0f, 0.0f, 0.0f, 0.13f};
    private static final float[] KNEEL = new float[]{-45.0f, -15.0f, 20.0f, -35.0f, -35.0f, 15.0f, 0.05f};
    private static final float[] BLOWN = new float[]{30.0f, 75.0f, 15.0f, 25.0f, 12.0f, -25.0f, 0.8f};
    private final BzlDeathAnimation plugin;
    private final Player player;
    private final World world;
    private final Location feet;
    private final Location startEye;
    private final Location lyingEye;
    private final Location portalCenter;
    private final Location site;
    private final Vector forward;
    private final Vector right;
    private final Vector up = new Vector(0, 1, 0);
    private final Vector travel;
    private final GameMode originalMode;
    private final Body body;
    private final Portal portal;
    private final ItemDisplay camera;
    private final BlockDisplay lidTop;
    private final BlockDisplay lidBottom;
    private Location lastChase;
    private float lid;
    private double shake;
    private int tick;
    private boolean eyesClosed;
    private boolean finished;
    private int nextBeat = 15;

    Cinematic(BzlDeathAnimation plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.world = player.getWorld();
        this.feet = Cinematic.groundBelow(player);
        float yaw = this.feet.getYaw();
        this.forward = new Vector(-Math.sin(Math.toRadians(yaw)), 0.0, Math.cos(Math.toRadians(yaw)));
        this.right = this.forward.getCrossProduct(this.up).normalize();
        this.startEye = player.getEyeLocation();
        this.lyingEye = this.feet.clone().subtract(this.forward.clone().multiply(1.75)).add(0.0, 0.55, 0.0);
        this.site = this.feet.clone().add(this.forward.clone().multiply(plugin.settings.portalDistance));
        this.portalCenter = this.site.clone().add(0.0, plugin.settings.portalHeight, 0.0);
        this.travel = this.portalCenter.toVector().subtract(new Vector(0.0, 1.0, 0.0)).subtract(this.feet.toVector());
        Body b = null;
        Portal pt = null;
        ItemDisplay cam = null;
        BlockDisplay top = null;
        BlockDisplay bottom = null;
        try {
            b = Body.create(this.feet, yaw, player, plugin.skinOf(player), plugin.settings.body);
            pt = new Portal(this.portalCenter, yaw, plugin.settings.portalHeight, new Portal.Timing(58, 92, 112, 120, 178));
            cam = (ItemDisplay)this.world.spawn(this.startEye, ItemDisplay.class, d -> {
                d.setPersistent(false);
                d.addScoreboardTag("bda_fx");
                d.setTeleportDuration(3);
            });
            top = this.spawnLid();
            bottom = this.spawnLid();
        }
        catch (RuntimeException e) {
            if (b != null) {
                b.remove();
            }
            if (pt != null) {
                pt.remove();
            }
            if (cam != null) {
                cam.remove();
            }
            if (top != null) {
                top.remove();
            }
            if (bottom != null) {
                bottom.remove();
            }
            throw e;
        }
        this.body = b;
        this.portal = pt;
        this.camera = cam;
        this.lidTop = top;
        this.lidBottom = bottom;
        this.originalMode = player.getGameMode();
        player.getPersistentDataContainer().set(plugin.savedModeKey, PersistentDataType.STRING, (Object)this.originalMode.name());
        player.setGameMode(GameMode.SPECTATOR);
        this.moveFirstPerson(this.startEye, false);
        this.world.playSound(this.feet, "entity.player.hurt", 1.0f, 0.8f);
        this.runTaskTimer((Plugin)plugin, 1L, 1L);
    }

    private static Location groundBelow(Player player) {
        Location at = player.getLocation();
        boolean grounded = player.isOnGround();
        if (grounded || at.getBlock().isLiquid()) {
            return at;
        }
        RayTraceResult hit = at.getWorld().rayTraceBlocks(at.clone().add(0.0, 0.1, 0.0), new Vector(0, -1, 0), 40.0, FluidCollisionMode.ALWAYS, true);
        if (hit == null) {
            return at;
        }
        Location ground = hit.getHitPosition().toLocation(at.getWorld());
        ground.setYaw(at.getYaw());
        ground.setPitch(at.getPitch());
        return ground;
    }

    private BlockDisplay spawnLid() {
        Location at = this.startEye.clone();
        at.setYaw(0.0f);
        at.setPitch(0.0f);
        return (BlockDisplay)this.world.spawn(at, BlockDisplay.class, d -> {
            d.setPersistent(false);
            d.addScoreboardTag("bda_fx");
            d.setBlock(Material.BLACK_CONCRETE.createBlockData());
            d.setBrightness(PITCH_BLACK);
            d.setTeleportDuration(2);
            d.setDisplayWidth(4.0f);
            d.setDisplayHeight(4.0f);
        });
    }

    public void run() {
        ++this.tick;
        if (this.player.getSpectatorTarget() != this.camera) {
            this.plugin.watch(this.player, (Entity)this.camera);
        }
        for (int cut : CUTS) {
            if (this.tick == cut - 1) {
                this.camera.setTeleportDuration(0);
            }
            if (this.tick != cut + 1) continue;
            this.camera.setTeleportDuration(3);
        }
        if (this.tick <= 14) {
            this.fall();
        } else if (this.tick < 54) {
            this.lieAndBlink();
        } else if (this.tick == 54) {
            this.wake();
        }
        if (this.tick >= 54) {
            if (this.tick < 357) {
                this.shake += (double)this.portal.update(this.tick, Cinematic.inCubic(Cinematic.k(this.tick, 343.0f, 357.0f))) * 0.35;
            } else if (this.tick == 357) {
                this.portal.remove();
                Fx.get(Fx.Slot.PORTAL_CLOSE).spawn(this.portalCenter, 30, 0.1, 0.1, 0.1, 0.2);
                this.world.playSound(this.portalCenter, "block.respawn_anchor.deplete", 0.8f, 1.5f);
            }
            this.buildEffects();
            this.bodyScene();
            this.directCamera();
        }
        if (this.tick >= 377) {
            this.finish(true);
        }
    }

    private void fall() {
        float f = (float)this.tick / 14.0f;
        f *= f;
        this.body.pose(Body.Stage.FALL, f, Cinematic.mix(STANDING, LYING, f), 0.0, 0.0, 0.0, 1.0f);
        Location eye = Cinematic.lerp(this.startEye, this.lyingEye, f);
        eye.setYaw(this.startEye.getYaw());
        eye.setPitch(Cinematic.lerp(this.startEye.getPitch(), -80.0f, f));
        this.moveFirstPerson(eye, false);
        if (this.tick == 14) {
            this.world.playSound(this.feet, "entity.generic.big_fall", 1.0f, 0.9f);
            this.player.playSound((Entity)this.player, "block.beacon.ambient", 0.5f, 2.0f);
            Fx.get(Fx.Slot.BODY_FALL).spawn(this.feet, 12, 0.6, 0.05, 0.6, 0.02);
        }
    }

    private void lieAndBlink() {
        boolean closed = false;
        for (int[] w : EYES_CLOSED) {
            closed |= this.tick >= w[0] && this.tick < w[1];
        }
        if (this.tick >= this.nextBeat) {
            Sfx.heartbeat(this.player, 1.0f, 1.0f);
            this.nextBeat = this.tick + (this.tick < 30 ? 14 : (this.tick < 44 ? 17 : 21));
        }
        if (!closed && this.eyesClosed) {
            Sfx.breatheIn(this.player);
        }
        this.eyesClosed = closed;
        Location eye = this.lyingEye.clone();
        eye.setYaw(this.startEye.getYaw());
        eye.setPitch(-80.0f + (float)Math.sin((double)this.tick * 0.12) * 2.5f);
        this.moveFirstPerson(eye, closed);
    }

    private void moveFirstPerson(Location eye, boolean closed) {
        this.camera.teleport(eye);
        this.lid = closed ? Math.min(1.0f, this.lid + 0.45f) : Math.max(0.0f, this.lid - 0.3f);
        float gap = (1.0f - Cinematic.smooth(this.lid)) * 0.8f;
        Matrix4f face = new Matrix4f().rotateY((float)(-Math.toRadians(eye.getYaw()))).rotateX((float)Math.toRadians(eye.getPitch()));
        Puppet.apply((Display)this.lidTop, new Matrix4f((Matrix4fc)face).translate(-1.2f, gap - 0.01f, 0.2f).scale(2.4f, 0.8f, 0.01f), 2);
        Puppet.apply((Display)this.lidBottom, new Matrix4f((Matrix4fc)face).translate(-1.2f, -gap - 0.79f, 0.2f).scale(2.4f, 0.8f, 0.01f), 2);
        Location at = eye.clone();
        at.setYaw(0.0f);
        at.setPitch(0.0f);
        this.lidTop.teleport(at);
        this.lidBottom.teleport(at);
    }

    private void wake() {
        this.lidTop.remove();
        this.lidBottom.remove();
        this.world.playSound(this.site, "entity.wither.spawn", 0.35f, 1.6f);
        this.world.playSound(this.site, "entity.lightning_bolt.thunder", 0.6f, 0.8f);
        Sfx.minor(this.site, "block.note_block.bell", 0.7f, 1);
        this.world.playSound(this.site, "item.elytra.flying", 0.35f, 1.3f);
        if (this.plugin.settings.music) {
            this.player.playSound((Entity)this.player, "music.end", 0.9f, 1.0f);
        }
    }

    private void directCamera() {
        Location look;
        Location pos;
        if (this.tick < 109) {
            float t = Cinematic.smooth(Cinematic.k(this.tick, 54.0f, 103.0f));
            pos = this.feet.clone().subtract(this.forward.clone().multiply(2.5)).add(this.right.clone().multiply(3)).add(0.0, (double)Cinematic.lerp(9.0f, 2.2f, t), 0.0);
            look = this.site.clone().add(0.0, (double)Cinematic.lerp(30.0f, 1.0f, t), 0.0);
        } else if (this.tick < 200) {
            float t = Cinematic.smooth(Cinematic.k(this.tick, 109.0f, 200.0f));
            pos = this.portalCenter.clone().subtract(this.forward.clone().multiply(Cinematic.lerp(11.0f, 6.5f, t))).add(this.right.clone().multiply(Cinematic.lerp(2.5f, 0.6f, t))).add(0.0, (double)Cinematic.lerp(-1.3f, -0.4f, t), 0.0);
            look = this.portalCenter.clone().add(0.0, 0.3, 0.0);
        } else if (this.tick < 343) {
            Location at = this.bodyAt();
            Location side = this.feet.clone().add(this.right.clone().multiply(3.4)).subtract(this.forward.clone().multiply(0.6)).add(this.forward.clone().multiply(0.6 * (double)Cinematic.k(this.tick, 200.0f, 243.0f))).add(0.0, 1.1, 0.0);
            Location sideLook = this.feet.clone().add(0.0, 0.8, 0.0);
            Location chase = at.clone().subtract(this.forward.clone().multiply(4.2)).add(this.right.clone().multiply(1.4)).add(0.0, 0.6, 0.0);
            Location chaseLook = Cinematic.lerp(at, this.portalCenter, 0.65f);
            float b = Cinematic.smooth(Cinematic.k(this.tick, 239.0f, 259.0f));
            pos = Cinematic.lerp(side, chase, b);
            look = Cinematic.lerp(sideLook, chaseLook, b);
            this.lastChase = pos.clone();
        } else {
            pos = this.lastChase.clone().subtract(this.forward.clone().multiply(1.5 * (double)Cinematic.k(this.tick, 343.0f, 377.0f)));
            look = this.portalCenter;
        }
        if (this.tick >= 109) {
            pos = pos.clone().add(Math.sin((double)this.tick * 0.13) * 0.06, Math.sin((double)this.tick * 0.17 + 1.0) * 0.05, Math.sin((double)this.tick * 0.11 + 2.0) * 0.06);
        }
        if (!this.plugin.settings.screenShake) {
            this.shake = 0.0;
        }
        if (this.shake > 0.01) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            pos = pos.clone().add(r.nextDouble(-this.shake, this.shake), r.nextDouble(-this.shake, this.shake), r.nextDouble(-this.shake, this.shake));
            this.shake *= 0.8;
        }
        this.place(pos, look);
    }

    private void place(Location pos, Location look) {
        RayTraceResult hit;
        Vector off = pos.toVector().subtract(look.toVector());
        double len = off.length();
        if (len > 0.01 && (hit = this.world.rayTraceBlocks(look, off.clone().normalize(), len, FluidCollisionMode.NEVER, true)) != null) {
            off.normalize().multiply(Math.max(0.8, hit.getHitPosition().distance(look.toVector()) - 0.4));
        }
        Location cam = look.clone().add(off);
        this.camera.teleport(cam.setDirection(look.toVector().subtract(cam.toVector())));
    }

    private void buildEffects() {
        int i;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (this.tick >= 168 && this.tick < 178) {
            if (this.tick == 168) {
                this.world.playSound(this.portalCenter, "block.beacon.power_select", 1.0f, 0.5f);
                this.world.playSound(this.portalCenter, "block.conduit.ambient.short", 1.0f, 0.8f);
            }
            if ((this.tick - 168) % 3 == 0) {
                this.world.playSound(this.portalCenter, "block.respawn_anchor.charge", 1.0f, 1.2f + (float)(this.tick - 168) * 0.06f);
            }
            for (i = 0; i < 6; ++i) {
                Cinematic.suck(Fx.Slot.PORTAL_STREAM, this.onPortal(r.nextDouble(Math.PI * 2), 2.4 + r.nextDouble(1.2)), this.portalCenter, 0.04);
            }
            Fx.get(Fx.Slot.PORTAL_CHARGE).spawn(this.portalCenter, 3, 0.1, 0.1, 0.1, 0.01);
        }
        if (this.tick == 178) {
            Cinematic.flash(this.portalCenter);
            Fx.get(Fx.Slot.PORTAL_IGNITE).spawn(this.portalCenter, 120, 0.25, 0.25, 0.25, 0.27);
            for (i = 0; i < 36; ++i) {
                double a = (double)i * Math.PI * 2.0 / 36.0;
                Vector dir = this.right.clone().multiply(Math.cos(a)).add(new Vector(0.0, Math.sin(a), 0.0));
                Location from = this.portalCenter.clone().add(dir.clone().multiply(1.6));
                Fx.get(Fx.Slot.SHOCKWAVE_RING).spawn(from, 0, dir.getX(), dir.getY(), dir.getZ(), 0.5);
                Vector flat = this.right.clone().multiply(Math.cos(a)).add(this.forward.clone().multiply(Math.sin(a)));
                Fx.get(Fx.Slot.SHOCKWAVE_GROUND).spawn(this.site.clone().add(flat).add(0.0, 0.2, 0.0), 0, flat.getX(), 0.0, flat.getZ(), 0.6);
            }
            this.world.playSound(this.portalCenter, "block.end_portal.spawn", 0.6f, 1.2f);
            Sfx.major(this.portalCenter, "block.note_block.bell", 1.0f, 6);
            this.world.playSound(this.portalCenter, "item.trident.thunder", 0.8f, 1.0f);
            this.world.playSound(this.portalCenter, "entity.warden.sonic_boom", 0.4f, 1.4f);
            this.world.playSound(this.portalCenter, "block.respawn_anchor.set_spawn", 1.0f, 0.9f);
            this.world.playSound(this.portalCenter, "block.conduit.activate", 1.0f, 0.9f);
            this.world.playSound(this.portalCenter, "block.beacon.activate", 1.0f, 1.2f);
            this.world.playSound(this.portalCenter, "entity.generic.explode", 0.6f, 1.6f);
            this.shake += 0.5;
        }
        if (this.tick > 178 && this.tick < 343) {
            if ((this.tick - 178) % 30 == 0) {
                this.world.playSound(this.portalCenter, "block.respawn_anchor.ambient", 1.0f, 0.8f);
            }
            if ((this.tick - 178) % 50 == 25) {
                this.world.playSound(this.portalCenter, "block.beacon.ambient", 1.0f, 1.1f);
            }
            this.vortex(Math.min(1.0f, Cinematic.k(this.tick, 183.0f, 194.0f)));
            for (i = 0; i < 12; ++i) {
                Fx.get(Fx.Slot.PORTAL_HALO).spawn(this.onPortal(r.nextDouble(Math.PI * 2), 1.62 + r.nextDouble(0.4)), 1, 0.0, 0.0, 0.05, 0.0);
            }
            for (int arm = 0; arm < 2; ++arm) {
                Fx.get(Fx.Slot.PORTAL_SPIRAL).spawn(this.onPortal(-((double)this.tick * 0.25 + (double)arm * Math.PI), 1.3), 1, 0.0, 0.0, 0.0, 0.0);
            }
            for (i = 0; i < 3; ++i) {
                Location from = this.onPortal(r.nextDouble(Math.PI * 2), 2.6 + r.nextDouble()).add(this.forward.clone().multiply(r.nextDouble(-0.6, 0.2)));
                Cinematic.suck(Fx.Slot.PORTAL_STREAM, from, this.portalCenter, 0.035);
            }
            if (this.tick % 2 == 0) {
                Fx.get(Fx.Slot.PORTAL_SPARKLE).spawn(this.onPortal(r.nextDouble(Math.PI * 2), 1.7), 1, 0.05, 0.05, 0.05, 0.0);
            }
        } else if (this.tick >= 343 && this.tick < 357) {
            for (i = 0; i < 10; ++i) {
                Cinematic.suck(Fx.Slot.PORTAL_STREAM, this.onPortal(r.nextDouble(Math.PI * 2), 2.0 + r.nextDouble(1.5)), this.portalCenter, 0.045);
            }
        }
    }

    private void vortex(float size) {
        if (size <= 0.0f) {
            return;
        }
        Vector toViewer = this.forward.clone().multiply(-0.08);
        Fx fx = Fx.get(Fx.Slot.PORTAL_VORTEX);
        for (int arm = 0; arm < 4; ++arm) {
            for (int j = 0; j < 7; ++j) {
                float t = (float)j / 6.0f;
                double a = (double)this.tick * 0.18 + (double)arm * Math.PI / 2.0 + (double)t * 2.4;
                double r = (0.15 + (double)t * 1.25) * (double)size;
                fx.spawn(this.onPortal(a, r).add(toViewer), 1, 0.02, 0.02, 0.0, 0.0, t);
            }
        }
    }

    private float pullTravel() {
        float q = Cinematic.k(this.tick, 246.0f, 343.0f);
        return q < 0.5f ? 2.0f * q * q : 1.0f - 2.0f * (1.0f - q) * (1.0f - q);
    }

    private Location bodyAt() {
        return this.feet.clone().add(this.travel.clone().multiply(this.pullTravel())).add(0.0, 1.0, 0.0);
    }

    private void bodyScene() {
        if (this.tick < 200 || this.tick > 343) {
            return;
        }
        if (this.tick == 343) {
            this.body.remove();
            Cinematic.flash(this.portalCenter);
            Fx.get(Fx.Slot.BODY_ENTER).spawn(this.portalCenter, 110, 0.4, 0.4, 0.25, 0.3);
            this.world.playSound(this.portalCenter, "entity.enderman.teleport", 1.0f, 0.6f);
            this.world.playSound(this.portalCenter, "entity.firework_rocket.twinkle", 1.0f, 0.8f);
            this.world.playSound(this.portalCenter, "block.portal.travel", 0.25f, 1.4f);
            this.world.playSound(this.portalCenter, "block.respawn_anchor.deplete", 1.0f, 0.7f);
            this.world.playSound(this.portalCenter, "block.beacon.deactivate", 1.0f, 0.8f);
            this.world.playSound(this.portalCenter, "block.end_gateway.spawn", 0.5f, 1.3f);
            return;
        }
        Location at = this.bodyAt();
        if (this.tick < 243) {
            float g = Cinematic.k(this.tick, 200.0f, 235.0f);
            float[] p = g < 0.5f ? Cinematic.mix(LYING, KNEEL, Cinematic.smooth(g * 2.0f)) : Cinematic.mix(KNEEL, STANDING, Cinematic.smooth((g - 0.5f) * 2.0f));
            this.body.pose(Body.Stage.GET_UP, g, p, 0.0, 0.0, 0.0, 1.0f);
            if (this.tick == 202) {
                Sfx.heartbeat(this.player, 1.0f, 1.1f);
            }
            if (this.tick == 208) {
                Sfx.breatheIn(this.player);
            }
            if (this.tick == 215) {
                Sfx.breatheOut(this.player);
            }
            if (this.tick == 224) {
                Sfx.breatheIn(this.player);
            }
            if (this.tick == 231) {
                Sfx.breatheOut(this.player);
            }
            if (this.tick == 220) {
                this.world.playSound(this.feet, "item.armor.equip_generic", 1.0f, 0.8f);
            }
            if (this.tick % 4 == 0) {
                Fx.get(Fx.Slot.BODY_GETUP).spawn(at, 2, 0.4, 0.6, 0.4, 0.0);
            }
            return;
        }
        float jolt = 1.0f - (float)Math.pow(1.0f - Cinematic.k(this.tick, 243.0f, 248.0f), 3.0);
        float q = Cinematic.k(this.tick, 246.0f, 343.0f);
        float e = this.pullTravel();
        float[] p = Cinematic.mix(STANDING, BLOWN, jolt);
        float wob = q > 0.0f ? (float)Math.sin((double)this.tick * 0.35) * (1.0f - q) : 0.0f;
        p[0] = p[0] + (wob * 2.0f + 10.0f * Cinematic.smooth(q));
        p[1] = p[1] + wob * 8.0f;
        p[3] = p[3] + wob * 5.0f;
        p[4] = p[4] - wob * 5.0f;
        p[6] = p[6] + (float)Math.sin((double)q * Math.PI) * 0.35f;
        this.body.pose(Body.Stage.PULL, q, p, this.travel.getX() * (double)e, this.travel.getY() * (double)e, this.travel.getZ() * (double)e, 1.0f - Cinematic.inCubic(Cinematic.k(q, 0.7f, 1.0f)) * 0.98f);
        if (this.tick == 243) {
            this.world.playSound(at, "entity.breeze.wind_burst", 1.0f, 0.7f);
            this.world.playSound(at, "item.elytra.flying", 0.5f, 1.4f);
            Location behind = at.clone().subtract(this.forward.clone().multiply(0.6));
            Fx.get(Fx.Slot.BODY_HIT).spawn(behind, 20, 0.2, 0.4, 0.2, 0.07);
            this.shake += 0.25;
        }
        if (this.tick == 246 + Math.round(48.5f)) {
            this.world.playSound(at, "entity.breeze.wind_burst", 1.0f, 1.1f);
            this.world.playSound(at, "entity.phantom.swoop", 0.8f, 0.7f);
            this.shake += 0.15;
        }
        Fx.get(Fx.Slot.BODY_TRAIL).spawn(at, 4, 0.22, 0.45, 0.22, 0.01);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Cinematic.suck(Fx.Slot.PORTAL_STREAM, at.clone().add(r.nextDouble(-0.3, 0.3), r.nextDouble(-0.6, 0.6), 0.0), this.portalCenter, 0.04);
    }

    private static void suck(Fx.Slot slot, Location from, Location to, double speed) {
        Vector v = to.toVector().subtract(from.toVector()).multiply(speed);
        Fx.get(slot).spawn(from, 0, v.getX(), v.getY(), v.getZ(), 1.0);
    }

    private Location onPortal(double a, double r) {
        return this.portalCenter.clone().add(this.right.clone().multiply(Math.cos(a) * r)).add(0.0, Math.sin(a) * r, 0.0);
    }

    private static void flash(Location at) {
        Fx.get(Fx.Slot.FLASH).spawn(at, 1, 0.0, 0.0, 0.0, 0.0);
    }

    void finish(boolean animate) {
        if (this.finished) {
            return;
        }
        this.finished = true;
        this.cancel();
        this.plugin.running.remove(this.player.getUniqueId());
        this.body.remove();
        this.portal.remove();
        for (Display d : new Display[]{this.camera, this.lidTop, this.lidBottom}) {
            d.remove();
        }
        BzlDeathAnimation.unwatch(this.player);
        this.player.setGameMode(this.originalMode);
        this.player.getPersistentDataContainer().remove(this.plugin.savedModeKey);
        this.plugin.nebula.imprison(this.player, this.feet, animate, this.originalMode);
    }

    private static float[] mix(float[] a, float[] b, float t) {
        float[] out = new float[a.length];
        for (int i = 0; i < a.length; ++i) {
            out[i] = a[i] + (b[i] - a[i]) * t;
        }
        return out;
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0f, Math.max(0.0f, (t - a) / (b - a)));
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static Location lerp(Location a, Location b, float t) {
        return a.clone().add(b.toVector().subtract(a.toVector()).multiply(t));
    }

    private static float smooth(float x) {
        return x * x * (3.0f - 2.0f * x);
    }

    private static float inCubic(float x) {
        return x * x * x;
    }
}

