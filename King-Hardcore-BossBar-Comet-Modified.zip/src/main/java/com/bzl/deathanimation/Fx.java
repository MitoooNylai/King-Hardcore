/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.destroystokyo.paper.ParticleBuilder
 *  org.bukkit.Bukkit
 *  org.bukkit.Color
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Particle$DustOptions
 *  org.bukkit.Particle$DustTransition
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package com.bzl.deathanimation;

import com.destroystokyo.paper.ParticleBuilder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

final class Fx {
    private static final Set<String> warned = new HashSet<String>();
    private static volatile Map<Slot, Fx> current = Map.of();
    private static final Fx OFF = new Fx(Slot.FLASH, false, List.of(), List.of(), List.of(Color.WHITE), 1.0f, 0.0, Material.STONE.createBlockData(), 0.0, 0);
    final Slot slot;
    final boolean enabled;
    final List<Particle> types;
    final List<Double> weights;
    private final double weightSum;
    final List<Color> colors;
    final float size;
    final double amount;
    final BlockData block;
    private final double globalAmount;
    private final int viewDistance;
    private int rotation;

    static Fx get(Slot slot) {
        Fx fx = current.get((Object)slot);
        return fx != null ? fx : OFF;
    }

    static void install(Map<Slot, Fx> slots) {
        current = Map.copyOf(slots);
    }

    private Fx(Slot slot, boolean enabled, List<Particle> types, List<Double> weights, List<Color> colors, float size, double amount, BlockData block, double globalAmount, int viewDistance) {
        this.slot = slot;
        this.enabled = enabled;
        this.types = types;
        this.weights = weights;
        this.weightSum = weights.stream().mapToDouble(Double::doubleValue).sum();
        this.colors = colors;
        this.size = size;
        this.amount = amount;
        this.block = block;
        this.globalAmount = globalAmount;
        this.viewDistance = viewDistance;
    }

    static Fx load(ConfigurationSection root, Slot slot, double globalAmount, int viewDistance) {
        String base = "particles.effects." + slot.key + ".";
        ArrayList<Particle> types = new ArrayList<Particle>();
        ArrayList<Double> weights = new ArrayList<Double>();
        for (Object entry : root.getStringList(base + "particles")) {
            String[] parts = ((String)entry).split("\\*", 2);
            String name = parts[0].trim().toUpperCase(Locale.ROOT);
            double weight = 1.0;
            if (parts.length == 2) {
                try {
                    weight = Math.max(0.0, Double.parseDouble(parts[1].trim()));
                }
                catch (NumberFormatException e) {
                    Fx.warnOnce(slot.key + ":" + (String)entry, "bad weight in '" + (String)entry + "' (particles.effects." + slot.key + "), using 1");
                }
            }
            try {
                types.add(Particle.valueOf((String)name));
                weights.add(weight);
            }
            catch (IllegalArgumentException e) {
                Fx.warnOnce(slot.key + ":" + name, "unknown particle '" + name + "' in particles.effects." + slot.key + " (skipped)");
            }
        }
        ArrayList<Color> colors = new ArrayList<Color>();
        for (String hex : root.getStringList(base + "colors")) {
            Color c = Fx.parseColor(hex);
            if (c != null) {
                colors.add(c);
                continue;
            }
            Fx.warnOnce(slot.key + ":" + hex, "bad colour '" + hex + "' in particles.effects." + slot.key + " (use #RRGGBB)");
        }
        if (colors.isEmpty()) {
            colors.add(Color.WHITE);
        }
        BlockData block = null;
        String blockName = root.getString(base + "block", "");
        if (!blockName.isBlank()) {
            Material m = Material.matchMaterial((String)blockName);
            if (m != null && m.isBlock()) {
                block = m.createBlockData();
            } else {
                Fx.warnOnce(slot.key + ":" + blockName, "bad block '" + blockName + "' in particles.effects." + slot.key);
            }
        }
        if (block == null) {
            block = Material.DEEPSLATE.createBlockData();
        }
        return new Fx(slot, root.getBoolean(base + "enabled", true), types, weights, colors, (float)Math.max(0.05, root.getDouble(base + "size", 1.0)), Math.max(0.0, root.getDouble(base + "amount", 1.0)), block, globalAmount, viewDistance);
    }

    void spawn(Location at, int count, double dx, double dy, double dz, double speed, double t) {
        if (!this.enabled || this.types.isEmpty() || this.weightSum <= 0.0 || at.getWorld() == null) {
            return;
        }
        if (count == 0) {
            if (this.amount * this.globalAmount <= 0.0) {
                return;
            }
            this.emit(null, this.next(), at, 0, dx, dy, dz, speed, t);
            return;
        }
        double total = (double)count * this.amount * this.globalAmount;
        for (int i = 0; i < this.types.size(); ++i) {
            int n = Fx.stochasticRound(total * this.weights.get(i) / this.weightSum);
            if (n <= 0) continue;
            this.emit(null, this.types.get(i), at, n, dx, dy, dz, speed, t);
        }
    }

    void spawn(Location at, int count, double dx, double dy, double dz, double speed) {
        this.spawn(at, count, dx, dy, dz, speed, 0.0);
    }

    void spawnFor(Player p, Location at, int count, double dx, double dy, double dz, double speed, double t) {
        int total;
        if (!this.enabled || this.types.isEmpty()) {
            return;
        }
        int n = total = count == 0 ? 0 : this.scaled(count);
        if (count != 0 && total <= 0) {
            return;
        }
        this.emit(p, count == 0 ? this.next() : this.types.get(Math.floorMod(this.rotation++, this.types.size())), at, total, dx, dy, dz, speed, t);
    }

    private int scaled(int count) {
        return Fx.stochasticRound((double)count * this.amount * this.globalAmount);
    }

    private static int stochasticRound(double n) {
        return n >= 1.0 ? (int)Math.round(n) : (ThreadLocalRandom.current().nextDouble() < n ? 1 : 0);
    }

    private Particle next() {
        return this.types.get(Math.floorMod(this.rotation++, this.types.size()));
    }

    private void emit(Player only, Particle type, Location at, int count, double dx, double dy, double dz, double speed, double t) {
        Object data;
        try {
            data = this.dataFor(type, t);
        }
        catch (UnsupportedOperationException e) {
            Fx.warnOnce("data:" + String.valueOf(type), "particle " + String.valueOf(type) + " needs data this plugin can't build; use another type in particles.effects." + this.slot.key);
            return;
        }
        ParticleBuilder b = new ParticleBuilder(type).location(at).count(count).offset(dx, dy, dz).extra(speed);
        if (data != null) {
            b.data(data);
        }
        if (only != null) {
            b.receivers(new Player[]{only});
        } else {
            b.receivers(this.viewDistance);
        }
        try {
            b.spawn();
        }
        catch (IllegalArgumentException e) {
            Fx.warnOnce("spawn:" + String.valueOf(type), "particle " + String.valueOf(type) + " could not be spawned (" + e.getMessage() + ") in particles.effects." + this.slot.key);
        }
    }

    private Object dataFor(Particle type, double t) {
        Class want = type.getDataType();
        if (want == Void.class) {
            return null;
        }
        if (want == Particle.DustOptions.class) {
            return new Particle.DustOptions(this.color(t), this.size);
        }
        if (want == Particle.DustTransition.class) {
            return new Particle.DustTransition(this.colors.get(0), this.colors.get(this.colors.size() - 1), this.size);
        }
        if (want == BlockData.class) {
            return this.block;
        }
        if (want == Color.class) {
            return this.color(t);
        }
        if (want == Float.class) {
            return Float.valueOf(this.size);
        }
        if (want == Integer.class) {
            return 0;
        }
        if (want == ItemStack.class) {
            return new ItemStack(this.block.getMaterial().isItem() ? this.block.getMaterial() : Material.STONE);
        }
        throw new UnsupportedOperationException();
    }

    static boolean supported(Particle type) {
        Class want = type.getDataType();
        return want == Void.class || want == Particle.DustOptions.class || want == Particle.DustTransition.class || want == BlockData.class || want == Color.class || want == Float.class || want == Integer.class || want == ItemStack.class;
    }

    List<String> entries() {
        ArrayList<String> out = new ArrayList<String>();
        for (int i = 0; i < this.types.size(); ++i) {
            double w = this.weights.get(i);
            out.add((String)(w == 1.0 ? this.types.get(i).name() : this.types.get(i).name() + "*" + Fx.num(w)));
        }
        return out;
    }

    static String num(double v) {
        return v == Math.rint(v) ? String.valueOf((long)v) : String.valueOf((double)Math.round(v * 100.0) / 100.0);
    }

    Color color(double t) {
        if (this.colors.size() == 1) {
            return this.colors.get(0);
        }
        double x = Math.max(0.0, Math.min(1.0, t)) * (double)(this.colors.size() - 1);
        int i = Math.min(this.colors.size() - 2, (int)x);
        double f = x - (double)i;
        Color a = this.colors.get(i);
        Color b = this.colors.get(i + 1);
        return Color.fromRGB((int)((int)Math.round((double)a.getRed() + (double)(b.getRed() - a.getRed()) * f)), (int)((int)Math.round((double)a.getGreen() + (double)(b.getGreen() - a.getGreen()) * f)), (int)((int)Math.round((double)a.getBlue() + (double)(b.getBlue() - a.getBlue()) * f)));
    }

    static Color parseColor(String hex) {
        String h = hex.trim().replace("#", "");
        if (!h.matches("[0-9a-fA-F]{6}")) {
            return null;
        }
        return Color.fromRGB((int)Integer.parseInt(h, 16));
    }

    static String hex(Color c) {
        return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
    }

    private static void warnOnce(String key, String message) {
        if (warned.add(key)) {
            Bukkit.getLogger().warning("[King Hardcore] " + message);
        }
    }

    static void resetWarnings() {
        warned.clear();
    }

    static enum Slot {
        BODY_FALL("body-fall", "Debu saat badan jatuh ke tanah", Material.COARSE_DIRT),
        STONE_TRAIL("stone-trail", "Jejak api batu yang jatuh dari langit", Material.BLAZE_POWDER),
        STONE_IMPACT("stone-impact", "Ledakan saat batu menghantam tanah", Material.TNT),
        STONE_IMPACT_RING("stone-impact-ring", "Cincin debu dari hantaman batu", Material.GRAY_DYE),
        STONE_LIFTOFF("stone-liftoff", "Serpihan saat batu terangkat", Material.COBBLED_DEEPSLATE),
        STONE_FLIGHT("stone-flight", "Jejak batu yang terbang ke portal", Material.FEATHER),
        STONE_LOCK("stone-lock", "Kilau saat batu terpasang", Material.AMETHYST_SHARD),
        STEPS_DEBRIS("steps-debris", "Debu tangga yang naik dari tanah", Material.DEEPSLATE_TILES),
        PORTAL_CHARGE("portal-charge", "Energi yang terkumpul sebelum menyala", Material.GLOWSTONE_DUST),
        PORTAL_STREAM("portal-stream", "Partikel yang tersedot ke portal", Material.ENDER_PEARL),
        PORTAL_IGNITE("portal-ignite", "Semburan saat portal menyala", Material.FIRE_CHARGE),
        SHOCKWAVE_RING("shockwave-ring", "Gelombang kejut di bidang portal", Material.HEART_OF_THE_SEA),
        SHOCKWAVE_GROUND("shockwave-ground", "Gelombang kejut di tanah", Material.WHITE_WOOL),
        PORTAL_HALO("portal-halo", "Cahaya lembut di tepi portal", Material.LIGHT_BLUE_DYE),
        PORTAL_SPIRAL("portal-spiral", "Spiral di tepi portal", Material.STRING),
        PORTAL_SPARKLE("portal-sparkle", "Kilau acak di tepi portal", Material.GLOW_INK_SAC),
        PORTAL_VORTEX("portal-vortex", "Pusaran galaksi di tengah portal", Material.ENDER_EYE),
        PORTAL_CLOSE("portal-close", "Semburan saat portal tertutup", Material.END_ROD),
        BODY_GETUP("body-getup", "Aura saat badan bangun", Material.SUGAR),
        BODY_HIT("body-hit", "Hembusan saat badan dihantam dari belakang", Material.WIND_CHARGE),
        BODY_TRAIL("body-trail", "Jejak badan yang tersedot ke portal", Material.GHAST_TEAR),
        BODY_ENTER("body-enter", "Semburan saat badan masuk portal", Material.NETHER_STAR),
        FLASH("flash", "Kilatan putih (portal, mendarat)", Material.GLOWSTONE),
        RIFT_SWIRL("rift-swirl", "Pusaran portal kecil (lantai / langit)", Material.PRISMARINE_CRYSTALS),
        RIFT_OPEN("rift-open", "Semburan saat portal langit terbuka", Material.END_CRYSTAL),
        FLOOR_RISE("floor-rise", "Cahaya naik dari portal lantai Nebula", Material.BEACON),
        FLOOR_SINK("floor-sink", "Semburan saat tenggelam ke portal lantai", Material.ENDER_PEARL),
        DESCENT_TRAIL("descent-trail", "Jejak badan yang turun dari langit", Material.PHANTOM_MEMBRANE),
        LANDING_RING("landing-ring", "Lingkaran titik mendarat", Material.LIGHT_BLUE_CARPET),
        LANDING_BEAM("landing-beam", "Sorot cahaya dari portal ke tanah", Material.SPECTRAL_ARROW),
        LANDING_SHOCKWAVE("landing-shockwave", "Gelombang saat mendarat", Material.SLIME_BALL),
        WINGS("wings", "Sayap dewi (warna dari pangkal ke ujung)", Material.ELYTRA),
        WING_TIPS("wing-tips", "Cahaya di ujung sayap", Material.END_ROD),
        WINGS_OPEN("wings-open", "Semburan saat sayap terbuka penuh", Material.TOTEM_OF_UNDYING),
        WING_BEAT("wing-beat", "Hembusan setiap kepakan sayap", Material.FEATHER),
        WINGS_BURST("wings-burst", "Sayap pecah jadi bulu", Material.WHITE_DYE),
        HALO("halo", "Halo di atas kepala", Material.GOLD_NUGGET),
        NEBULA_ARRIVE("nebula-arrive", "Cahaya saat mendarat di Nebula", Material.ECHO_SHARD),
        NEBULA_STARS("nebula-stars", "Bintang yang melayang di Nebula", Material.NETHER_STAR);

        final String key;
        final String description;
        final Material icon;

        private Slot(String key, String description, Material icon) {
            this.key = key;
            this.description = description;
            this.icon = icon;
        }
    }
}

