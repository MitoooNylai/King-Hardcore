/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.format.NamedTextColor
 *  net.kyori.adventure.text.format.TextColor
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Bukkit
 *  org.bukkit.command.ConsoleCommandSender
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Body;
import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Settings;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;

final class Banner {
    private static final String[] BDA = new String[]{"########  ########     ###", "##     ## ##     ##   ## ##", "##     ## ##     ##  ##   ##", "########  ##     ## ##     ##", "##     ## ##     ## #########", "##     ## ##     ## ##     ##", "########  ########  ##     ##"};
    private static final String RULE = "=".repeat(70);
    private static final String THIN = "-".repeat(70);
    private static final TextColor ICE = TextColor.color((int)8381439);
    private static final TextColor DEEP = TextColor.color((int)4176127);
    private static final TextColor PALE = TextColor.color((int)12120575);

    static void print(BzlDeathAnimation plugin, Settings settings) {
        ConsoleCommandSender console = Bukkit.getConsoleSender();
        console.sendMessage((Component)Component.text((String)RULE, (TextColor)NamedTextColor.DARK_GRAY));
        console.sendMessage((Component)Component.text((String)"  B Z L   D E V E L O P E R", (TextColor)DEEP, (TextDecoration[])new TextDecoration[]{TextDecoration.BOLD}));
        console.sendMessage((Component)Component.text((String)RULE, (TextColor)NamedTextColor.DARK_GRAY));
        console.sendMessage((Component)Component.empty());
        for (String line : BDA) {
            console.sendMessage((Component)Component.text((String)("  " + line), (TextColor)ICE));
        }
        console.sendMessage((Component)Component.empty());
        console.sendMessage((Component)Component.text((String)"  Death Animation", (TextColor)PALE, (TextDecoration[])new TextDecoration[]{TextDecoration.BOLD}));
        console.sendMessage((Component)Component.empty());
        console.sendMessage((Component)Component.text((String)THIN, (TextColor)NamedTextColor.DARK_GRAY));
        Banner.row(console, "Plugin", "King Hardcore v" + plugin.getPluginMeta().getVersion());
        Banner.row(console, "Author", String.join((CharSequence)", ", plugin.getPluginMeta().getAuthors()));
        Banner.row(console, "Menu", "/bda menu  (permission bda.menu)");
        Banner.row(console, "Server", Bukkit.getName() + " " + Bukkit.getMinecraftVersion());
        Banner.row(console, "Body", Body.MANNEQUIN && !"blocks".equals(settings.body) ? "Mannequin (full skin)" : "Block body (player head)");
        Banner.row(console, "Nebula", "world '" + settings.nebulaWorld + "', " + settings.durationMinutes + " min");
        Banner.row(console, "Particles", settings.particles.size() + " effects, x" + settings.particleAmount);
        console.sendMessage((Component)Component.text((String)RULE, (TextColor)NamedTextColor.DARK_GRAY));
    }

    private static void row(ConsoleCommandSender console, String label, String value) {
        console.sendMessage(((TextComponent)Component.text((String)("  " + String.format("%-10s", label)), (TextColor)NamedTextColor.GRAY).append((Component)Component.text((String)": ", (TextColor)NamedTextColor.DARK_GRAY))).append((Component)Component.text((String)value, (TextColor)NamedTextColor.WHITE)));
    }

    private Banner() {
    }
}

