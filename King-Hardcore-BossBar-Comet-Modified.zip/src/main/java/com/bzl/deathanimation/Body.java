/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.entity.Player
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.MannequinBody;
import com.bzl.deathanimation.Puppet;
import org.bukkit.Location;
import org.bukkit.entity.Player;

interface Body {
    public static final boolean MANNEQUIN = Body.classExists("org.bukkit.entity.Mannequin");

    public void pose(Stage var1, float var2, float[] var3, double var4, double var6, double var8, float var10);

    public void remove();

    public boolean ready();

    public static Body create(Location feet, float yaw, Player owner, Puppet.Colors colors, String type) {
        if ("blocks".equals(type) || !MANNEQUIN) {
            return new Puppet(feet, yaw, owner, colors);
        }
        return Body.create(feet, yaw, owner, colors);
    }

    public static Body create(Location feet, float yaw, Player owner, Puppet.Colors colors) {
        return MANNEQUIN ? new MannequinBody(feet, yaw, owner) : new Puppet(feet, yaw, owner, colors);
    }

    private static boolean classExists(String name) {
        try {
            Class.forName(name);
            return true;
        }
        catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static enum Stage {
        FALL,
        GET_UP,
        PULL,
        DESCEND,
        LAND,
        LOOK;

    }
}

