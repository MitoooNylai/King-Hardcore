/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.FluidCollisionMode
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.NamespacedKey
 *  org.bukkit.World
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.ItemDisplay
 *  org.bukkit.entity.Player
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.util.RayTraceResult
 *  org.bukkit.util.Vector
 */
package com.bzl.deathanimation;

import com.bzl.deathanimation.Body;
import com.bzl.deathanimation.BzlDeathAnimation;
import com.bzl.deathanimation.Descent;
import com.bzl.deathanimation.Fx;
import com.bzl.deathanimation.Nebula;
import com.bzl.deathanimation.Rift;
import com.bzl.deathanimation.Sequence;
import com.bzl.deathanimation.Sfx;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

final class Arrival
extends BukkitRunnable
implements Sequence {
    private static final int OPEN = 10;
    private static final int EMERGE = 12;
    private static final int EMERGE_END = 26;
    private static final int CHASE_FROM = 30;
    private static final int LOOK_HOLD = 74;
    private static final int WINGS_HOLD = 104;
    private static final int WINGS_FROM = 10;
    private static final int BEATS = 3;
    private static final int BEAT_TICKS = 22;
    private static final int CAM_SMOOTH = 3;
    private static final Vector UP = new Vector(0, 1, 0);
    private static final double HIDDEN_ABOVE = 2.4;
    private static final float[] DESCEND_POSE = new float[]{10.0f, -150.0f, 30.0f, 15.0f, -10.0f, 20.0f, 0.0f};
    private static final float[] CROUCH = new float[]{-20.0f, -20.0f, 20.0f, -40.0f, -40.0f, 20.0f, 0.0f};
    private static final float[] STAND = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
    private final Player player;
    private final World world;
    private final Location dest;
    private final Location bodyTop;
    private final Location portalAt;
    private final Vector forward;
    private final Vector right;
    private final double drop;
    private final int landTick;
    private final int endTick;
    private final boolean wings;
    private final GameMode mode;
    private final Runnable onLand;
    private final NamespacedKey pendingKey;
    private Body body;
    private ItemDisplay camera;
    private Rift rift;
    private final float yaw;
    private final BzlDeathAnimation plugin;
    private final List<long[]> tickets = new ArrayList<long[]>();
    private int warmup;
    private int liveFor;
    private boolean ready;
    private double shake;
    private double bodyOy = 2.4;
    private int tick;
    private boolean done;

    Arrival(BzlDeathAnimation plugin, Player player, Location dest, GameMode mode, boolean wings, Runnable onLand) {
        this.player = player;
        this.wings = wings;
        this.dest = dest.clone();
        this.world = dest.getWorld();
        this.mode = mode;
        this.onLand = onLand;
        this.pendingKey = plugin.pendingKey;
        this.plugin = plugin;
        this.yaw = dest.getYaw();
        this.forward = new Vector(-Math.sin(Math.toRadians(this.yaw)), 0.0, Math.cos(Math.toRadians(this.yaw)));
        this.right = this.forward.getCrossProduct(UP).normalize();
        this.drop = Descent.clearAbove(dest);
        this.bodyTop = dest.clone().add(0.0, this.drop, 0.0);
        this.portalAt = this.bodyTop.clone().add(0.0, 2.2, 0.0);
        this.landTick = 26 + (int)Math.max(50.0, Math.min(90.0, this.drop * 4.0));
        this.endTick = this.landTick + (wings ? 104 : 74);
        int cx = dest.getBlockX() >> 4;
        int cz = dest.getBlockZ() >> 4;
        for (int x = cx - 1; x <= cx + 1; ++x) {
            for (int z = cz - 1; z <= cz + 1; ++z) {
                this.world.addPluginChunkTicket(x, z, (Plugin)plugin);
                this.tickets.add(new long[]{x, z});
            }
        }
        player.getPersistentDataContainer().set(this.pendingKey, PersistentDataType.STRING, (Object)(mode.name() + ";" + Nebula.serialize(dest)));
        player.setGameMode(GameMode.SPECTATOR);
        player.teleport(this.shot());
        this.runTaskTimer((Plugin)plugin, 1L, 1L);
    }

    private void begin() {
        this.camera = (ItemDisplay)this.world.spawn(this.shot(), ItemDisplay.class, d -> {
            d.setPersistent(false);
            d.addScoreboardTag("bda_fx");
            d.setTeleportDuration(3);
        });
        this.spawnBody();
        this.rift = new Rift(this.portalAt, 1.6f, false);
        this.world.playSound(this.portalAt, "block.end_portal.spawn", 0.5f, 1.4f);
        this.world.playSound(this.portalAt, "entity.lightning_bolt.thunder", 0.4f, 1.6f);
        this.world.playSound(this.portalAt, "block.beacon.activate", 1.0f, 1.2f);
    }

    private void spawnBody() {
        this.body = Body.create(this.bodyTop, this.yaw, this.player, this.plugin.skinOf(this.player), this.plugin.settings.body);
        this.body.pose(Body.Stage.DESCEND, 1.0f, DESCEND_POSE, 0.0, 2.4, 0.0, 1.0f);
    }

    public void run() {
        int cut;
        if (!this.player.isOnline()) {
            this.abort();
            return;
        }
        if (!this.ready) {
            ++this.warmup;
            boolean live = this.player.getWorld().equals((Object)this.world) && this.clientHas(this.shot()) && this.clientAround(this.dest);
            int n = this.liveFor = live ? this.liveFor + 1 : 0;
            if (this.liveFor >= 30 || this.warmup > 140) {
                this.ready = true;
                if (!this.player.getWorld().equals((Object)this.world)) {
                    this.finish();
                    return;
                }
                try {
                    this.begin();
                }
                catch (RuntimeException e) {
                    this.plugin.getLogger().log(Level.SEVERE, "Arrival cinematic failed for " + this.player.getName() + "; landing them directly.", e);
                    this.finish();
                    return;
                }
            } else {
                Location hold = this.shot();
                if (!this.player.getWorld().equals((Object)hold.getWorld()) || this.player.getLocation().distanceSquared(hold) > 0.01) {
                    this.player.teleport(hold);
                }
                return;
            }
        }
        ++this.tick;
        if (this.tick == 2 || this.tick == 8 || this.tick == 20 || this.tick == 40) {
            BzlDeathAnimation.unwatch(this.player);
            this.plugin.watch(this.player, (Entity)this.camera);
        }
        if (this.tick > 2 && this.player.getSpectatorTarget() != this.camera) {
            this.plugin.watch(this.player, (Entity)this.camera);
        }
        if (this.tick == 6 && !this.body.ready()) {
            this.plugin.getLogger().warning("Arrival body for " + this.player.getName() + " was not in the world; respawning it.");
            this.body.remove();
            this.spawnBody();
        }
        if (this.tick == (cut = this.landTick - 6) - 1) {
            this.camera.setTeleportDuration(0);
        }
        if (this.tick == cut + 1) {
            this.camera.setTeleportDuration(3);
        }
        this.portal();
        this.bodyScene();
        if (this.wings && this.tick >= this.landTick + 10) {
            this.wingShow(this.tick - this.landTick - 10);
        }
        this.camera.teleport(this.shot());
        if (this.tick >= this.endTick) {
            this.finish();
        }
    }

    private void portal() {
        if (this.rift == null) {
            return;
        }
        int close = 44;
        if (this.tick < close) {
            this.rift.size(Arrival.outBack(Arrival.k(this.tick, 0.0f, 10.0f)), 2, this.tick);
        } else if (this.tick <= close + 12) {
            this.rift.size(1.0f - Arrival.inCubic(Arrival.k(this.tick, close, close + 12)), 2, this.tick);
        } else {
            this.rift.remove();
            this.rift = null;
            this.world.playSound(this.portalAt, "block.beacon.deactivate", 0.8f, 1.4f);
            return;
        }
        for (int arm = 0; arm < 2; ++arm) {
            for (int j = 0; j < 5; ++j) {
                double t = (double)j / 4.0;
                double a = (double)this.tick * 0.25 + (double)arm * Math.PI + t * 2.2;
                double rad = 1.6 * (0.25 + 0.8 * t);
                Fx.get(Fx.Slot.RIFT_SWIRL).spawn(this.portalAt.clone().add(Math.cos(a) * rad, -0.1, Math.sin(a) * rad), 1, 0.0, 0.0, 0.0, 0.0, t);
            }
        }
        if (this.tick == 12) {
            this.world.playSound(this.portalAt, "entity.enderman.teleport", 1.0f, 0.8f);
        }
    }

    private void bodyScene() {
        if (this.tick < 12) {
            return;
        }
        if (this.tick < this.landTick) {
            double oy;
            float emerge = Arrival.smooth(Arrival.k(this.tick, 12.0f, 26.0f));
            float q = Arrival.k(this.tick, 26.0f, this.landTick);
            double fall = 1.0 - Math.pow(1.0f - q, 1.6);
            this.bodyOy = oy = -this.drop * fall + 2.4 * (double)(1.0f - emerge);
            this.body.pose(Body.Stage.DESCEND, 1.0f, DESCEND_POSE, 0.0, oy, 0.0, 1.0f);
            Location at = this.bodyTop.clone().add(0.0, oy + 1.0, 0.0);
            Fx.get(Fx.Slot.DESCENT_TRAIL).spawn(at, 4, 0.28, 0.55, 0.28, 0.01);
            this.ring(1.2 + Math.min(1.5, this.drop * (1.0 - fall) * 0.08));
            if (this.rift != null) {
                this.beam();
            }
            if (this.tick == 26) {
                this.player.playSound((Entity)this.player, "item.elytra.flying", 0.5f, 1.3f);
            }
            return;
        }
        this.bodyOy = -this.drop;
        float g = Arrival.k(this.tick, this.landTick, this.landTick + 14);
        if (this.wings || g < 1.0f || !this.plugin.settings.lookAround) {
            this.body.pose(Body.Stage.LAND, g, g < 0.5f ? CROUCH : STAND, 0.0, -this.drop, 0.0, 1.0f);
        } else {
            int t = this.tick - this.landTick - 14;
            float pitch = 4.0f + (float)Math.sin((double)t * 0.13) * 7.0f;
            this.body.pose(Body.Stage.LOOK, Arrival.k(t, 0.0f, 60.0f), new float[]{Arrival.headYaw(t), 0.0f, 0.0f, 0.0f, 0.0f, pitch, 0.0f}, 0.0, -this.drop, 0.0, 1.0f);
            if (t % 12 == 0) {
                Sfx.breatheIn(this.player);
            }
            if (t % 12 == 6) {
                Sfx.breatheOut(this.player);
            }
            if (t == 10 || t == 30) {
                this.player.playSound((Entity)this.player, "entity.sniffer.sniffing", 0.7f, 1.3f);
            }
            if (t % 14 == 0) {
                Sfx.heartbeat(this.player, 0.8f, 1.15f);
            }
            if (t == 26) {
                this.player.playSound((Entity)this.player, "block.amethyst_block.chime", 0.6f, 0.8f);
            }
        }
        if (this.tick == this.landTick) {
            this.touchdown();
        }
    }

    private static float headYaw(int t) {
        if (t < 6) {
            return 0.0f;
        }
        if (t < 16) {
            return -55.0f * Arrival.smooth(Arrival.k(t, 6.0f, 16.0f));
        }
        if (t < 24) {
            return -55.0f;
        }
        if (t < 38) {
            return -55.0f + 110.0f * Arrival.smooth(Arrival.k(t, 24.0f, 38.0f));
        }
        if (t < 46) {
            return 55.0f;
        }
        if (t < 56) {
            return 55.0f * (1.0f - Arrival.smooth(Arrival.k(t, 46.0f, 56.0f)));
        }
        return 0.0f;
    }

    private void touchdown() {
        for (int i = 0; i < 28; ++i) {
            double a = (double)i * Math.PI * 2.0 / 28.0;
            Location p = this.dest.clone().add(Math.cos(a) * 0.4, 0.1, Math.sin(a) * 0.4);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(p, 0, Math.cos(a), 0.06, Math.sin(a), 0.3);
            Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(p, 0, Math.cos(a), 0.06, Math.sin(a), 0.3);
        }
        Arrival.flash(this.dest.clone().add(0.0, 1.0, 0.0));
        this.world.playSound(this.dest, "entity.generic.big_fall", 1.0f, 0.7f);
        this.world.playSound(this.dest, "block.respawn_anchor.deplete", 1.0f, 1.2f);
        this.world.playSound(this.dest, "block.amethyst_block.resonate", 1.0f, 1.0f);
        if (!this.wings) {
            Sfx.minor(this.dest, "block.note_block.bell", 0.8f, 3);
        }
        this.player.stopSound("item.elytra.flying");
        this.shake += 0.35;
    }

    private void wingShow(int t) {
        Location center = this.dest.clone().add(0.0, 1.0, 0.0);
        float unfold = Arrival.smooth(Arrival.k(t, 0.0f, 14.0f));
        int beatsEnd = 80;
        double flap = 0.0;
        if (t >= 14 && t < beatsEnd) {
            double phase = (double)(t - 14) / 22.0;
            flap = Math.sin(phase * Math.PI * 2.0) * 1.15;
        } else if (t >= beatsEnd) {
            flap = Math.sin((double)(t - beatsEnd) * 0.15) * 0.15;
        }
        if (t < 0 || this.tick >= this.endTick - 2) {
            return;
        }
        if (this.tick < this.endTick - 6 && this.tick % 2 == 0) {
            this.drawWings(center, unfold, flap);
        }
        if (t == 0) {
            this.world.playSound(this.dest, "block.beacon.power_select", 1.0f, 1.6f);
            this.world.playSound(this.dest, "block.amethyst_block.resonate", 1.0f, 1.4f);
            this.world.playSound(this.dest, "item.armor.equip_elytra", 1.0f, 0.8f);
            Fx.get(Fx.Slot.WINGS_OPEN).spawn(center, 40, 0.4, 0.6, 0.4, 0.15);
        }
        if (t == 14) {
            this.player.playSound((Entity)this.player, "ui.toast.challenge_complete", 0.9f, 1.0f);
            Sfx.major(this.dest, "block.note_block.bell", 1.0f, 6);
            Sfx.major(this.dest, "block.note_block.chime", 0.7f, 13);
            this.world.playSound(this.dest, "entity.player.levelup", 1.0f, 0.8f);
            this.world.playSound(this.dest, "entity.firework_rocket.large_blast", 1.0f, 1.0f);
            this.world.playSound(this.dest, "entity.firework_rocket.twinkle", 1.0f, 1.2f);
            Fx.get(Fx.Slot.WINGS_OPEN).spawn(center, 120, 0.6, 1.0, 0.6, 0.5);
            Arrival.flash(center);
            this.shake += 0.3;
        }
        if (t >= 14 && t < beatsEnd && (t - 14) % 22 == 11) {
            int beat = (t - 14) / 22;
            this.world.playSound(this.dest, "entity.ender_dragon.flap", 1.0f, 1.1f + (float)beat * 0.15f);
            this.world.playSound(this.dest, "entity.breeze.wind_burst", 0.8f, 1.2f + (float)beat * 0.1f);
            Sfx.major(this.dest, "block.note_block.bell", 0.6f, 8 + beat * 2);
            for (int i = 0; i < 24; ++i) {
                double a = (double)i * Math.PI * 2.0 / 24.0;
                Fx.get(Fx.Slot.LANDING_SHOCKWAVE).spawn(this.dest.clone().add(Math.cos(a) * 0.6, 0.15, Math.sin(a) * 0.6), 0, Math.cos(a), 0.01, Math.sin(a), 0.35);
            }
            Fx.get(Fx.Slot.WING_BEAT).spawn(center, 40, 2.2, 1.0, 2.2, 0.02);
            this.shake += 0.15;
        }
        if (this.tick == this.endTick - 6) {
            Location c = center.clone().add(0.0, 0.4, 0.0);
            Fx.get(Fx.Slot.WINGS_BURST).spawn(c, 360, 2.4, 1.3, 2.4, 0.04);
            Sfx.major(this.dest, "block.note_block.bell", 1.0f, 13);
            this.world.playSound(this.dest, "block.respawn_anchor.set_spawn", 1.0f, 1.3f);
            this.world.playSound(this.dest, "entity.firework_rocket.twinkle_far", 1.0f, 1.0f);
        }
    }

    private void drawWings(Location center, float unfold, double flap) {
        Vector back = this.forward.clone().multiply(-1);
        Location shoulder = center.clone().add(0.0, 0.35, 0.0).add(back.clone().multiply(0.3));
        double span = 6.2 * (double)unfold;
        for (int s = -1; s <= 1; s += 2) {
            Vector out = this.right.clone().multiply(s);
            Vector o = out.clone().multiply(Math.cos(flap)).add(UP.clone().multiply(Math.sin(flap)));
            Vector l = UP.clone().multiply(Math.cos(flap)).subtract(out.clone().multiply(Math.sin(flap)));
            Fx wing = Fx.get(Fx.Slot.WINGS);
            for (int i = 0; i <= 24; ++i) {
                wing.spawn(Arrival.arm(shoulder, o, l, back, (double)i / 24.0, span), 1, 0.0, 0.0, 0.0, 0.0, 0.0);
            }
            for (int f = 0; f < 9; ++f) {
                double a = 0.14 + (double)f * 0.105;
                Location root = Arrival.arm(shoulder, o, l, back, a, span);
                double len = (0.9 + 1.4 * (1.0 - Math.min(1.0, Math.abs(a - 0.6) * 1.6))) * (double)unfold;
                Vector dir = l.clone().multiply(-0.85).add(o.clone().multiply(0.35)).add(back.clone().multiply(0.15)).normalize();
                for (int j = 1; j <= 5; ++j) {
                    Location p = root.clone().add(dir.clone().multiply(len * (double)j / 5.0));
                    wing.spawn(p, 1, 0.0, 0.0, 0.0, 0.0, (double)j / 5.0);
                }
            }
            Fx.get(Fx.Slot.WING_TIPS).spawn(Arrival.arm(shoulder, o, l, back, 1.0, span), 1, 0.0, 0.0, 0.0, 0.005);
        }
        Location crown = center.clone().add(0.0, 1.15, 0.0);
        for (int i = 0; i < 14; ++i) {
            double a = (double)this.tick * 0.08 + (double)i * Math.PI * 2.0 / 14.0;
            Fx.get(Fx.Slot.HALO).spawn(crown.clone().add(Math.cos(a) * 0.34, 0.0, Math.sin(a) * 0.34), 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private static Location arm(Location shoulder, Vector out, Vector lift, Vector back, double a, double span) {
        return shoulder.clone().add(out.clone().multiply(a * span)).add(lift.clone().multiply(Math.sin(a * Math.PI * 0.85) * 0.9 + a * 0.4)).add(back.clone().multiply(a * 0.4));
    }

    private void ring(double r) {
        if (this.tick % 2 != 0) {
            return;
        }
        for (int i = 0; i < 18; ++i) {
            double a = (double)this.tick * 0.12 + (double)i * Math.PI * 2.0 / 18.0;
            Fx.get(Fx.Slot.LANDING_RING).spawn(this.dest.clone().add(Math.cos(a) * r, 0.1, Math.sin(a) * r), 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void beam() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < 3; ++i) {
            Fx.get(Fx.Slot.LANDING_BEAM).spawn(this.dest.clone().add(r.nextDouble(-0.3, 0.3), r.nextDouble(0.0, this.drop + 2.0), r.nextDouble(-0.3, 0.3)), 1, 0.0, 0.0, 0.0, 0.005);
        }
    }

    private static void flash(Location at) {
        Fx.get(Fx.Slot.FLASH).spawn(at, 1, 0.0, 0.0, 0.0, 0.0);
    }

    private boolean clientAround(Location at) {
        for (int dx = -16; dx <= 16; dx += 16) {
            for (int dz = -16; dz <= 16; dz += 16) {
                if (this.clientHas(at.clone().add((double)dx, 0.0, (double)dz))) continue;
                return false;
            }
        }
        return true;
    }

    private boolean clientHas(Location at) {
        long x = at.getBlockX() >> 4;
        long z = at.getBlockZ() >> 4;
        return this.player.isChunkSent(x & 0xFFFFFFFFL | (z & 0xFFFFFFFFL) << 32);
    }

    private Location shot() {
        Location look;
        Location pos;
        Location center = this.bodyTop.clone().add(0.0, this.bodyOy + 1.0, 0.0);
        if (this.tick < this.landTick - 6) {
            Location open = center.clone().add(this.right.clone().multiply(4.5)).add(0.0, -2.2, 0.0);
            Location openLook = this.portalAt.clone().subtract(0.0, 0.6, 0.0);
            Location chase = center.clone().subtract(this.forward.clone().multiply(4.2)).add(0.0, 1.8, 0.0);
            Location chaseLook = center.clone().add(this.forward.clone().multiply(0.6)).subtract(0.0, 0.3, 0.0);
            float b = Arrival.smooth(Arrival.k(this.tick, 12.0f, 30.0f));
            pos = Arrival.lerp(open, chase, b);
            look = Arrival.lerp(openLook, chaseLook, b);
        } else if (this.wings) {
            float t = Arrival.smooth(Arrival.k(this.tick, this.landTick - 6, this.endTick));
            pos = this.dest.clone().add(this.forward.clone().multiply(8.0f + 3.0f * t)).add(this.right.clone().multiply(1.0)).add(0.0, 1.2 + 1.2 * (double)t, 0.0);
            look = this.dest.clone().add(0.0, 1.9, 0.0);
        } else {
            float t = Arrival.smooth(Arrival.k(this.tick, this.landTick - 6, this.landTick + 10));
            Location hero = this.dest.clone().add(this.forward.clone().multiply(4.5 - (double)t)).add(this.right.clone().multiply(1.0)).add(0.0, 0.5, 0.0);
            Location heroLook = this.dest.clone().add(0.0, 1.0, 0.0);
            float c = Arrival.smooth(Arrival.k(this.tick, this.landTick + 12, this.landTick + 36));
            Location close = this.dest.clone().add(this.forward.clone().multiply(1.8)).add(this.right.clone().multiply(0.35)).add(0.0, 1.65, 0.0);
            Location closeLook = this.dest.clone().add(0.0, 1.6, 0.0);
            pos = Arrival.lerp(hero, close, c);
            look = Arrival.lerp(heroLook, closeLook, c);
        }
        if (!this.plugin.settings.screenShake) {
            this.shake = 0.0;
        }
        if (this.shake > 0.01) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            pos = pos.clone().add(r.nextDouble(-this.shake, this.shake), r.nextDouble(-this.shake, this.shake), r.nextDouble(-this.shake, this.shake));
            this.shake *= 0.8;
        }
        return this.clip(pos, look);
    }

    private Location clip(Location pos, Location look) {
        RayTraceResult hit;
        Vector off = pos.toVector().subtract(look.toVector());
        double len = off.length();
        if (len > 0.01 && (hit = this.world.rayTraceBlocks(look, off.clone().normalize(), len, FluidCollisionMode.NEVER, true)) != null) {
            off.normalize().multiply(Math.max(0.8, hit.getHitPosition().distance(look.toVector()) - 0.4));
        }
        Location cam = look.clone().add(off);
        return cam.setDirection(look.toVector().subtract(cam.toVector()));
    }

    private static Location lerp(Location a, Location b, float t) {
        return a.clone().add(b.toVector().subtract(a.toVector()).multiply(t));
    }

    private void finish() {
        if (this.done) {
            return;
        }
        this.done = true;
        this.cancel();
        if (this.body != null) {
            this.body.remove();
        }
        if (this.rift != null) {
            this.rift.remove();
        }
        if (this.camera != null) {
            this.camera.remove();
        }
        BzlDeathAnimation.unwatch(this.player);
        Location at = this.dest.clone();
        at.setPitch(0.0f);
        boolean arrived = this.player.teleport(at) && this.player.getWorld().equals((Object)this.dest.getWorld());
        this.player.setGameMode(this.mode);
        this.player.setFallDistance(0.0f);
        if (arrived) {
            this.player.getPersistentDataContainer().remove(this.pendingKey);
        }
        this.player.stopSound("item.elytra.flying");
        for (long[] t : this.tickets) {
            this.world.removePluginChunkTicket((int)t[0], (int)t[1], (Plugin)this.plugin);
        }
        this.onLand.run();
    }

    @Override
    public void abort() {
        this.finish();
    }

    private static float k(float t, float a, float b) {
        return Math.min(1.0f, Math.max(0.0f, (t - a) / (b - a)));
    }

    private static float smooth(float x) {
        return x * x * (3.0f - 2.0f * x);
    }

    private static float inCubic(float x) {
        return x * x * x;
    }

    private static float outBack(float x) {
        if (x <= 0.0f) {
            return 0.0f;
        }
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        return 1.0f + c3 * (float)Math.pow(x - 1.0f, 3.0) + c1 * (float)Math.pow(x - 1.0f, 2.0);
    }
}

